// Lumina scene contract, schema 1 - reference implementation.
//
// This scene is the executable form of docs/SCENE-CONTRACT.md. It requests every signal at v1,
// handles every lifecycle transition, renders its own live state, and logs every message it
// receives. When the WebView2 SDK, signal schema, lifecycle or renderer implementation changes,
// a contract break shows up here as a visible diff instead of a silent behaviour change.
//
// It is also the reference scene authors copy from, so the patterns here have to be the ones we
// actually want repeated: reading the negotiated signal set rather than the requested one,
// capping frame rate at maxFps, and tolerating unknown message types.

(function () {
  'use strict';

  var SCHEMA = 1;

  var host = {
    post: function (msg) {
      try { window.chrome.webview.postMessage(msg); } catch (e) { /* not hosted */ }
    }
  };

  // ------------------------------------------------------------------ state

  var state = {
    lifecycle: 'Initializing',
    luminaVersion: '?',
    sceneId: '?',
    negotiated: null,     // the signals the host actually agreed to send
    display: null,
    performance: { tier: 'idle', targetFps: 30, maxFps: 60 },
    cursor: null,
    clock: null,
    sun: null,
    season: null,
    weather: null,
    climate: null,
    audio: null,
    lastLife: 'none',
    lastLifeAt: performance.now(),
    initReceived: false
  };

  var canvas = document.getElementById('c');
  var ctx = canvas.getContext('2d');
  var statePanel = document.getElementById('state');
  var logPanel = document.getElementById('log');

  function log(text, cls) {
    var row = document.createElement('div');
    row.textContent = new Date().toISOString().substr(11, 12) + '  ' + text;
    if (cls) row.className = cls;
    logPanel.insertBefore(row, logPanel.firstChild);
    while (logPanel.childNodes.length > 120) logPanel.removeChild(logPanel.lastChild);
  }

  // ----------------------------------------------------------- host messages

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { log('unparseable message', 'bad'); return; }
    }
    if (!msg || typeof msg.type !== 'string') return;

    switch (msg.type) {
      case 'life.init':      return onInit(msg);
      case 'life.pause':     return onLife('pause', function () { state.lifecycle = 'Suspended'; stopLoop(); });
      case 'life.resume':    return onLife('resume', function () { state.lifecycle = 'Running'; startLoop(); });
      case 'life.destroy':   return onLife('destroy', function () { state.lifecycle = 'Destroyed'; });
      case 'life.resize':
        // Deliberately does not change lifecycle. A resolution change must never wake a scene
        // that a fullscreen game paused.
        return onLife('resize', function () { if (msg.display) state.display = msg.display; });
      case 'env.tick':       return onTick(msg);
      case 'env.state':      return onState(msg);
      case 'rt.performance': return onPerformance(msg);
      default:
        // Unknown types are ignored on purpose: it is what lets the host add signals without a
        // coordinated release of every existing scene.
        log('ignored unknown type ' + msg.type, 'warn');
    }
  }

  function onInit(msg) {
    state.initReceived = true;
    state.lifecycle = 'Running';
    state.luminaVersion = (msg.lumina && msg.lumina.version) || '?';
    state.sceneId = (msg.scene && msg.scene.id) || '?';
    state.display = msg.display || null;
    if (msg.performance) state.performance = msg.performance;

    // Read the negotiated set, not what scene.json asked for. The host is allowed to serve less.
    state.negotiated = msg.signals || {};
    var requested = ['clock', 'sun', 'season', 'display', 'cursor', 'weather', 'climate', 'audio'];
    var declined = requested.filter(function (s) { return !(s in state.negotiated); });

    log('life.init  lumina ' + state.luminaVersion + '  schema ' + (msg.scene && msg.scene.schema), 'life');
    log('  negotiated: ' + JSON.stringify(state.negotiated));
    if (declined.length) log('  declined: ' + declined.join(', '), 'warn');

    markLife('init');
    host.post({ v: SCHEMA, type: 'ready', sceneId: state.sceneId, renderer: '2d canvas' });
  }

  function onLife(name, apply) {
    apply();
    markLife(name);
    log('life.' + name + ' -> ' + state.lifecycle, 'life');
  }

  function markLife(name) {
    state.lastLife = name;
    state.lastLifeAt = performance.now();
  }

  // Counts what actually arrived, so the host can assert on delivery instead of someone having
  // to read a wallpaper off a screenshot.
  var seen = {
    'env.tick': 0, 'env.state': 0, cursor: 0, clock: 0, sun: 0, season: 0,
    weather: 0, climate: 0, audio: 0
  };

  function onTick(msg) {
    seen['env.tick']++;
    if (msg.cursor) { state.cursor = msg.cursor; seen.cursor++; }
    if (msg.audio) { state.audio = msg.audio; seen.audio++; }
  }

  function onState(msg) {
    // Partial by design: only keys that actually changed are present.
    seen['env.state']++;
    if (msg.clock) { state.clock = msg.clock; seen.clock++; }
    if (msg.sun) { state.sun = msg.sun; seen.sun++; }
    if (msg.season) { state.season = msg.season; seen.season++; }
    if (msg.weather) { state.weather = msg.weather; seen.weather++; }
    if (msg.climate) { state.climate = msg.climate; seen.climate++; }
    if (msg.display) state.display = msg.display;
    log('env.state ' + Object.keys(msg).filter(function (k) {
      return k !== 'v' && k !== 'type';
    }).join(', '));
  }

  function onPerformance(msg) {
    state.performance = msg;
    log('rt.performance tier=' + msg.tier + ' maxFps=' + msg.maxFps, 'life');
  }

  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) { onMessage(e.data); });
  }

  // ------------------------------------------------------------------- fps

  var stamps = [];
  var frames = 0;
  var lastBeat = performance.now();

  // Raw requestAnimationFrame cadence, tracked separately from the rate we actually render at.
  // They are not the same number and scene authors need to see both: a frame cap can only ever
  // land on a subharmonic of the rAF clock, and the rAF clock is not necessarily this display's
  // refresh rate.
  var rafStamps = [];

  function fpsStats(now) {
    while (stamps.length && now - stamps[0] > 5000) stamps.shift();
    if (stamps.length < 3) return { fps: 0, floor: 0 };
    var worst = 0;
    for (var i = 1; i < stamps.length; i++) worst = Math.max(worst, stamps[i] - stamps[i - 1]);
    var span = (stamps[stamps.length - 1] - stamps[0]) / 1000;
    return { fps: span > 0 ? (stamps.length - 1) / span : 0, floor: worst > 0 ? 1000 / worst : 0 };
  }

  // --------------------------------------------------------------- rendering

  function resize() {
    var w = Math.max(16, canvas.clientWidth);
    var h = Math.max(16, canvas.clientHeight);
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  }

  function draw(now) {
    resize();
    var w = canvas.width, h = canvas.height;
    var t = now / 1000;

    ctx.fillStyle = '#05060a';
    ctx.fillRect(0, 0, w, h);

    // Moving bands, purely so that a stalled render loop is obvious at a glance rather than
    // having to be read off the fps counter.
    for (var i = 0; i < 7; i++) {
      var p = (t * 0.06 + i / 7) % 1;
      ctx.fillStyle = 'rgba(80, 150, 255, ' + (0.05 + 0.03 * Math.sin(t + i)).toFixed(3) + ')';
      ctx.fillRect(0, p * h, w, h * 0.05);
    }

    // Cursor puck, so the cursor signal can be verified without reading numbers.
    if (state.cursor && state.cursor.onDisplay) {
      var cx = state.cursor.x * w, cy = state.cursor.y * h;
      var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 160);
      g.addColorStop(0, 'rgba(110, 231, 255, 0.35)');
      g.addColorStop(1, 'rgba(110, 231, 255, 0)');
      ctx.fillStyle = g;
      ctx.fillRect(cx - 160, cy - 160, 320, 320);
    }

    // Spectrum, for the same reason as the cursor puck: whether the bands are log-spaced and
    // whether silence detection actually fires are both obvious on sight and tedious to read off
    // sixteen numbers. Drawn greyed rather than hidden when inactive, so "silent" and "no signal
    // at all" stay distinguishable.
    if (state.audio && state.audio.bands) {
      var bands = state.audio.bands;
      var barW = w / bands.length;
      ctx.fillStyle = state.audio.active
        ? 'rgba(110, 231, 255, 0.55)'
        : 'rgba(110, 231, 255, 0.12)';

      for (var b = 0; b < bands.length; b++) {
        var barH = bands[b] * h * 0.3;
        ctx.fillRect(b * barW + 2, h - barH, barW - 4, barH);
      }
    }
  }

  function pad(label) { return (label + '          ').substr(0, 12); }

  function describeDisplay(d) {
    if (!d) return 'unknown';
    return d.id + '  ' + d.width + 'x' + d.height +
      (d.refreshRate ? ' @' + d.refreshRate + 'Hz' : '') +
      (d.scale ? '  scale ' + d.scale : '') +
      (d.primary ? '  primary' : '');
  }

  function elapsed(ms) {
    var s = Math.floor(ms / 1000);
    return '+' + String(Math.floor(s / 3600)).padStart(2, '0') + ':' +
      String(Math.floor(s / 60) % 60).padStart(2, '0') + ':' +
      String(s % 60).padStart(2, '0');
  }

  function renderPanel(now, stats) {
    var c = state.cursor;
    var lines = [
      'Lumina Scene Runtime',
      '--------------------',
      pad('State:') + state.lifecycle,
      pad('Display:') + describeDisplay(state.display),
      pad('FPS:') + stats.fps.toFixed(1) + '   floor ' + stats.floor.toFixed(1) +
        '   cap ' + state.performance.maxFps + '   rAF ' + rafHz().toFixed(1) + 'Hz',
      pad('Tier:') + state.performance.tier + '   target ' + state.performance.targetFps,
      pad('Cursor:') + (c ? c.x.toFixed(2) + ', ' + c.y.toFixed(2) +
        (c.onDisplay ? '  (on display)' : '  (off display)') : 'no signal'),
      pad('Clock:') + (state.clock ? state.clock.iso : 'no signal'),
      pad('Sun:') + (state.sun
        ? Math.round(state.sun.elevation) + ' deg elev, ' + Math.round(state.sun.azimuth) +
          ' deg az, ' + state.sun.phase
        : 'no signal'),
      pad('Season:') + (state.season
        ? state.season.season + ', ' + state.season.hemisphere + 'ern hemisphere, day ' +
          state.season.dayOfYear
        : 'no signal'),
      // Peak band as well as loudness: rms alone cannot tell a working spectrum from sixteen
      // zeroes, and those are very different failures.
      pad('Audio:') + (state.audio ? (state.audio.active
        ? 'active  rms ' + state.audio.rms.toFixed(2) +
          '  peak band ' + Math.max.apply(null, state.audio.bands || [0]).toFixed(2) +
          ' of ' + (state.audio.bands || []).length
        : 'inactive') : 'no signal'),
      pad('Weather:') + (state.weather
        ? (state.weather.available
          ? state.weather.temperature + 'C  precip ' + state.weather.precipitation +
            (state.weather.stale ? '  (stale)' : '')
          : 'unavailable')
        : 'no signal'),
      // Reports source explicitly, because the one thing a scene author must not miss about this
      // signal is that nobody measured it.
      pad('Climate:') + (state.climate
        ? state.climate.band + ', ' + state.climate.source + '  ' +
          state.climate.temperature + 'C  cloud ' + state.climate.cloudCover +
          '  ' + state.climate.precipitationType + ' ' + state.climate.precipitation +
          '  wind ' + state.climate.wind + '  fog ' + state.climate.fog
        : 'no signal'),
      pad('Lumina:') + state.luminaVersion + '    schema ' + SCHEMA,
      pad('Signals:') + (state.negotiated
        ? Object.keys(state.negotiated).map(function (k) { return k + ':' + state.negotiated[k]; }).join(' ')
        : 'not negotiated'),
      pad('Last life:') + state.lastLife + '  ' + elapsed(now - state.lastLifeAt)
    ];
    statePanel.textContent = lines.join('\n');
  }

  // ------------------------------------------------------------- frame loop

  var lastFrame = 0;
  var lastAudit = 0;
  var rafHandle = 0;

  // Stopping the loop on life.pause is required of every scene, not a nicety of this one. The
  // host leaves the surface visible so the last frame stays on screen, and suspends any scene
  // whose heartbeats keep arriving after the pause.
  function startLoop() {
    if (!rafHandle) rafHandle = requestAnimationFrame(loop);
  }

  function stopLoop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);

    rafStamps.push(now);
    while (rafStamps.length && now - rafStamps[0] > 5000) rafStamps.shift();

    // Honour the host's frame cap. This is mandatory, not advisory: nothing else in the stack
    // limits a wallpaper's frame rate, and Phase 0 measured a scene accelerating to the panel's
    // refresh rate the moment it became occluded. requestAnimationFrame is not a frame limiter.
    var maxFps = state.performance.maxFps || 60;
    if (now - lastFrame < 1000 / maxFps - 0.5) return;
    lastFrame = now;

    stamps.push(now);
    frames++;
    draw(now);

    if (now - lastBeat >= 1000) {
      lastBeat = now;
      var stats = fpsStats(now);
      renderPanel(now, stats);
      host.post({
        v: SCHEMA, type: 'heartbeat',
        fps: stats.fps, fpsFloor: stats.floor, frames: frames, rafHz: rafHz()
      });
    }

    if (now - lastAudit >= 10000) {
      lastAudit = now;
      host.post({ v: SCHEMA, type: 'contract.audit', seen: seen, rafHz: rafHz(), fps: fpsStats(now).fps });
    }
  }

  function rafHz() {
    if (rafStamps.length < 3) return 0;
    var span = (rafStamps[rafStamps.length - 1] - rafStamps[0]) / 1000;
    return span > 0 ? (rafStamps.length - 1) / span : 0;
  }

  window.addEventListener('error', function (e) {
    log('ERROR ' + e.message, 'bad');
    host.post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });

  log('scene loaded, waiting for life.init');

  // A host that never sends life.init is a contract break, and saying so beats rendering a
  // plausible-looking panel full of "no signal".
  setTimeout(function () {
    if (!state.initReceived) {
      log('no life.init after 5s - host contract break', 'bad');
      host.post({ v: SCHEMA, type: 'error', message: 'no life.init received within 5s', fatal: false });
    }
  }, 5000);

  startLoop();
})();
