# Wave Drift

A living range rather than a looping clip. Version 1.5.4.

Canvas2D on purpose: layered aurora curtains, glow, stars, weather, and a forest that grows, at a wallpaper frame rate and with no image assets.

## What you see

- Aurora curtains over a mountain range. The palette stays green and cyan, with violet on the upper edges.
- Grass, rain, autumn, and snow turn with the season. Forests and lights gather over years.
- The pointer can pull the waves, part them, or be ignored. Audio can drive the curtains; without it they drift on their own.

## How time works

On the Live dial, day and night stay on the wall clock. Grass, forests, and seasons advance at twelve world days per real day. One world day per real day left a week of ownership looking still, so ecology runs faster than the sun.

Rates above Live replace both clocks. Those rates are the developer world-evolution dial (one day per hour, per minute, per 10 seconds, or per 2 seconds).

The world is an epoch and a seed in `localStorage` (`lumina.world.wavedrift`). Age is a pure function of that pair, so two displays agree, a paused display rejoins, and a restart continues the same world. A cleared WebView2 profile starts the world over. Schema 1 has no channel for the scene to store that pair in the host.

## Desktop, not a single screen

Positions use virtual-desktop pixels and a shared clock. A wave is sized against a nominal 1920 px span, never against whichever monitor happens to be drawing it, so the picture continues across a seam.
