# Aurora Drift — Updated

This replaces the original accent-streak/bloom implementation with an actual procedural aurora borealis.

## Visual structure
- Deep polar-night sky
- 220 twinkling stars
- Broad atmospheric aurora glow
- 11 independent translucent aurora curtains
- Multiple harmonic folds per curtain
- Narrow luminous vertical folds/rays
- Stronger violet/pink upper-edge coloration
- Green/cyan dominant lower curtains
- Subtle drifting auroral particles
- Dark distant horizon/treeline for scale

The animation is deliberately slow and continuous. It should read as northern lights rather than ribbons or diagonal streaks.

## Colour changes
The palette changes automatically at irregular intervals:
- First transition after roughly 33–55 seconds.
- Subsequent transitions roughly every 30–80 seconds.
- Transitions are interpolated rather than hard-switched.
- Green/cyan remain dominant, while violet/magenta variations appear as alternate auroral conditions.

## Lumina
The existing lifecycle contract is preserved:
`life.init`, `life.pause`, `life.resume`, `life.resize`, `life.destroy`, `rt.performance`

The scene emits the same `ready`, `heartbeat`, and `error` messages.

No network access, CDN, image assets, fonts, or external dependencies are used.
