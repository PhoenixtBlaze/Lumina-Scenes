// Wave Drift - aurora curtains over a layered range, for Lumina.
//
// Canvas2D is intentional: the scene stays lightweight while using layered curtain geometry,
// additive blending, atmospheric glow and star depth. No network or external assets.
//
// The organising idea is that this scene does not live on a display, it lives on the desktop.
// Every position and every phase is computed in virtual-desktop pixels from a clock shared by all
// instances, so two screens running it are two windows onto one continuous picture rather than two
// copies of the same animation. Anything that breaks that - a random seed, a per-instance elapsed
// counter, a coordinate normalized against one screen - shows up immediately as a seam.
//
// Signals are optional by contract and each has a defined look when it never arrives: no cursor
// means no pointer response, no audio means the curtains drift on their own.
(function () {
  'use strict';

  var SCHEMA = 1;
  var canvas = document.getElementById('scene');
  var ctx = canvas.getContext('2d', { alpha: false });
  var sceneId = document.body.dataset.sceneId || 'wavedrift';

  // Feature sizes are expressed against this nominal width in desktop pixels, never against the
  // display's own width. A wave has to be the same wave on both sides of a seam, which it cannot
  // be if its wavelength is "one twentieth of whichever screen it happens to be drawn on".
  var SPAN = 1920;

  // A fixed recent epoch. Date.now() is identical in every instance on the machine, which is what
  // makes it the shared timeline; subtracting an epoch just keeps the numbers small enough to read
  // in a log.
  var EPOCH = Date.UTC(2026, 0, 1);

  var width = 0, height = 0, dpr = 1;
  var maxFps = 30;
  var rafHandle = 0, lastFrame = 0, lastBeat = 0;
  var beatFrames = 0, frames = 0;
  var stamps = [];               // rendered-frame times since the last heartbeat

  // Where this display sits on the virtual desktop, from life.init. Origin and 1:1 until told
  // otherwise, which is exactly right for the single-display case.
  var originX = 0, originY = 0, pxPerCss = 1;

  // ------------------------------------------------------------------ options

  var CURSOR_ATTRACT = 'attract', CURSOR_REPEL = 'repel', CURSOR_OFF = 'off';
  var cursorMotion = CURSOR_ATTRACT;
  var audioReactive = true;
  // When false the sun stays put: fixedSky picks noon or midnight so a wallpaper can be forever
  // day or forever night without the aurora and the rock trading places every few minutes.
  var dayNightCycle = true;
  var fixedSky = 'day';

  // The mode as the renderer sees it: two weights that ease toward the chosen one rather than a
  // string that is tested per frame.
  //
  // Branching on the string directly is what made switching modes snap. Attract and repel displace
  // a curtain by comparable amounts in opposite directions, and off displaces it not at all, so
  // every switch was an instantaneous jump of the full displacement. Crossfading the weights means
  // one influence withdraws as the other arrives and the curtain is never asked to be in two
  // places at once.
  var attractMix = 1, repelMix = 0;
  var modeSettled = false;       // first life.init snaps these; later changes ease

  // -------------------------------------------------------------------- state

  // Targets are what the host last said and rendered values chase them. The cursor arrives in
  // 30Hz steps and audio in 16 bands per tick; stepping a visual straight to a new value makes a
  // wallpaper twitch, which is the one thing it must never do.
  var cursor = { x: 0.5, y: 0.5 };
  var cursorTarget = { x: 0.5, y: 0.5 };
  var presence = 0, presenceTarget = 0;
  var energy = 0, energyTarget = 0;

  var BAND_COUNT = 16;
  var level = 0, levelTarget = 0;          // overall loudness
  var bass = 0, bassTarget = 0;
  var treble = 0, trebleTarget = 0;
  var pulse = 0, bassAverage = 0;          // beat onset, and the mean it is measured against

  // A boreal-night palette. Aurora is normally green/cyan dominant, with violet/pink appearing in
  // stronger upper and edge structures.
  var palettes = [
    { a: [38, 255, 164], b: [52, 205, 255], c: [151, 78, 255] },
    { a: [74, 255, 128], b: [28, 224, 222], c: [208, 72, 255] },
    { a: [40, 239, 190], b: [98, 255, 118], c: [173, 100, 255] },
    { a: [28, 220, 255], b: [70, 255, 169], c: [255, 91, 214] }
  ];
  // Five minutes. A minute-long era reads as a scene that changes colour; at this length the
  // palette is never seen to move, which is the only way a colour shift stays part of the weather
  // rather than becoming an event.
  var PALETTE_ERA = 300000;      // ms one full palette cycle takes, hold plus crossfade
  var PALETTE_HOLD = 0.45;       // fraction of the era at rest before the crossfade begins

  var bands = [];
  var particles = [];
  var clouds = [];
  var trees = [];
  var meadows = [];
  var precip = [];
  var hamlets = [];
  var lifeSeed = -1;             // worldSeed trees/hamlets were generated for
  var precipSeed = -1;

  // World-derived render state, recomputed once per frame so the drawing routines stay pure
  // functions of it rather than each recomputing the world's age for themselves.
  var auroraGain = 1;            // fade-in for the newest band in the set
  var auroraDetail = 0;          // 0..1, how elaborate the aurora has become
  var auroraStorm = 0;           // 0..1, a storm in progress
  var starVisibility = 1;        // how much of the star field the cloud is leaving
  var sunAlt = -1;               // -1 at midnight, +1 at noon
  var nightness = 1;             // 1 at night, 0 in daylight
  var dayFrac = 0;               // 0..1 through the world day, same clock as the sun
  var worldGrowth = 0;           // 0..1 across the world's first year
  var stormNow = null;           // the storm in progress, with its own colour
  var visibleImpacts = [];       // craters close enough to this screen to shape its crest

  var BAND_TOTAL = 18;           // every band the aurora will ever have
  var BAND_AT_BIRTH = 3;         // how many of them are out on day one
  var BAND_AT_DEFAULT = 11;      // the count Wave Drift used to ship with, reached at two months
  var CLOUD_CELLS = 14;
  var CLOUD_WRAP = 0;            // set once SPAN is known, below

  // Far wider than any desktop, so motes have global positions that wrap somewhere nobody is
  // looking rather than at the edge of a screen.
  var PARTICLE_WRAP = SPAN * 8;
  CLOUD_WRAP = SPAN * 6;

  // ----------------------------------------------------------------- plumbing

  function post(message) {
    if (window.chrome && window.chrome.webview) {
      window.chrome.webview.postMessage(message);
    }
  }

  function rgba(c, a) {
    return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' +
      Math.round(c[2]) + ',' + a + ')';
  }

  function lerp(a, b, t) { return a + (b - a) * t; }

  function mixColor(a, b, t) {
    return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
  }

  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

  /** Always-positive modulo. JS % keeps the sign of the dividend, and desktop x can be negative. */
  function mod(v, n) { return ((v % n) + n) % n; }

  function smoothstep(v) { v = clamp01(v); return v * v * (3 - 2 * v); }

  // Frame-rate independent easing. A plain lerp per frame eases at a different speed at 30fps than
  // at 60, and the host changes the cap at runtime whenever the performance tier moves.
  function approach(current, target, rate, dt) {
    return current + (target - current) * (1 - Math.exp(-rate * dt));
  }

  // Mulberry32. Every instance must generate the identical field, so the one thing this scene can
  // never use is Math.random(): two displays seeded differently produce two different auroras that
  // happen to sit next to each other.
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  // ---------------------------------------------------------------- the world

  /**
   * Wave Drift is a world rather than a loop: it has an age, and what it looks like depends on
   * how old it is. A viewer who leaves it installed should catch themselves wondering whether
   * something was always there.
   *
   * The whole of that memory is two numbers - when the world began, and its seed. Everything
   * else, from the moon's phase to how many stars are out to whether it is clouding over, is a
   * pure function of the age those two produce. That is the same rule the scene already follows
   * for desktop x, and it buys the same things: two displays agree without talking to each other,
   * a paused display rejoins where the other got to, and a restart resumes the world instead of
   * starting a new one.
   *
   * The pair lives in localStorage, which for a scene means the WebView2 profile Lumina keeps in
   * LocalAppData. Storing it host-side would survive more (a cleared profile starts the world
   * over) but there is no scene-to-host channel in schema 1 that could write it back, so this is
   * the honest version of persistence available to a scene today.
   */
  var DAY_MS = 86400000;
  var WORLD_KEY = 'lumina.world.wavedrift';

  // Re-read cadence. Two displays that both find no stored world on a first ever run each write
  // their own; whichever landed last is the one on disk, and this is how the other one finds out
  // rather than staying a fraction of a day apart forever. At the fastest test rate a fraction of
  // a day is visible, which is the only reason it matters at all.
  var WORLD_SYNC_MS = 2000;

  var worldEpoch = 0;            // wall-clock ms at which this world began
  var worldSeed = 0x5CE7E;       // per-install seed, so two people's worlds differ
  var worldDays = 0;             // age in world days, recomputed every frame
  var lastWorldSync = 0;

  // The dial. Live is the real thing: one world day per real day. The rest exist so a whole
  // month of evolution can be watched from the library card in a couple of minutes.
  var SPEEDS = { live: 1, hour: 24, minute: 1440, fast: 8640, warp: 43200 };
  var evolutionRate = 1;

  function loadWorld() {
    var stored = readWorld();
    if (stored) {
      worldEpoch = stored.epoch;
      worldSeed = stored.seed;
      anchorDay();
      return;
    }

    // Quantized to the minute so two instances starting seconds apart on a first ever run agree
    // on the world's birthday instead of each inventing one a few hundred milliseconds off.
    worldEpoch = Math.floor(Date.now() / 60000) * 60000;
    worldSeed = (Math.imul(worldEpoch >>> 9, 0x9E3779B1) ^ 0x5CE7E) >>> 0;
    writeWorld();
    anchorDay();
  }

  /** Where in a local day the world was born, so the live rate keeps night at night. */
  function anchorDay() {
    var d = new Date(worldEpoch);
    epochDayOffset = ((d.getHours() * 60 + d.getMinutes()) * 60 + d.getSeconds()) * 1000;
  }

  function readWorld() {
    try {
      var raw = window.localStorage.getItem(WORLD_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed.epoch !== 'number' || !isFinite(parsed.epoch)) return null;
      return { epoch: parsed.epoch, seed: (parsed.seed >>> 0) || 0x5CE7E };
    } catch (e) {
      // Storage disabled or full. The world then lasts as long as the process, which is a worse
      // scene rather than a broken one.
      return null;
    }
  }

  function writeWorld() {
    try {
      window.localStorage.setItem(WORLD_KEY, JSON.stringify({ epoch: worldEpoch, seed: worldSeed }));
    } catch (e) {
      /* storage unavailable */
    }
  }

  /** Adopts whatever the other instance stored, so the two converge within a couple of seconds. */
  function syncWorld(wall) {
    if (wall - lastWorldSync < WORLD_SYNC_MS) return;
    lastWorldSync = wall;

    var stored = readWorld();
    if (stored && stored.epoch !== worldEpoch) {
      worldEpoch = stored.epoch;
      worldSeed = stored.seed;
      impactsKey = -1;
      lifeSeed = -1;
      anchorDay();
    }
  }

  function ageInDays(wall) {
    return Math.max(0, (wall - worldEpoch) * evolutionRate / DAY_MS);
  }

  /**
   * The evolution timeline.
   *
   * Two months is the point at which the world has grown into the scene Wave Drift used to be on
   * install - the same aurora, the same sky. A year is the point at which it is fully grown, and
   * after that only its weather, its moon and the things that happen to it keep moving. Every
   * curve in this file is expressed against these two numbers so the whole world matures together
   * rather than each piece arriving on its own schedule.
   */
  var EVOLVE_DEFAULT = 60;
  var EVOLVE_FULL = 365;

  /** 0 on the day the world begins, 1 once it is fully grown. */
  function growth(days) { return smoothstep(days / EVOLVE_FULL); }

  // ------------------------------------------------------------- day and night

  // Milliseconds from local midnight to the moment the world began. Holding this means the world
  // clock can run at any rate and still line up with the wall clock at the live one: a viewer
  // running Wave Drift normally gets night at night, and the dial spins whole days past.
  var epochDayOffset = 0;

  function dayFraction(wall) {
    if (!dayNightCycle) {
      // Noon for day, midnight for night. Matches sunHeight's -cos curve.
      return fixedSky === 'night' ? 0 : 0.5;
    }
    return mod((epochDayOffset + (wall - worldEpoch) * evolutionRate) / DAY_MS, 1);
  }

  /** -1 at midnight, +1 at noon. Not an ephemeris, just the shape of a day. */
  function sunHeight(frac) { return -Math.cos(frac * Math.PI * 2); }

  /**
   * How cloudy the world is, as a smooth function of its age.
   *
   * Clouds are not an event that comes and goes evenly: a young world is clear and gets the odd
   * passing cloud, and an older one has a sky that is usually covered, with the clear nights
   * being the thing worth noticing. So the cover is a floor that rises over the first month with
   * a swing on top of it, rather than a swing around a fixed mean.
   *
   * Sines at unrelated periods rather than noise, because a front has to arrive and leave over
   * days identically on every display and across a restart, which rules out anything that steps a
   * random walk forward per frame.
   */
  /**
   * A year on this range, as continuous seasonal weights.
   *
   * Wallpaper distance cannot carry calendar text, so the year has to be readable as colour and
   * weather: grass filling the low ground, rain in the mild seasons, snow in the air and on the
   * rock, and canopies that go green then gold then bare. Weights blend rather than snap, so a
   * warp run shows autumn arriving rather than flipping a palette.
   */
  var YEAR_DAYS = 365;

  function seasonWeight(phase, center, halfWidth) {
    var d = Math.abs(phase - center);
    d = Math.min(d, 1 - d);
    return clamp01(1 - d / halfWidth);
  }

  function seasonAt(days) {
    // Phase 0 ≈ early spring. A world born in spring gets grass before it gets snow, which is the
    // order that sells "life arriving" on a fresh install.
    var phase = mod(days / YEAR_DAYS, 1);
    var spring = seasonWeight(phase, 0.18, 0.20);
    var summer = seasonWeight(phase, 0.42, 0.20);
    var autumn = seasonWeight(phase, 0.68, 0.20);
    var winter = seasonWeight(phase, 0.92, 0.22);
    var sum = spring + summer + autumn + winter;
    if (sum > 0.001) {
      spring /= sum; summer /= sum; autumn /= sum; winter /= sum;
    }

    // How alive the low ground is. Winter barely holds a tint; summer is a full meadow.
    var grass = spring * 0.72 + summer * 1.0 + autumn * 0.38 + winter * 0.04;
    // Snow on the rock and in the air. Autumn gets a first dusting on the peaks only via snowAt.
    var snowCover = winter * 0.95 + autumn * 0.12 + spring * 0.08;
    // Rain wants cloud; snow can fall from a thinner overcast.
    var rainWish = spring * 0.85 + summer * 0.28 + autumn * 0.70 + winter * 0.05;
    var snowWish = winter * 0.95 + lateAutumnDust(autumn);

    // Canopy colours the forest reads as. Weighted by season so autumn gold and winter bare
    // arrive as a drift rather than a palette swap on one day.
    var foliage = [
      Math.round(52 * spring + 34 * summer + 168 * autumn + 198 * winter),
      Math.round(98 * spring + 112 * summer + 86 * autumn + 206 * winter),
      Math.round(54 * spring + 48 * summer + 30 * autumn + 216 * winter)
    ];
    // Ground cover wet-season green, dry-summer olive, autumn straw, winter frost.
    var turf = [
      Math.round(40 * spring + 48 * summer + 110 * autumn + 186 * winter),
      Math.round(92 * spring + 118 * summer + 78 * autumn + 196 * winter),
      Math.round(44 * spring + 52 * summer + 28 * autumn + 208 * winter)
    ];

    return {
      phase: phase,
      spring: spring,
      summer: summer,
      autumn: autumn,
      winter: winter,
      grass: grass,
      snowCover: snowCover,
      rainWish: rainWish,
      snowWish: snowWish,
      foliage: foliage,
      turf: turf,
      // Bare deciduous fraction: winter and late autumn drop leaves.
      bare: clamp01(winter * 0.9 + autumn * 0.35)
    };
  }

  function lateAutumnDust(autumn) {
    return autumn * 0.25;
  }

  function weatherAt(days) {
    var s = (worldSeed % 100000) * 1e-5;
    var season = seasonAt(days);

    var settled = smoothstep((days - 2) / 26);

    var swing = 0.5 +
      0.28 * Math.sin(days * 0.37 + s) +
      0.14 * Math.sin(days * 0.11 + s * 2.3 + 1.7) +
      0.08 * Math.sin(days * 1.70 + s * 0.7 + 4.1);

    // A young world still carries weather. The old floor (swing - 0.58) left most of the first
    // weeks as empty blue sky, which is exactly when daytime looked like "only the sun".
    var cloud = clamp01(lerp(0.22 + swing * 0.55, 0.44 + swing * 0.52, settled));

    // The rare, genuinely clear spell. Long period and a high threshold, so a settled world gets
    // one every few weeks and it is a change worth seeing rather than the resting state.
    var clearing = clamp01((Math.sin(days * 0.053 + s * 5.1) - 0.84) * 8);
    cloud *= 1 - clearing * 0.94;

    // Mild seasons carry more overcast; midsummer and deep clear winter nights open up.
    cloud = clamp01(cloud * (0.72 + season.spring * 0.35 + season.autumn * 0.4 +
      season.summer * 0.1 + season.winter * 0.25));

    var rain = clamp01(season.rainWish * (0.25 + cloud * 0.9));
    var snowfall = clamp01(season.snowWish * (0.35 + cloud * 0.75));
    // Prefer one precip type so the air does not read as grey static.
    if (snowfall > rain) rain *= 0.15;
    else snowfall *= 0.2;

    return {
      cloud: cloud,
      clearing: clearing,
      rain: rain,
      snowfall: snowfall,
      season: season
    };
  }

  /**
   * Aurora storms, which are the world's weather for the sky rather than for the ground.
   *
   * Every storm has a colour of its own. A storm that is only a brighter version of the ordinary
   * aurora is not an event, it is a volume knob, so the palette leans hard toward the storm's own
   * tint for as long as it lasts and the whole sky changes character.
   */
  var STORM_TINTS = [
    { a: [255, 88, 96], b: [255, 150, 112], c: [216, 64, 150] },   // crimson
    { a: [176, 104, 255], b: [122, 138, 255], c: [236, 110, 255] }, // violet
    { a: [62, 255, 150], b: [132, 255, 198], c: [40, 220, 255] },   // emerald
    { a: [190, 240, 255], b: [132, 206, 255], c: [96, 160, 255] },  // ice
    { a: [255, 170, 74], b: [255, 120, 86], c: [255, 92, 148] }     // ember
  ];

  var STORM_PERIOD = 4.1;        // world days per storm window

  function stormAt(days) {
    if (days < 2.5) return null;

    var index = Math.floor(days / STORM_PERIOD);
    var r = rng(0x570A3 ^ Math.imul(index + 1, 0x9E3779B1) ^ worldSeed);

    // A young world storms occasionally; a grown one storms most windows. The roll comes first so
    // that every later draw from this generator belongs to a storm that is actually happening.
    if (r() > 0.32 + 0.5 * growth(days)) return null;

    var span = 0.4 + r() * 0.7;
    var start = r() * Math.max(0.1, STORM_PERIOD - span);
    var local = days - index * STORM_PERIOD - start;
    if (local < 0 || local > span) return null;

    var tint = STORM_TINTS[Math.floor(r() * STORM_TINTS.length) % STORM_TINTS.length];
    return {
      strength: Math.sin(local / span * Math.PI) * (0.6 + 0.4 * r()),
      tint: tint
    };
  }

  /**
   * Meteor shower strength, 0 outside one.
   *
   * On a period that is not a whole number of days, so a shower never settles into the same hour
   * of the evening and a viewer cannot learn when to look.
   */
  var SHOWER_PERIOD = 6.4;
  var SHOWER_WIDTH = 0.07;

  function showerAt(days) {
    if (days < 3) return 0;
    var phase = mod(days, SHOWER_PERIOD) / SHOWER_PERIOD;
    if (phase > SHOWER_WIDTH) return 0;
    return Math.sin(phase / SHOWER_WIDTH * Math.PI) * (0.45 + 0.55 * growth(days));
  }

  /**
   * The strikes this world has taken, as a pure function of its age.
   *
   * A meteor that only streaks past is weather. One that lands is history: it leaves a crater in
   * the range that is still there a year later, which is the difference between a world that
   * animates and a world that has happened to something. A comet is the rare one - a few hundred
   * pixels of new landscape and a glow in the sky for weeks afterwards.
   */
  var IMPACT_PERIOD = 6.8;       // world days per candidate strike
  var IMPACT_ERODE = 150;        // world days for a crater to weather back flat
  var IMPACT_WINDOW = 40;        // candidates back far enough to cover that erosion
  var impacts = [];
  var impactsKey = -1;

  /**
   * Only the recent candidates are considered, and a crater weathers away over a few months.
   *
   * Both of those are the same decision. A world that keeps every scar it ever took ends up as a
   * list that grows with its age - which at the dial's faster rates means hundreds of thousands
   * of entries, a crest summed from all of them, and a range that sinks off the bottom of the
   * screen. Erosion bounds the list and is also what ground actually does.
   */
  function refreshImpacts(days) {
    var last = Math.floor(days / IMPACT_PERIOD);
    if (last === impactsKey) return;
    impactsKey = last;

    var first = Math.max(0, last - IMPACT_WINDOW);
    var list = [];
    for (var i = first; i <= last; i++) {
      var r = rng(0x1A9AC7 ^ Math.imul(i + 1, 0x85EBCA6B) ^ worldSeed);
      if (r() > 0.28) continue;                 // enough landings that a year leaves a scarred range

      var at = (i + r()) * IMPACT_PERIOD;
      var comet = r() > 0.90;
      list.push({
        day: at,
        gx: (r() * 8 - 4) * SPAN,
        radius: comet ? 320 + r() * 220 : 70 + r() * 110,
        depth: comet ? 38 + r() * 22 : 14 + r() * 16,
        comet: comet
      });
    }

    impacts = list;
  }

  // ------------------------------------------------------- desktop coordinates

  /** A local CSS-pixel x as a position on the virtual desktop. */
  function gx(x) { return originX + x * pxPerCss; }

  /** The same, as a multiple of the nominal span, for phases written in screen-fractions. */
  function gn(x) { return gx(x) / SPAN; }

  // ------------------------------------------------------------------ palette

  /**
   * The palette is a pure function of the shared clock rather than a timer each instance runs for
   * itself. Two screens drifting to different colours is as visible a seam as a broken wave, and
   * a scheduled transition cannot stay in step across a pause on one display only.
   */
  function paletteAt(t) {
    var era = Math.floor(t / PALETTE_ERA);
    var f = t / PALETTE_ERA - era;

    var from = palettes[pick(era)];
    var to = palettes[pick(era + 1)];
    // Just under half the era at rest, then a crossfade over the rest of it. Spreading the change
    // across two and a half minutes puts the fastest channel under half an RGB step per second,
    // which is below what the eye picks up as movement.
    var blend = smoothstep((f - PALETTE_HOLD) / (1 - PALETTE_HOLD));

    return {
      a: mixColor(from.a, to.a, blend),
      b: mixColor(from.b, to.b, blend),
      c: mixColor(from.c, to.c, blend)
    };
  }

  function pick(era) {
    return Math.floor(rng(0xA0A0 ^ Math.imul(era, 0x9E3779B1))() * palettes.length) % palettes.length;
  }

  // --------------------------------------------------------------------- seed

  function seed() {
    var r = rng(0x5CE7E);

    // Every band the aurora will ever have is generated here, but only three of them are out on
    // day one. Generating the whole set up front is what keeps a band's shape from changing on
    // the day it appears: it was always this band, it just was not out yet.
    bands = [];
    for (var i = 0; i < BAND_TOTAL; i++) {
      bands.push({
        phase: r() * Math.PI * 2,
        speed: 0.00020 + r() * 0.00028,
        freq: (0.0015 + r() * 0.0020),
        amp: 35 + r() * 75,
        baseY: 0.27 + (i % 11) * 0.055 + r() * 0.06,
        width: 55 + r() * 95,
        alpha: 0.10 + r() * 0.095,
        skew: -0.12 + r() * 0.24,
        depth: (i % 11) / 10,
        // Which way this band leans off the shared palette. A young aurora with three bands is
        // essentially one colour; an old one with eighteen is several at once, because each band
        // leans further as the world grows.
        hue: r() * 2 - 1
      });
    }

    // Cloud cells. Each is a place in desktop space that clouds over and clears again on its own
    // cycle, so the sky is never uniformly overcast and never uniformly clear.
    clouds = [];
    for (var c = 0; c < CLOUD_CELLS; c++) {
      clouds.push({
        // Kept in the lower half of the sky, where the aurora glow is bright enough for a cloud
        // to read as something passing in front of it. Higher up there is nothing to occlude and
        // a dark shape on a dark sky is simply invisible.
        gx: r() * CLOUD_WRAP,
        y: 0.24 + r() * 0.38,
        rx: 320 + r() * 620,
        ry: 52 + r() * 92,
        drift: 0.0016 + r() * 0.0042,   // desktop px per ms
        lifeDays: 0.45 + r() * 1.6,
        lifePhase: r(),
        weight: 0.55 + r() * 0.45,
        puffs: [r(), r(), r()]
      });
    }

    // Motes wrap over a span far wider than any desktop, so their positions are global and
    // continuous without the scene needing to know how wide the desktop actually is.
    particles = [];
    for (var p = 0; p < 110; p++) {
      particles.push({
        gx: r() * PARTICLE_WRAP,
        y: 0.18 + r() * 0.62,
        speed: 0.004 + r() * 0.010,      // desktop px per ms
        phase: r() * Math.PI * 2,
        size: 0.5 + r() * 1.2,
        alpha: 0.15 + r() * 0.3
      });
    }

    // Living world features depend on worldSeed. Regenerated when the seed changes so two
    // displays and a restarted process keep the same forest and the same villages.
    lifeSeed = -1;
    precipSeed = -1;
    ensureLife();
    ensurePrecip();
  }

  /**
   * Trees and settlements as pure functions of worldSeed.
   *
   * Each feature has a bornDay so a warp run shows them arriving over time instead of everything
   * popping in when forestAt crosses a threshold. That is what makes thirty minutes of full speed
   * feel like a lifetime rather than a finished painting.
   */
  function ensureLife() {
    // lifeLayout bumps when the planted density changes so an old sparse forest does not stick
    // around after a scene update on the same worldSeed.
    var LIFE_LAYOUT = 3;
    if (lifeSeed === worldSeed && trees.length > 0 && meadows.length > 0 &&
        meadows[0].layout === LIFE_LAYOUT) return;
    lifeSeed = worldSeed;

    var r = rng(0x71FEE ^ worldSeed);
    trees = [];
    // Dense enough that a single monitor reads as a forest belt, not a thin scatter. Staggered
    // across years so warp still shows the slope filling rather than finishing in one stamp.
    for (var i = 0; i < 420; i++) {
      trees.push({
        gx: (r() * 12 - 6) * SPAN,
        // Wider band down the face so stands cover foothills through mid-slope, still off the snow.
        down: 0.012 + r() * 0.155,
        bornDay: 28 + r() * 640,
        growDays: 70 + r() * 140,
        maxH: 10 + r() * 24,
        lean: (r() - 0.5) * 0.35,
        fertile: 0.5 + r() * 0.5,
        // Deciduous stands carry autumn and winter bare; evergreens hold the slope year-round.
        deciduous: r() > 0.38,
        layout: LIFE_LAYOUT
      });
    }

    meadows = [];
    // Tuft anchors for grass on the lower face. Drawn as short blades, never filled discs -
    // ellipses read as weird coins on the rock at wallpaper distance.
    for (var m = 0; m < 340; m++) {
      meadows.push({
        gx: (r() * 12 - 6) * SPAN,
        down: 0.02 + r() * 0.22,
        bornDay: 4 + r() * 260,
        growDays: 28 + r() * 60,
        span: 18 + r() * 48,
        blades: 8 + Math.floor(r() * 14),
        fertile: 0.5 + r() * 0.5,
        phase: r() * Math.PI * 2,
        layout: LIFE_LAYOUT
      });
    }

    hamlets = [];
    // Valleys first (born earlier), then higher shelves. A world that sprouts five villages at
    // once does not read as civilization unfolding.
    var borns = [36, 72, 118, 175, 250, 340, 455, 580];
    for (var h = 0; h < borns.length; h++) {
      hamlets.push({
        gx: (r() * 7 - 3.5) * SPAN,
        down: 0.055 + r() * 0.07,
        bornDay: borns[h] + r() * 18,
        growDays: 40 + r() * 55,
        rooms: 2 + Math.floor(r() * 5),
        warmth: 0.55 + r() * 0.45,
        smoke: r() > 0.35
      });
    }
  }

  function ensurePrecip() {
    if (precipSeed === worldSeed && precip.length > 0) return;
    precipSeed = worldSeed;
    var r = rng(0xA17F ^ worldSeed);
    precip = [];
    for (var i = 0; i < 160; i++) {
      precip.push({
        gx: r() * PARTICLE_WRAP,
        y: r(),
        speed: 0.45 + r() * 1.1,
        drift: (r() - 0.5) * 0.35,
        size: 0.55 + r() * 1.5,
        phase: r()
      });
    }
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.max(1, Math.round(width * dpr));
    canvas.height = Math.max(1, Math.round(height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  /** Places this instance on the desktop from the display block of life.init or life.resize. */
  function placeOnDesktop(display) {
    if (!display) return;
    originX = typeof display.x === 'number' ? display.x : 0;
    originY = typeof display.y === 'number' ? display.y : 0;
    // Physical desktop pixels per CSS pixel. The host reports the display in physical pixels and
    // the canvas works in CSS ones, and on a scaled display those differ.
    pxPerCss = (typeof display.width === 'number' && width > 0) ? display.width / width : 1;
    if (!isFinite(pxPerCss) || pxPerCss <= 0) pxPerCss = 1;
    skyKey = '';
  }

  // ---------------------------------------------------------------------- sky

  // Two full-screen gradient fills for a picture that only changes as the palette drifts and the
  // sun moves. Cached to an offscreen canvas and repainted only when it has moved a visible
  // amount.
  var skyCanvas = null, skyCtx = null, skyKey = '';

  /**
   * The sky through a day, as keyframes the sun's height interpolates between.
   *
   * Written as three bands rather than a full atmospheric model: what a wallpaper needs from
   * dawn is that the horizon goes warm while the top of the screen is still dark, and that is a
   * gradient rather than a simulation.
   */
  var SKY_KEYS = [
    { alt: -1.00, top: [1, 3, 11], mid: [3, 11, 24], low: [7, 21, 37] },
    { alt: -0.22, top: [4, 8, 24], mid: [14, 20, 48], low: [40, 34, 64] },
    { alt: -0.06, top: [13, 20, 50], mid: [56, 46, 92], low: [148, 84, 88] },
    { alt: 0.06, top: [31, 62, 112], mid: [124, 112, 142], low: [232, 150, 100] },
    { alt: 0.30, top: [26, 78, 146], mid: [78, 146, 198], low: [176, 210, 230] },
    { alt: 1.00, top: [20, 82, 158], mid: [82, 158, 212], low: [196, 224, 238] }
  ];

  function skyBandsAt(alt) {
    var lo = SKY_KEYS[0];
    var hi = SKY_KEYS[SKY_KEYS.length - 1];

    for (var i = 0; i < SKY_KEYS.length - 1; i++) {
      if (alt >= SKY_KEYS[i].alt && alt <= SKY_KEYS[i + 1].alt) {
        lo = SKY_KEYS[i];
        hi = SKY_KEYS[i + 1];
        break;
      }
    }

    var f = hi.alt === lo.alt ? 0 : smoothstep((alt - lo.alt) / (hi.alt - lo.alt));
    return {
      top: mixColor(lo.top, hi.top, f),
      mid: mixColor(lo.mid, hi.mid, f),
      low: mixColor(lo.low, hi.low, f)
    };
  }

  function paintSky(p) {
    if (!skyCanvas) {
      skyCanvas = document.createElement('canvas');
      skyCtx = skyCanvas.getContext('2d', { alpha: false });
    }
    skyCanvas.width = canvas.width;
    skyCanvas.height = canvas.height;
    skyCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

    var bands = skyBandsAt(sunAlt);
    var g = skyCtx.createLinearGradient(0, 0, 0, height);
    g.addColorStop(0, rgba(bands.top, 1));
    g.addColorStop(0.5, rgba(bands.mid, 1));
    g.addColorStop(0.86, rgba(bands.low, 1));
    g.addColorStop(1, rgba(mixColor(bands.low, [2, 6, 13], 0.55), 1));
    skyCtx.fillStyle = g;
    skyCtx.fillRect(0, 0, width, height);

    // The broad atmospheric glow behind the curtains, as a purely vertical gradient, and only at
    // night: in daylight there is nothing for an aurora to glow against.
    //
    // It used to be a radial centred on the screen, which is a seam: two displays each get their
    // own blob, and the brightness steps where they meet. Centring it on the desktop instead would
    // mean knowing how wide the desktop is, which nothing tells the scene. Horizontally uniform is
    // continuous by construction and costs almost nothing here, because the horizontal variety in
    // this sky comes from the curtains rather than from the wash behind them.
    if (nightness > 0.02) {
      var glow = skyCtx.createLinearGradient(0, height * 0.12, 0, height * 0.95);
      glow.addColorStop(0, 'rgba(0,0,0,0)');
      glow.addColorStop(0.34, rgba(p.b, 0.030 * nightness));
      glow.addColorStop(0.62, rgba(p.a, 0.062 * nightness));
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      skyCtx.fillStyle = glow;
      skyCtx.fillRect(0, 0, width, height);
    }
  }

  function sky(t, p) {
    // Keyed on the colour it would paint, not on elapsed time. A time key repaints on a schedule
    // whether or not the palette moved, and each repaint jumps the sky by however far the colour
    // travelled in between - which is exactly the stepping that makes a slow crossfade look like
    // a series of small snaps. Keying on the rounded colour repaints only when a channel crosses
    // an integer, so every repaint is a one-unit change and no step is visible. The sun's height
    // is in the key at a resolution fine enough that a sunrise is smooth and coarse enough that
    // it is not a repaint per frame.
    // The sun's step is coarse on purpose. At the live rate a sunrise takes an hour of real time
    // and even this is a repaint every few seconds; at the dial's faster rates a finer step meant
    // repainting two full-screen gradients several times a second for a transition nobody could
    // see the individual steps of anyway.
    var key = rgba(p.a, 1) + rgba(p.b, 1) + Math.round(sunAlt * 90) +
      canvas.width + 'x' + canvas.height;
    if (key !== skyKey) {
      paintSky(p);
      skyKey = key;
    }
    ctx.drawImage(skyCanvas, 0, 0, width, height);
  }

  // -------------------------------------------------------------------- stars

  // Stars are generated per tile of desktop space rather than per display. A tile's contents
  // depend only on its index, so the instance on the right generates exactly the stars the
  // instance on the left would have drawn had its window extended that far.
  //
  // Nothing here reads the cursor. Stars are the fixed thing the moving things move against, and
  // a sky that reacts to the pointer stops reading as distance.
  var STAR_TILE = 480;
  var STARS_AT_BIRTH = 24;       // the sky a viewer meets on install
  var STARS_PER_TILE = 54;       // every star this tile will ever hold
  var STAR_FILL_DAYS = 110;      // how long the rest take to come out
  var starTiles = {};

  function starTile(index) {
    var cached = starTiles[index];
    if (cached) return cached;

    var r = rng(0x57A85 ^ Math.imul(index, 0x9E3779B1));
    var list = [];
    for (var s = 0; s < STARS_PER_TILE; s++) {
      list.push({
        gx: index * STAR_TILE + r() * STAR_TILE,
        y: r() * 0.70,
        radius: 0.35 + r() * 1.35,
        alpha: 0.18 + r() * 0.68,
        twinkle: r() * Math.PI * 2,
        rate: 0.0007 + r() * 0.0018,
        // Their own slow wander. Periodic rather than a drift, so a star stays in the tile that
        // generated it and the field never needs regenerating.
        driftRate: 0.00004 + r() * 0.00009,
        driftPhase: r() * Math.PI * 2,
        driftX: 3 + r() * 9,
        driftY: 2 + r() * 6,
        // The whole field is generated once and gated on the world's age instead of the tile
        // being rebuilt as stars accrue: a star that appears on day 40 is in exactly the place it
        // would have been on day 1, so nothing already in the sky shifts when a new one arrives.
        bornDay: s < STARS_AT_BIRTH
          ? -1
          : ((s - STARS_AT_BIRTH) + r()) / (STARS_PER_TILE - STARS_AT_BIRTH) * STAR_FILL_DAYS,
        // A few of them slowly brighten and dim over months, so the sky is never quite the sky
        // it was even where no star has been added.
        swingRate: 0.004 + r() * 0.02,
        swingPhase: r() * Math.PI * 2,
        swing: r() < 0.35 ? 0.25 + r() * 0.3 : 0
      });
    }

    starTiles[index] = list;
    return list;
  }

  function drawStars(t) {
    // Nothing to draw in daylight, and the shooting stars go with them.
    if (nightness < 0.02) return;

    var first = Math.floor(gx(0) / STAR_TILE) - 1;
    var last = Math.floor(gx(width) / STAR_TILE) + 1;

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = '#d9efff';

    for (var tile = first; tile <= last; tile++) {
      var list = starTile(tile);
      for (var i = 0; i < list.length; i++) {
        var s = list[i];
        if (worldDays < s.bornDay) continue;

        // Over most of a day, so nobody watches a star switch on.
        var arrival = smoothstep((worldDays - s.bornDay) / 0.8);

        var wander = t * s.driftRate + s.driftPhase;
        var globalX = s.gx + Math.sin(wander) * s.driftX;
        var x = (globalX - originX) / pxPerCss;
        if (x < -4 || x > width + 4) continue;

        var y = s.y * height + Math.cos(wander * 0.83) * s.driftY;
        var swing = s.swing ? 1 + s.swing * Math.sin(worldDays * s.swingRate + s.swingPhase) : 1;
        ctx.globalAlpha = clamp01(s.alpha * swing * arrival * starVisibility * nightness) *
          (0.72 + 0.28 * Math.sin(t * s.rate + s.twinkle));
        ctx.beginPath();
        ctx.arc(x, y, s.radius, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
    drawShootingStar(t);
  }

  // One candidate per window of time, its path decided by the window index alone. Both displays
  // therefore agree on when it falls and where, and one crossing the seam is drawn by each
  // instance for the part that lands on its own screen.
  var SHOOT_WINDOW = 21000;
  var SHOOT_TRAVEL = 1400;

  function drawShootingStar(t) {
    var index = Math.floor(t / SHOOT_WINDOW);

    // Outside a shower the sky gets its one candidate per window, as it always did. Inside one it
    // gets several, all drawn from the same window index so both displays agree on every streak.
    var shower = showerAt(worldDays);
    var candidates = 1 + Math.round(9 * shower);

    for (var c = 0; c < candidates; c++) {
      drawStreak(t, index, c, shower);
    }
  }

  function drawStreak(t, index, slot, shower) {
    var r = rng(0x5400F ^ Math.imul(index, 0x85EBCA6B) ^ Math.imul(slot + 1, 0x27D4EB2F));

    var delay = r() * (SHOOT_WINDOW - SHOOT_TRAVEL);
    var age = t - index * SHOOT_WINDOW - delay;
    if (age < 0 || age > SHOOT_TRAVEL) return;

    var progress = age / SHOOT_TRAVEL;
    // One streak in a shower is occasionally a fireball: brighter, longer, and slower to fade.
    var fireball = shower > 0.35 && r() > 0.86 ? 1 : 0;
    // Straddles the origin generously: displays sit on both sides of it, and a shooting star that
    // can only ever start in positive desktop space is one that never crosses the left-hand screen.
    var startX = (r() * 5 - 2.5) * SPAN;
    var startY = r() * 0.34;
    var angle = 0.28 + r() * 0.32;
    var reach = SPAN * (0.34 + r() * 0.30);

    var globalX = startX + Math.cos(angle) * reach * progress;
    var y = (startY + Math.sin(angle) * reach * progress / SPAN * 1.6) * height;
    var x = (globalX - originX) / pxPerCss;

    var tail = (130 + fireball * 210) / pxPerCss;
    // Fades in and out across its flight rather than appearing and vanishing at full brightness.
    var strength = Math.sin(progress * Math.PI) * (0.85 + fireball * 0.15);
    if (x < -tail || x > width + tail) return;

    var trail = ctx.createLinearGradient(x, y, x - Math.cos(angle) * tail, y - Math.sin(angle) * tail);
    trail.addColorStop(0, 'rgba(226,244,255,' + strength + ')');
    trail.addColorStop(1, 'rgba(226,244,255,0)');

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.strokeStyle = trail;
    ctx.lineWidth = 1.7 + fireball * 1.4;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - Math.cos(angle) * tail, y - Math.sin(angle) * tail);
    ctx.stroke();
    ctx.restore();
  }

  // --------------------------------------------------------------------- moon

  /**
   * The moon, and the first thing in this world that is genuinely absent at the start.
   *
   * It arrives around the world's seventh day and then runs a 32-day phase cycle. The cycle is
   * the world's, not the sky's: tying it to the real lunar calendar would mean the wallpaper
   * agreed with the window, which is a nice trick exactly once, whereas a phase that belongs to
   * the world is something a viewer can watch progress and can accelerate on the dial.
   *
   * Position is a function of world time too, so it crosses slowly and is in the same place on
   * every display at the same moment.
   */
  var MOON_ARRIVES = 6;          // world day the first sliver becomes visible
  var MOON_CYCLE = 32;           // world days from new moon to new moon
  var moonCanvas = null, moonCtx = null, moonKey = '';

  function moonState() {
    var presence = smoothstep((worldDays - MOON_ARRIVES) / 2.5);
    if (presence <= 0.002) return null;

    // 0 is new, 0.5 is full. The illuminated fraction is the usual cosine of the phase angle.
    var phase = mod(worldDays / MOON_CYCLE, 1);
    var illum = (1 - Math.cos(phase * Math.PI * 2)) * 0.5;

    // Crossing takes rather longer than a world day, so the moon is not in the same place at the
    // same hour two days running. Kept to a traverse near one screen wide for the same reason as
    // the sun: a moon that is off the side of the monitor is not a feature.
    var travel = mod(worldDays / 1.37, 1);
    var globalX = travel * SPAN * 2.2 - SPAN * 0.6;
    var arc = Math.sin(travel * Math.PI);

    return {
      phase: phase,
      illum: illum,
      presence: presence,
      globalX: globalX,
      y: height * (0.30 - 0.14 * arc),
      radius: Math.max(9, Math.min(height, width) * 0.026)
    };
  }

  /**
   * The lit shape is built once per phase step into its own canvas and blitted.
   *
   * It has to be masked somewhere with transparency: erasing the shadowed half straight onto the
   * scene would cut a hole through the sky behind it rather than through the moon.
   */
  function moonFace(m, p) {
    var r = m.radius;
    var size = Math.ceil(r * 2 + 4);
    // Quantized so the face is redrawn a few dozen times a cycle rather than every frame.
    var key = size + ':' + Math.round(m.phase * 180) + ':' + Math.round(p.a[0]);
    if (moonKey === key) return moonCanvas;

    if (!moonCanvas) {
      moonCanvas = document.createElement('canvas');
      moonCtx = moonCanvas.getContext('2d');
    }
    if (moonCanvas.width !== size || moonCanvas.height !== size) {
      moonCanvas.width = size;
      moonCanvas.height = size;
    }

    var g = moonCtx;
    var c = size / 2;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, size, size);

    // A cold disc with a little of the aurora in it, because nothing in this sky is neutral.
    var face = g.createRadialGradient(c - r * 0.3, c - r * 0.3, r * 0.1, c, c, r);
    face.addColorStop(0, rgba(mixColor([236, 246, 255], p.a, 0.10), 1));
    face.addColorStop(0.7, rgba(mixColor([206, 224, 242], p.b, 0.16), 1));
    face.addColorStop(1, rgba(mixColor([168, 190, 212], p.b, 0.22), 1));
    g.fillStyle = face;
    g.beginPath();
    g.arc(c, c, r, 0, Math.PI * 2);
    g.fill();

    // Faint maria, fixed to the disc so the moon keeps a face rather than being a blank circle.
    g.fillStyle = 'rgba(120,146,170,0.30)';
    g.beginPath();
    g.arc(c - r * 0.28, c - r * 0.18, r * 0.30, 0, Math.PI * 2);
    g.fill();
    g.beginPath();
    g.arc(c + r * 0.22, c + r * 0.26, r * 0.22, 0, Math.PI * 2);
    g.fill();
    g.beginPath();
    g.arc(c + r * 0.05, c - r * 0.40, r * 0.14, 0, Math.PI * 2);
    g.fill();

    // The terminator: a half circle on the lit limb closed by a half ellipse whose width is the
    // cosine of the phase angle. Everything outside it is erased rather than painted dark.
    var k = Math.cos(m.phase * Math.PI * 2);
    var waxing = m.phase < 0.5;

    g.globalCompositeOperation = 'destination-in';
    g.beginPath();
    if (waxing) {
      g.arc(c, c, r, -Math.PI / 2, Math.PI / 2, false);
      g.ellipse(c, c, r * Math.abs(k), r, 0, Math.PI / 2, -Math.PI / 2, k > 0);
    } else {
      g.arc(c, c, r, Math.PI / 2, -Math.PI / 2, false);
      g.ellipse(c, c, r * Math.abs(k), r, 0, -Math.PI / 2, Math.PI / 2, k < 0);
    }
    g.closePath();
    g.fill();
    g.globalCompositeOperation = 'source-over';

    moonKey = key;
    return moonCanvas;
  }

  function drawMoon(p, weather) {
    if (nightness < 0.05) return;

    var m = moonState();
    if (!m) return;

    var x = (m.globalX - originX) / pxPerCss;
    var reach = m.radius * 7;
    if (x < -reach || x > width + reach) return;

    // Cloud takes the moon before it takes the stars, because it is the brighter thing and the
    // one whose absence is noticed.
    var clarity = m.presence * (1 - weather.cloud * 0.85) * nightness;
    if (clarity <= 0.01) return;

    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    var halo = ctx.createRadialGradient(x, m.y, m.radius * 0.6, x, m.y, m.radius * 6.5);
    halo.addColorStop(0, rgba(mixColor([200, 226, 248], p.a, 0.25), 0.16 * clarity * (0.35 + m.illum)));
    halo.addColorStop(0.35, rgba(mixColor([150, 186, 220], p.b, 0.3), 0.05 * clarity * (0.35 + m.illum)));
    halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo;
    ctx.fillRect(x - m.radius * 6.5, m.y - m.radius * 6.5, m.radius * 13, m.radius * 13);

    var face = moonFace(m, p);
    ctx.globalAlpha = clarity;
    ctx.drawImage(face, x - face.width / 2, m.y - face.height / 2);
    ctx.restore();
  }

  // ---------------------------------------------------------------------- sun

  /**
   * The sun, rising on the left and setting on the right across the whole desktop.
   *
   * Placed in desktop coordinates like everything else, so on two monitors it is one sun crossing
   * one sky rather than a copy sitting in each. It is low and large near the horizon and small
   * and pale overhead, which is most of what distinguishes an afternoon from a sunset.
   */
  function drawSun(frac, p) {
    if (sunAlt < -0.12) return;

    var progress = (frac - 0.25) / 0.5;             // 0 at sunrise, 1 at sunset
    if (progress < -0.08 || progress > 1.08) return;

    // A traverse a little wider than one screen rather than the whole desktop. A sun spread
    // across four spans is off the side of any single monitor for most of the day, which is
    // astronomically tidy and useless as a wallpaper; this keeps one continuous sun that is
    // actually in the sky while the sky is bright.
    var globalX = -SPAN * 0.35 + progress * SPAN * 1.7;
    var x = (globalX - originX) / pxPerCss;
    var arc = Math.sin(clamp01(progress) * Math.PI);
    var y = height * (0.80 - 0.62 * arc);
    var radius = Math.max(10, Math.min(height, width) * 0.021);
    var reach = radius * 9;
    if (x < -reach || x > width + reach) return;

    // Warm and heavy at the horizon, white and small overhead.
    var low = 1 - clamp01(arc * 1.4);
    var disc = mixColor([255, 248, 232], [255, 168, 96], low);
    var presence = smoothstep((sunAlt + 0.12) / 0.18);

    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    var halo = ctx.createRadialGradient(x, y, radius * 0.4, x, y, reach);
    halo.addColorStop(0, rgba(disc, 0.42 * presence));
    halo.addColorStop(0.22, rgba(mixColor(disc, [255, 190, 130], 0.5), 0.14 * presence));
    halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo;
    ctx.fillRect(x - reach, y - reach, reach * 2, reach * 2);

    ctx.globalAlpha = presence;
    ctx.fillStyle = rgba(disc, 0.95);
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // ------------------------------------------------------------------- clouds

  /**
   * Clouds that are born, grow, cross and dissipate rather than looping.
   *
   * Each cell owns a place on the desktop and a life measured in world days, so what a viewer
   * sees is a sky that is clear for a while, clouds over, and clears again - and at the dial's
   * faster settings, does all of that in front of them.
   */
  function drawClouds(t, p, weather) {
    if (weather.cloud < 0.02 || clouds.length === 0) return;

    ctx.save();

    for (var i = 0; i < clouds.length; i++) {
      var c = clouds[i];

      // A cell thins and thickens rather than being born and dying. Once a world has clouded
      // over the cloud is a feature of it, not an event in it, so the floor under this envelope
      // is what keeps the sky covered between one swell and the next.
      var life = mod(worldDays / c.lifeDays + c.lifePhase, 1);
      var envelope = 0.42 + 0.58 * Math.sin(life * Math.PI);
      var alpha = envelope * weather.cloud * c.weight * 0.98;
      if (alpha < 0.012) continue;

      var globalX = mod(c.gx + t * c.drift, CLOUD_WRAP) - CLOUD_WRAP * 0.5;
      var x = (globalX - originX) / pxPerCss;
      var rx = c.rx / pxPerCss;
      if (x < -rx * 1.6 || x > width + rx * 1.6) continue;

      var y = c.y * height;
      var ry = c.ry * (0.7 + 0.5 * envelope);

      // Drawn as a squashed radial gradient: one fill per cell, and soft enough at the edge that
      // no part of it reads as a shape with an outline.
      ctx.save();
      ctx.translate(x, y);
      ctx.scale(1, ry / rx);

      // A night cloud is a dark shape in front of the aurora; a daytime one is a lit shape
      // against a blue sky. Same cell, opposite treatment, and it is the clearest signal in the
      // scene that the hour has moved on.
      var day = 1 - nightness;
      // Daytime cores have to sit well above the noon sky ([196,224,238]) or they dissolve into
      // it. Night cores stay darker than the aurora glow so they still occlude it.
      var core = mixColor(mixColor([30, 50, 68], p.b, 0.22), [248, 252, 255], day);
      var edge = mixColor(mixColor([20, 36, 52], p.b, 0.16), [176, 194, 214], day);
      var shade = mixColor(mixColor([14, 24, 36], p.b, 0.12), [132, 148, 168], day);
      var lift = alpha * (0.85 + day * 0.55);

      // Three overlapping puffs rather than one ellipse. A single radial gradient reads as a lens
      // no matter how soft its edge is, because its outline is a perfect ellipse and nothing in
      // the sky is; offsetting a few of them at different sizes is the cheapest thing that stops
      // looking like geometry.
      for (var puff = 0; puff < 3; puff++) {
        var off = (puff - 1) * rx * 0.52;
        var pr = rx * (puff === 1 ? 0.78 : 0.56) * (0.85 + 0.3 * c.puffs[puff]);
        var py = (c.puffs[puff] - 0.5) * rx * 0.22;

        var body = ctx.createRadialGradient(off, py - pr * 0.12, pr * 0.05, off, py + pr * 0.18, pr);
        body.addColorStop(0, rgba(core, lift * 0.95));
        body.addColorStop(0.28, rgba(edge, lift * 0.62));
        body.addColorStop(0.58, rgba(shade, lift * 0.34));
        body.addColorStop(0.82, rgba(shade, lift * 0.12));
        body.addColorStop(1, 'rgba(6,14,24,0)');
        ctx.fillStyle = body;
        ctx.beginPath();
        ctx.arc(off, py, pr, 0, Math.PI * 2);
        ctx.fill();
      }

      // The aurora is behind them, so their upper edge catches a little of it.
      if (nightness > 0.03) {
        ctx.globalCompositeOperation = 'screen';
        var lit = ctx.createRadialGradient(0, -rx * 0.25, rx * 0.05, 0, -rx * 0.25, rx * 0.9);
        lit.addColorStop(0, rgba(p.a, alpha * 0.22 * nightness));
        lit.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = lit;
        ctx.beginPath();
        ctx.arc(0, -rx * 0.12, rx * 0.9, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }

    ctx.restore();
  }

  // ------------------------------------------------------------------ impacts

  /**
   * What a strike looks like from here: a flash as it lands, then a glow over the place it hit
   * that fades across the following days. A comet's lasts weeks and lights half the sky.
   *
   * The crater itself is in the crest, not here. This is only the part of an impact that is in
   * the air, which is why it fades and the ground does not.
   */
  function drawImpacts(p) {
    if (impacts.length === 0) return;

    var horizon = height * HORIZON;

    for (var i = 0; i < impacts.length; i++) {
      var im = impacts[i];
      if (im.day > worldDays) continue;

      var since = worldDays - im.day;
      var linger = im.comet ? 40 : 8.5;
      if (since > linger) continue;

      var x = (im.gx - originX) / pxPerCss;
      var reach = (im.comet ? 900 : 260) / pxPerCss;
      if (x < -reach || x > width + reach) continue;

      // The strike itself, over the first few hours of world time, and then the afterglow.
      var flash = since < 0.06 ? Math.sin((1 - since / 0.06) * Math.PI * 0.5) : 0;
      var glow = Math.pow(1 - since / linger, 2);
      var strength = clamp01(flash * 0.9 + glow * (im.comet ? 0.5 : 0.22));
      if (strength < 0.01) continue;

      var tone = im.comet
        ? mixColor([255, 208, 150], p.c, 0.25)
        : mixColor([255, 226, 190], p.a, 0.3);

      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      var bloom = ctx.createRadialGradient(x, horizon, 0, x, horizon, reach);
      bloom.addColorStop(0, rgba(tone, 0.55 * strength));
      bloom.addColorStop(0.3, rgba(tone, 0.16 * strength));
      bloom.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = bloom;
      ctx.fillRect(x - reach, horizon - reach, reach * 2, reach * 2);
      ctx.restore();
    }
  }

  // ------------------------------------------------------------------- aurora

  /**
   * How strongly the pointer affects a point, by distance along the desktop. A Gaussian rather
   * than a radius test, so curtains bend into the disturbance instead of showing its edge.
   */
  function pull(globalX) {
    // Gated on the eased weights, never on the mode itself: a mode test here would zero the whole
    // displacement on the frame the viewer changed the option, which is the snap the weights exist
    // to avoid.
    if (presence < 0.004 || attractMix + repelMix < 0.004) return 0;
    var d = (globalX - cursorGlobalX()) / (SPAN * 0.16);
    return Math.exp(-(d * d) / 2) * presence;
  }

  function cursorGlobalX() { return originX + cursor.x * width * pxPerCss; }

  function curtainCenter(b, xCss, t) {
    var g = gx(xCss);

    // Several harmonics: a real curtain has folds rather than one smooth sine wave.
    var wave =
      Math.sin(g * b.freq + t * b.speed + b.phase) * b.amp +
      Math.sin(g * b.freq * 2.17 - t * b.speed * 0.71 + b.phase * 1.7) * b.amp * 0.34 +
      Math.sin(g * b.freq * 4.31 + t * b.speed * 0.43) * b.amp * 0.12;

    // Audio rides on the curtain's own shape rather than replacing it: loud music deepens the
    // folds that were already there instead of switching on a different animation.
    wave *= 1 + level * 1.15 + bass * 0.75 + pulse * 0.55;

    var traveling = Math.sin(gn(xCss) * 5.3 + t * 0.00018 + b.phase) * 0.5 + 0.5;
    var center = b.baseY * height + wave + traveling * b.skew * SPAN / pxPerCss;

    // A beat travels along the curtain rather than flashing all of it at once, so the movement
    // reads as running through the aurora in the direction it is already drifting.
    if (pulse > 0.004) {
      center += Math.sin(gn(xCss) * 3.1 - t * 0.0016 + b.phase) * pulse * b.width * 0.5;
    }

    var reach = pull(g) * (0.35 + 0.65 * (1 - b.depth));
    if (reach <= 0) return center;

    // Both displacements are measured from the undisturbed curtain and then summed, rather than
    // applied one on top of the other, so the crossfade between modes is a straight blend of two
    // independent answers instead of one mode deflecting what the other already did.
    var rest = center;
    var shift = 0;

    if (repelMix > 0.002) {
      // Parted: pushed away from the pointer on whichever side it already sits.
      //
      // The side used to be a sign test, which is a step discontinuity exactly where it is most
      // visible - a curtain drifting through the pointer's height would invert its full
      // displacement between one frame and the next. This is the same sign, softened over a band
      // either side of the pointer, so a curtain crossing it passes through undisplaced instead of
      // flipping.
      var gap = rest - cursor.y * height;
      var soft = height * 0.13;
      var away = gap / Math.sqrt(gap * gap + soft * soft);
      shift += away * reach * repelMix * (b.width * 0.62 + height * 0.035);
    }

    if (attractMix > 0.002) {
      shift += (cursor.y * height - rest) * reach * attractMix * 0.22;
      shift -= reach * attractMix * energy * b.width * 0.55;
    }

    return rest + shift;
  }

  function drawAuroraBand(b, t, palette) {
    var step = Math.max(10, width / 140);
    var points = [];
    for (var x = -step; x <= width + step; x += step) {
      var center = curtainCenter(b, x, t);
      var nx = gn(x);
      var top = center - b.width * (0.55 + 0.25 * Math.sin(nx * 8 + b.phase));
      var bottom = center + b.width * (0.85 + 0.28 * Math.sin(nx * 5 - b.phase));
      points.push({ x: x, top: top, bottom: bottom });
    }

    var g2 = auroraCtx;
    g2.beginPath();
    g2.moveTo(points[0].x, height);
    for (var i = 0; i < points.length; i++) g2.lineTo(points[i].x, points[i].bottom);
    g2.lineTo(points[points.length - 1].x, height);
    g2.closePath();

    // Louder audio brightens the curtain as well as deepening it, which is what stops a loud
    // passage reading as merely a bigger version of a quiet one. An aurora storm does the same
    // thing on a scale of days rather than beats.
    var lift = (1 + level * 1.05 + pulse * 0.45 + auroraStorm * 0.85) * auroraGain;
    var grad = g2.createLinearGradient(0, points[0].top, 0, height);
    var edge = mixColor(palette.c, palette.a, b.depth * 0.5);
    grad.addColorStop(0, rgba(edge, 0));
    grad.addColorStop(0.12, rgba(palette.c, b.alpha * 0.32 * lift));
    grad.addColorStop(0.38, rgba(palette.b, b.alpha * 0.68 * lift));
    grad.addColorStop(0.62, rgba(palette.a, b.alpha * lift));
    grad.addColorStop(1, rgba(palette.a, 0));
    g2.fillStyle = grad;
    g2.fill();

    // Narrow luminous folds: what makes the shape read as aurora rather than a gradient. Fold
    // count falls off with depth, because on a distant curtain they are too dim to count and this
    // is the scene's single biggest cost.
    // Fold count grows with the world: an old aurora has finer structure in it than a young one,
    // which is the part that reads as the sky having become more elaborate rather than brighter.
    g2.lineCap = 'round';
    var detail = Math.round(2 * auroraDetail);
    var foldCount = (b.depth > 0.62 ? 4 : (b.depth > 0.3 ? 5 : 7)) + detail;
    for (var f = 0; f < foldCount; f++) {
      var offset = (f / Math.max(1, foldCount - 1) - 0.5) * b.width * 1.2;
      g2.beginPath();
      for (var j = 0; j < points.length; j += 3) {
        var q = points[j];
        var fold = offset +
          Math.sin(gx(q.x) * b.freq * 2.4 + t * b.speed * 1.35 + f * 0.9) * b.width * 0.34;
        var y = q.top + b.width * 0.24 + fold;
        if (j === 0) g2.moveTo(q.x, y);
        else g2.lineTo(q.x, y);
      }
      var lineColor = f % 3 === 0 ? palette.c : palette.a;
      // Treble picks out the folds. They are the finest structure in the scene, so they are what
      // can carry a hi-hat without the whole sky flashing.
      g2.strokeStyle = rgba(lineColor, 0.045 + b.alpha * 0.28 + treble * 0.26);
      g2.lineWidth = 1.2 + (1 - b.depth) * 1.7;
      g2.stroke();
    }
  }

  // The curtains are drawn into a half-resolution buffer and blitted up. Aurora is the one layer
  // with no hard edge anywhere in it, so it loses nothing to being drawn at half scale, and this
  // collapses fifteen full-screen 'screen' composites onto the visible canvas into one.
  var AURORA_SCALE = 0.5;
  var auroraCanvas = null, auroraCtx = null;

  function ensureAuroraBuffer() {
    var w = Math.max(1, Math.round(canvas.width * AURORA_SCALE));
    var h = Math.max(1, Math.round(canvas.height * AURORA_SCALE));

    if (!auroraCanvas) {
      auroraCanvas = document.createElement('canvas');
      auroraCtx = auroraCanvas.getContext('2d');
    }
    if (auroraCanvas.width !== w || auroraCanvas.height !== h) {
      auroraCanvas.width = w;
      auroraCanvas.height = h;
    }

    // Scaled so every drawing routine keeps working in CSS pixels and none of the curtain maths
    // has to know it is being rendered smaller than it is shown.
    auroraCtx.setTransform(dpr * AURORA_SCALE, 0, 0, dpr * AURORA_SCALE, 0, 0);
    auroraCtx.clearRect(0, 0, width, height);
  }

  /**
   * How many curtains are out. Three on install, the eleven Wave Drift used to ship with at two
   * months, and the full eighteen after a year.
   */
  function bandsOut(days) {
    if (days <= EVOLVE_DEFAULT) {
      return BAND_AT_BIRTH + (BAND_AT_DEFAULT - BAND_AT_BIRTH) * smoothstep(days / EVOLVE_DEFAULT);
    }
    var late = smoothstep((days - EVOLVE_DEFAULT) / (EVOLVE_FULL - EVOLVE_DEFAULT));
    return BAND_AT_DEFAULT + (BAND_TOTAL - BAND_AT_DEFAULT) * late;
  }

  /**
   * A band's own colours: the shared palette leaned toward one of its other two, further as the
   * aurora grows, and then pulled hard toward the storm's tint if one is running.
   */
  function bandPalette(b, p) {
    var spread = (0.12 + 0.55 * worldGrowth) * Math.abs(b.hue);
    var toward = b.hue > 0 ? 1 : -1;

    var col = {
      a: mixColor(p.a, toward > 0 ? p.b : p.c, spread),
      b: mixColor(p.b, toward > 0 ? p.c : p.a, spread),
      c: mixColor(p.c, toward > 0 ? p.a : p.b, spread)
    };

    if (stormNow) {
      // Hard enough that the sky changes character rather than gaining brightness. A storm the
      // viewer cannot name a colour for is not an event.
      var s = stormNow.strength * 0.8;
      col.a = mixColor(col.a, stormNow.tint.a, s);
      col.b = mixColor(col.b, stormNow.tint.b, s);
      col.c = mixColor(col.c, stormNow.tint.c, s);
    }

    return col;
  }

  function drawAurora(t, p) {
    ensureAuroraBuffer();
    auroraCtx.globalCompositeOperation = 'screen';

    var out = bandsOut(worldDays);

    for (var i = 0; i < bands.length; i++) {
      if (i >= out) break;

      // The newest band is only partly out, so the aurora gains a curtain over days rather than
      // between one frame and the next.
      auroraGain = clamp01(out - i);
      drawAuroraBand(bands[i], t, bandPalette(bands[i], p));
    }

    auroraGain = 1;

    // A few intense, narrow curtains at the top edge. Fixed rather than seeded, so identical in
    // every instance by construction, and arriving one at a time as the world matures.
    for (var k = 0; k < 4; k++) {
      var arrival = clamp01((worldGrowth - k * 0.2) * 4);
      if (arrival <= 0.01) break;

      auroraGain = arrival;
      drawAuroraBand({
        phase: k * 1.9,
        speed: 0.00032 + k * 0.000035,
        freq: 0.0013 + k * 0.00025,
        amp: 48 + k * 12,
        baseY: 0.17 + k * 0.045,
        width: 42 + k * 7,
        alpha: 0.10,
        skew: 0.05,
        depth: 0.1 + k * 0.08,
        hue: k % 2 ? 0.7 : -0.7
      }, t, bandPalette({ hue: k % 2 ? 0.7 : -0.7 }, p));
    }

    auroraGain = 1;

    // Nothing is drawn at the pointer itself. A glow or a cleared disc that follows the mouse
    // reads as a halo stuck to the cursor rather than as the aurora responding to it, and it is
    // the one part of the interaction that draws attention to the pointer instead of the sky.
    // The response is entirely in where the curtains go, which is what makes it feel like weather.

    // Night: the full screen-blended aurora. Day: screen on a bright sky is invisible, so a
    // separate soft sky-wave pass keeps the curtains moving instead of leaving an empty blue field.
    if (nightness > 0.02) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = nightness;
      ctx.drawImage(auroraCanvas, 0, 0, width, height);
      ctx.restore();
    }

    drawDayWaves(t);
  }

  /**
   * Daytime cousins of the aurora curtains.
   *
   * Same motion, quieter colour. They exist so noon still has waves: without them the day cycle
   * deletes the only moving sky feature and the wallpaper collapses to sun + flat colour.
   */
  function drawDayWaves(t) {
    var day = 1 - nightness;
    if (day < 0.08) return;

    var out = Math.min(Math.ceil(bandsOut(worldDays)), 8);
    if (out < 1) return;

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    var step = Math.max(12, width / 110);
    for (var i = 0; i < out; i++) {
      var b = bands[i];
      var gain = clamp01(out - i) * day * (0.55 + 0.45 * (1 - b.depth));
      var alpha = (0.055 + b.alpha * 0.42) * gain;
      if (alpha < 0.01) continue;

      var pts = [];
      for (var x = -step; x <= width + step; x += step) {
        var center = curtainCenter(b, x, t);
        var half = b.width * (0.38 + 0.12 * Math.sin(gn(x) * 6 + b.phase));
        pts.push({ x: x, top: center - half, bot: center + half * 1.15 });
      }

      // Cool white over soft blue-grey, darker on the underside so the ribbon has a little volume
      // against the noon gradient instead of reading as chalk scribbled on the sky.
      var lit = mixColor([255, 255, 255], [210, 228, 245], 0.35 + b.depth * 0.25);
      var dim = mixColor([168, 190, 214], [140, 164, 190], b.depth * 0.4);
      var grad = ctx.createLinearGradient(0, pts[0].top - 8, 0, pts[0].bot + 24);
      grad.addColorStop(0, rgba(lit, 0));
      grad.addColorStop(0.22, rgba(lit, alpha * 0.55));
      grad.addColorStop(0.48, rgba(lit, alpha * 0.85));
      grad.addColorStop(0.72, rgba(dim, alpha * 0.5));
      grad.addColorStop(1, rgba(dim, 0));

      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].top);
      for (var a = 1; a < pts.length; a++) ctx.lineTo(pts[a].x, pts[a].top);
      for (var c = pts.length - 1; c >= 0; c--) ctx.lineTo(pts[c].x, pts[c].bot);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      // One fold line per curtain: motion reads better as a travelling edge than as a soft blob.
      ctx.beginPath();
      for (var f = 0; f < pts.length; f++) {
        var fold = (pts[f].top + pts[f].bot) * 0.48 +
          Math.sin(gx(pts[f].x) * b.freq * 2.1 + t * b.speed * 1.2) * b.width * 0.16;
        if (f === 0) ctx.moveTo(pts[f].x, fold);
        else ctx.lineTo(pts[f].x, fold);
      }
      ctx.strokeStyle = rgba(lit, alpha * 0.7);
      ctx.lineWidth = 1.1 + (1 - b.depth) * 1.4;
      ctx.stroke();
    }

    ctx.restore();
  }

  function drawParticles(t, p) {
    var day = 1 - nightness;
    // Night motes stay bright screen flecks; day keeps a few soft dust motes so the sky is not
    // a still photograph behind the sun.
    var presence = nightness + day * 0.22;
    if (presence < 0.02) return;

    ctx.save();
    ctx.globalCompositeOperation = nightness > 0.45 ? 'screen' : 'source-over';

    for (var i = 0; i < particles.length; i++) {
      var q = particles[i];
      // Wrapped into a range straddling the origin, because a display can sit at a negative
      // desktop x: the secondary on the reference machine starts at -1920, and a wrap into
      // [0, WRAP) puts every mote on the other side of the desktop from it.
      var globalX = mod(q.gx + t * q.speed, PARTICLE_WRAP) - PARTICLE_WRAP * 0.5;
      var x = (globalX - originX) / pxPerCss;
      if (x < -8 || x > width + 8) continue;

      var y = (q.y + Math.sin(t * 0.00025 + q.phase) * 0.018) * height;
      var tone = nightness > 0.45
        ? (i % 4 ? p.a : p.c)
        : mixColor([255, 255, 255], [190, 210, 230], 0.35);
      ctx.globalAlpha = q.alpha * (0.65 + 0.35 * Math.sin(t * 0.001 + q.phase)) * presence;
      ctx.fillStyle = rgba(tone, 1);
      ctx.beginPath();
      ctx.arc(x, y, q.size * (nightness > 0.45 ? 1 : 1.35), 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  // -------------------------------------------------------------------- range

  // The original low silhouette, restored.
  //
  // The three-layer ridged range that briefly replaced it was a different landscape rather than a
  // better version of this one. What this needed was detail on the shape that was already here, so
  // the large profile below is the old one term for term and everything after it adds relief,
  // light and weather to that shape without moving it.
  //
  // Written against desktop x, so the range continues across the seam between displays for free.
  var HORIZON = 0.76;
  var CREST_MID = 10;
  // Reach of the front profile. Kept modest so the sky (and its waves) still own most of the frame.
  var CREST_AMP = 82;
  var SNOW_LINE = 0.52;          // fraction of that reach above the mean where snow starts

  /**
   * The crest at a desktop x.
   *
   * First three terms are the original profile's amplitudes and frequencies, unchanged - the
   * shape of the range is still the same three-hump silhouette it always was. The rest is fine
   * relief laid over it: enough that the edge reads as broken rock, still small enough that the
   * silhouette from across the room is the same range.
   *
   * The relief is scaled by a much slower sine before it is added. Uniform roughness is its own
   * kind of flatness: every summit equally jagged is as obviously generated as every summit
   * equally smooth. This way the range has weathered stretches and bare ones.
   *
   * What made the restored profile read as a cutout rather than terrain was not the amplitudes,
   * it was their spacing: three fixed-period sine waves put a peak at very nearly the same
   * distance from the last one everywhere along the range, which is a comb, and no mountain range
   * looks like a comb. Warping the x each term is evaluated at - a slow wander built from two
   * long, unrelated periods - compresses peaks together in some stretches and spreads them apart
   * in others without moving a single amplitude. The three-hump silhouette and its full reach are
   * exactly what they were; only how the peaks along it are spaced has changed.
   */
  // Mild warp only: enough to break the comb spacing of the fixed-period sines, not enough to
  // open deep rectangular valleys that read as holes punched through the range.
  //
  // On top of the warp, the amplitudes are scaled by a slowly varying regional relief. One set of
  // amplitudes end to end gives a range with a single personality, which is the other half of why
  // it read as pattern: a real range has massifs and it has low ground between them, and which
  // one you are looking at should depend on where you are looking.
  function crestAt(globalX, horizon) {
    var warped = globalX +
      Math.sin(globalX * 0.00085 + 0.6) * 22 +
      Math.sin(globalX * 0.00193 + 3.1) * 10;

    // Two periods, one about a screen and a half wide and one about four, so a single monitor
    // shows a high stretch and a low one rather than a uniform slice of a variation whose period
    // is wider than the desktop. That was the whole of why the range still looked the same all
    // the way across: the variety existed, it was just all off the side of the screen.
    var relief = 0.30 + 1.30 *
      (Math.sin(globalX * 0.0021 + 1.3) * 0.5 + 0.5) *
      (0.4 + 0.6 * (Math.sin(globalX * 0.00072 + 4.2) * 0.5 + 0.5));

    // How broken this stretch is, separately from how high it is. High smooth ground and low
    // jagged ground both exist, and tying jaggedness to height alone is what gives a generated
    // range its one note.
    var rough = 0.25 + 0.75 * (Math.sin(warped * 0.0067 + 0.7) * 0.5 + 0.5) *
      (0.35 + 0.65 * (Math.sin(globalX * 0.0014 + 2.9) * 0.5 + 0.5));

    return horizon + CREST_MID +
      // The massif: a long, slow swell the smaller humps sit on, so a stretch of the range can be
      // high ground as a whole rather than merely having taller individual peaks.
      Math.sin(warped * 0.0072 + 2.4) * 16 * relief +
      Math.sin(warped * 0.0129 + 5.1) * 10 * relief +
      (Math.sin(warped * 0.018) * 15 +
       Math.sin(warped * 0.049) * 8.5 +
       Math.sin(warped * 0.091) * 4.2) * relief +
      rough * relief * (
        Math.sin(warped * 0.173 + 1.31) * 1.5 +
        Math.sin(warped * 0.317 + 2.77) * 0.75 +
        Math.sin(warped * 0.611 + 0.42) * 0.42 +
        Math.sin(warped * 1.13 + 4.05) * 0.22) +
      craterAt(globalX);
  }

  /**
   * How far the ground has been pushed down at a desktop x by everything that has hit it.
   *
   * A bowl with a raised rim, which is the shape an impact actually leaves, and it settles in
   * over a few days rather than appearing between two frames. Because it is a function of the
   * world's age and nothing else, the crater is in the same place on both displays and is still
   * there a year later - the landscape genuinely carries its history rather than replaying it.
   */
  function craterAt(globalX) {
    if (visibleImpacts.length === 0) return 0;

    var drop = 0;
    for (var i = 0; i < visibleImpacts.length; i++) {
      var im = visibleImpacts[i];
      var d = (globalX - im.gx) / im.radius;
      if (d < -1.7 || d > 1.7) continue;

      var since = worldDays - im.day;
      var settled = smoothstep(since / 2.5);
      var weathered = 1 - smoothstep(since / IMPACT_ERODE);
      var bowl = Math.exp(-d * d * 2.2);
      var rim = Math.exp(-Math.pow(Math.abs(d) - 1.0, 2) * 9) * 0.5;
      drop += (bowl - rim) * im.depth * settled * weathered;
    }

    // Two strikes in the same valley deepen it; twenty must not open a hole the range falls
    // through, so the total is bounded well inside the profile's own reach.
    return Math.min(drop, CREST_AMP * 0.55);
  }

  /**
   * How much snow there is on the rock, 0..1.
   *
   * Permanent high caps accumulate with age; seasonal cover comes and goes so winter actually
   * whites out the mid-slopes and summer gives them back to grass.
   */
  function snowAt(days) {
    var accumulated = smoothstep(days / 240);
    var season = seasonAt(days);
    var seasonal = season.snowCover;
    return clamp01(0.10 + accumulated * 0.45 + seasonal * (0.35 + accumulated * 0.25));
  }

  /**
   * How far vegetation has claimed the low ground, 0..1.
   *
   * Age opens the possibility; the season decides how green it looks right now. A summer meadow
   * on a young world is thin; a winter meadow on an old one is mostly memory.
   */
  function greenAt(days) {
    var maturity = clamp01(
      smoothstep((days - 5) / 70) * 0.65 +
      smoothstep((days - 100) / 180) * 0.35);
    return maturity * seasonAt(days).grass;
  }

  /**
   * How dense the living forest is.
   *
   * Delayed and slow on purpose: grass has to own the slope before trunks read as a forest, and
   * individual trees still grow across many world-days so warp does not look like a stamp.
   */
  function forestAt(days) {
    return clamp01(
      smoothstep((days - 30) / 80) * 0.50 +
      smoothstep((days - 120) / 150) * 0.32 +
      smoothstep((days - 280) / 220) * 0.18);
  }

  /**
   * How far people have settled the range. Keeps climbing past the first year so a long warp run
   * still unfolds instead of freezing once growth() hits 1.
   */
  function civAt(days) {
    return clamp01(
      smoothstep((days - 38) / 70) * 0.40 +
      smoothstep((days - 110) / 120) * 0.30 +
      smoothstep((days - 260) / 180) * 0.18 +
      smoothstep((days - 420) / 300) * 0.12);
  }

  /**
   * Where snow begins at a desktop x.
   *
   * A flat snow line makes every summit wear the same cap. A few metres of wander, keyed to the
   * same global x the crest uses, turns that into a wind-scoured edge without changing which peaks
   * are snowed at all.
   */
  function snowLineAt(globalX, base) {
    return base +
      Math.sin(globalX * 0.073 + 0.9) * 3.5 +
      Math.sin(globalX * 0.19 + 2.1) * 1.5;
  }

  // ------------------------------------------------------------- backdrop

  /**
   * Two hazy ridgelines behind the range proper.
   *
   * The foreground silhouette's shape is deliberately untouched (see the note above): what it was
   * missing was not a different profile but the depth that a single flat cutout can never have on
   * its own. These add that depth the same way the front range's own light and weather were added
   * - as extra layers over an unchanged shape, not as a replacement for it.
   *
   * A silhouette alone cannot look three-dimensional; it can only look like a cutout. What tells
   * an eye that a shape recedes is contrast with something behind it: a farther ridge is paler,
   * bluer and softer than a nearer one because that is what several kilometres of air actually do
   * to light, and this scene fakes exactly that (desaturated toward the haze colour, low contrast,
   * blurred) rather than drawing a second copy of the same rock at a smaller scale.
   *
   * Both are still pure functions of desktop x, so the pair the far layer's peak sits at above one
   * display is the same peak the far layer draws at the matching x on its neighbour.
   */
  // Close enough above the horizon that a far peak can rise into the same band the front range's
  // own peaks occupy - the overlap in that one band is what lets a gap in the near silhouette show
  // a farther one behind it, rather than the two ever reading as separate, unrelated pictures.
  var FAR_LIFT = 0.055;
  var MID_LIFT = 0.024;

  function farCrestAt(globalX, base) {
    return base +
      Math.sin(globalX * 0.0043 + 2.05) * 46 +
      Math.sin(globalX * 0.0101 + 0.35) * 18 +
      Math.sin(globalX * 0.0234 + 3.7) * 7.5 +
      Math.sin(globalX * 0.052 + 1.9) * 3;
  }

  function midCrestAt(globalX, base) {
    return base +
      Math.sin(globalX * 0.0079 + 1.05) * 36 +
      Math.sin(globalX * 0.0187 + 3.35) * 14 +
      Math.sin(globalX * 0.041 + 0.55) * 5.5 +
      Math.sin(globalX * 0.083 + 2.4) * 4 +
      Math.sin(globalX * 0.15 + 0.9) * 2;
  }

  /**
   * One hazy ridge: a soft-edged body that dims whatever sky is behind it, plus a thin
   * screen-blended rim so its highest edge alone is allowed to catch light. Everything below its
   * own crest line still belongs to whichever layer sits in front of it - the front range's solid
   * fill paints over all of this except where a farther peak pokes up above a nearer one.
   */
  function drawDistantRidge(crestFn, base, tone, alpha, blurPx, rimAlpha) {
    var step = Math.max(4, width / 260);
    var pts = [];
    for (var x = -step; x <= width + step; x += step) {
      pts.push({ x: x, y: crestFn(gx(x), base) });
    }

    ctx.save();
    if (blurPx > 0) ctx.filter = 'blur(' + blurPx + 'px)';

    ctx.beginPath();
    ctx.moveTo(pts[0].x, height);
    for (var i = 0; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.lineTo(pts[pts.length - 1].x, height);
    ctx.closePath();

    // Fades in from nothing well above its own peaks, so the top of the shape melts into the sky
    // rather than ending on a visible seam where the fill begins.
    var grad = ctx.createLinearGradient(0, base - 70, 0, height);
    grad.addColorStop(0, rgba(tone, 0));
    grad.addColorStop(0.3, rgba(tone, alpha * 0.6));
    grad.addColorStop(1, rgba(tone, alpha));
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.beginPath();
    for (var k = 0; k < pts.length; k++) {
      if (k === 0) ctx.moveTo(pts[k].x, pts[k].y);
      else ctx.lineTo(pts[k].x, pts[k].y);
    }
    ctx.strokeStyle = rgba(mixColor(tone, [180, 210, 230], 0.6), rimAlpha);
    ctx.lineWidth = 1.3;
    ctx.stroke();
    ctx.restore();
  }

  function drawBackdrop(p) {
    var horizon = height * HORIZON;
    var day = 1 - nightness;

    // Night keeps cool haze. Day pushes the far layers toward blue air so they sit behind the
    // front range instead of reading as the same dark cutout stacked three times.
    var farTone = mixColor(mixColor(p.b, [10, 22, 34], 0.45), [118, 148, 178], day);
    var midTone = mixColor(mixColor(p.a, [12, 26, 38], 0.28), [86, 108, 128], day);
    var farAlpha = 0.28 + day * 0.22;
    var midAlpha = 0.36 + day * 0.24;

    // Soft haze only - no canvas blur. Blur left rectangular soft boxes around the ridge fill
    // that read as patches once the front range sat over them.
    drawDistantRidge(farCrestAt, horizon - height * FAR_LIFT, farTone, farAlpha, 0, 0.07 + day * 0.05);
    drawDistantRidge(midCrestAt, horizon - height * MID_LIFT, midTone, midAlpha, 0, 0.09 + day * 0.06);
  }

  function drawRange(t, p) {
    var horizon = height * HORIZON;
    // Four times finer than the original 18px step, which would average the new relief straight
    // back out and leave the edge exactly as smooth as it was before.
    var step = Math.max(3, width / 420);

    // Both heights come from the profile's own bounds rather than from the samples on this screen.
    // Measuring the extremes of the visible crest would give each display a different snow line,
    // which is a seam - and the one place a seam is unmissable is a horizontal edge.
    var peak = horizon + CREST_MID - CREST_AMP;
    // Snow comes further down the mountain as the world accumulates it, so where the white starts
    // is a property of the world's age rather than a constant. Clamped well above the mean line:
    // left unbounded it eventually put the snow line under every peak in the range, and a range
    // that is white from crest to foot has no shape left to read.
    var snowReach = Math.max(0.40, SNOW_LINE - 0.30 * (snowAt(worldDays) - 0.18));
    var snowLine = horizon + CREST_MID - CREST_AMP * snowReach;

    // Only the craters that can touch this screen, resolved once rather than per crest sample.
    // A year-old world has dozens of them and all but a couple are somewhere else entirely.
    var leftEdge = gx(-step) - 900;
    var rightEdge = gx(width + step) + 900;
    visibleImpacts = [];
    for (var n = 0; n < impacts.length; n++) {
      var im = impacts[n];
      if (im.day > worldDays || worldDays - im.day > IMPACT_ERODE) continue;
      if (im.gx + im.radius * 1.7 < leftEdge || im.gx - im.radius * 1.7 > rightEdge) continue;
      visibleImpacts.push(im);
    }

    var crest = [];
    for (var x = -step; x <= width + step; x += step) {
      crest.push({ x: x, y: crestAt(gx(x), horizon) });
    }

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(crest[0].x, crest[0].y);
    for (var i = 1; i < crest.length; i++) ctx.lineTo(crest[i].x, crest[i].y);
    ctx.lineTo(crest[crest.length - 1].x, height);
    ctx.lineTo(crest[0].x, height);
    ctx.closePath();

    // Fully opaque rock: any alpha under 1 let the aurora and backdrop print through the crest,
    // which is what read as black blotches and as "wavy lines painted on the mountains".
    //
    // In daylight the range stops being a silhouette and becomes lit ground, which is most of
    // what makes the same landscape look like a different place at a different hour. Kept darker
    // than the noon sky so the silhouette still holds when the aurora is gone.
    var day = 1 - nightness;
    var rockHigh = mixColor(mixColor(p.a, [58, 92, 112], 0.55), [142, 152, 162], day);
    var rockMid = mixColor(mixColor(p.b, [18, 34, 48], 0.62), [92, 102, 112], day);
    var rockLow = mixColor([8, 18, 28], [54, 62, 70], day);
    var rockBase = mixColor([3, 7, 14], [32, 38, 44], day);

    // Vegetation on the low ground. Age opens the possibility; season picks the colour - spring
    // green, summer lush, autumn straw, winter frost - so the same slope reads as a year turning.
    var green = greenAt(worldDays);
    var season = seasonAt(worldDays);
    if (green > 0.01 || season.snowCover > 0.15) {
      var turf = season.turf;
      var turfDay = mixColor(turf, [Math.min(255, turf[0] + 28), Math.min(255, turf[1] + 24), Math.min(255, turf[2] + 18)], day);
      var wash = Math.max(green * 0.78, season.snowCover * 0.4);
      rockLow = mixColor(rockLow, turfDay, wash);
      rockBase = mixColor(rockBase, mixColor(turfDay, [20, 36, 24], 0.35), wash * 0.9);
      // Mid-slope frost in winter so the white is not only a summit cap.
      if (season.snowCover > 0.25) {
        rockMid = mixColor(rockMid, [220, 230, 240], season.snowCover * 0.28 * (0.45 + day * 0.55));
      }
    }

    var body = ctx.createLinearGradient(0, peak, 0, height);
    body.addColorStop(0, rgba(rockHigh, 1));
    body.addColorStop(0.2, rgba(rockMid, 1));
    body.addColorStop(0.55, rgba(rockLow, 1));
    body.addColorStop(1, rgba(rockBase, 1));
    ctx.fillStyle = body;
    ctx.fill();

    // Clipped to the silhouette for everything that follows, so the detail belongs to the range
    // instead of floating in the sky in front of it.
    ctx.clip();
    drawSlopes(peak, p);
    drawReliefShading(crest);
    drawFoothills(crest, horizon);
    drawTalus(crest);
    drawCraterScars();
    drawSnow(crest, peak, snowLine, p);
    ctx.restore();

    drawRim(crest, p);
    drawSpurs(crest, p);
    drawHaze(horizon, t, p);
  }

  /**
   * Directional face shading from the sun's side of the sky.
   *
   * A flat vertical wash cannot make a cutout look three-dimensional. Walking the crest and
   * darkening the faces that turn away from the sun is the cheapest way to give each peak a lit
   * side and a shadowed one, which is most of what the eye uses to read depth in a silhouette.
   */
  function drawReliefShading(crest) {
    if (crest.length < 3) return;

    // -1 at sunrise (light from the left), +1 at sunset (light from the right). Noon is overhead,
    // so the side contrast softens then rather than picking a false direction.
    var progress = clamp01((dayFrac - 0.25) / 0.5);
    var sunSide = progress * 2 - 1;
    var day = 1 - nightness;
    var strength = 0.16 + day * 0.38 + nightness * 0.12;
    if (strength < 0.04) return;

    var depth = height * (0.10 + day * 0.04);
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    for (var i = 0; i < crest.length - 1; i++) {
      var dx = crest[i + 1].x - crest[i].x;
      if (Math.abs(dx) < 0.001) continue;
      var slope = (crest[i + 1].y - crest[i].y) / dx;
      // Canvas y grows downward: a positive slope is the right face of a peak. Lit when that face
      // turns toward the sun, shaded when it turns away.
      var facing = -slope * sunSide;
      var shade = clamp01(0.42 - facing * 0.55 - Math.abs(sunSide) * 0.08 * (1 - day));
      // Overhead sun at noon softens left/right contrast; keep a little self-shadow either way.
      shade = shade * (0.55 + 0.45 * Math.abs(sunSide)) + (1 - Math.abs(sunSide)) * 0.12;
      shade = clamp01(shade) * strength;
      if (shade < 0.02) continue;

      ctx.beginPath();
      ctx.moveTo(crest[i].x, crest[i].y);
      ctx.lineTo(crest[i + 1].x, crest[i + 1].y);
      ctx.lineTo(crest[i + 1].x, crest[i + 1].y + depth);
      ctx.lineTo(crest[i].x, crest[i].y + depth);
      ctx.closePath();
      ctx.fillStyle = 'rgba(8,14,22,' + shade.toFixed(3) + ')';
      ctx.fill();
    }

    ctx.restore();
  }

  /**
   * Light on the high ground.
   *
   * A vertical wash rather than per-face shading. The aurora is a broad source directly overhead,
   * so what it actually picks out is height, and the clip does the rest: the wash only lands where
   * the range reaches up into it, which means the peaks are lit and the saddles between them stay
   * dark without either being drawn separately.
   */
  function drawSlopes(peak, p) {
    var day = 1 - nightness;
    var depth = height * (0.11 + day * 0.04);
    var wash = ctx.createLinearGradient(0, peak, 0, peak + depth);
    // Night: aurora coloured screen wash. Day: soft warm highlight on the high ground so peaks
    // catch the sun instead of staying a flat grey slab.
    if (day > 0.35) {
      wash.addColorStop(0, 'rgba(255,248,236,' + (0.16 * day).toFixed(3) + ')');
      wash.addColorStop(0.35, 'rgba(220,210,190,' + (0.06 * day).toFixed(3) + ')');
      wash.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.save();
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = wash;
      ctx.fillRect(0, peak, width, depth);
      ctx.restore();
      return;
    }

    wash.addColorStop(0, rgba(mixColor(p.a, [148, 194, 220], 0.35), 0.14));
    wash.addColorStop(0.4, rgba(mixColor(p.b, [62, 98, 122], 0.4), 0.055));
    wash.addColorStop(1, 'rgba(0,0,0,0)');

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = wash;
    ctx.fillRect(0, peak, width, depth);
    ctx.restore();
  }

  /**
   * A lower, softer echo of the crest inside the body.
   *
   * Not a second mountain range: the silhouette stays the one the aurora sits on. This is a faint
   * shoulder line about a third of the way down the face, so the dark fill below the rim has a
   * landform in it rather than reading as empty night.
   */
  function drawFoothills(crest, horizon) {
    var drop = height * 0.055;
    var day = 1 - nightness;
    ctx.save();
    ctx.globalCompositeOperation = day > 0.4 ? 'source-over' : 'screen';

    // Shoulder fill: a soft band under the crest so the face has a second landform, not only a
    // stroke. Day needs the fill; night keeps it quiet so it does not compete with the aurora.
    ctx.beginPath();
    ctx.moveTo(crest[0].x, crest[0].y);
    for (var i = 1; i < crest.length; i++) ctx.lineTo(crest[i].x, crest[i].y);
    for (var j = crest.length - 1; j >= 0; j--) {
      var edge = crest[j].y + drop + Math.sin(gx(crest[j].x) * 0.028 + 1.7) * 4.5;
      edge = Math.min(edge, horizon + height * 0.14);
      ctx.lineTo(crest[j].x, edge);
    }
    ctx.closePath();
    ctx.fillStyle = day > 0.4
      ? 'rgba(40,52,62,' + (0.14 * day).toFixed(3) + ')'
      : 'rgba(110,150,180,0.05)';
    ctx.fill();

    ctx.beginPath();
    for (var k = 0; k < crest.length; k++) {
      var line = crest[k].y + drop + Math.sin(gx(crest[k].x) * 0.028 + 1.7) * 4.5;
      line = Math.min(line, horizon + height * 0.14);
      if (k === 0) ctx.moveTo(crest[k].x, line);
      else ctx.lineTo(crest[k].x, line);
    }
    ctx.strokeStyle = day > 0.4
      ? 'rgba(28,38,46,' + (0.22 * day).toFixed(3) + ')'
      : 'rgba(110,150,180,0.16)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Soft bedding lines across the mid-slope.
   *
   * Several faint polylines that follow the crest a few dozen pixels down. They are not geology so
   * much as the suggestion of it: enough structure that the dark body stops reading as a flat
   * silhouette fill, quiet enough that they disappear under the aurora rather than competing with
   * it.
   */
  function drawTalus(crest) {
    var day = 1 - nightness;
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.lineWidth = 1;

    for (var band = 0; band < 3; band++) {
      var offset = height * (0.022 + band * 0.016);
      var wobble = 1.6 + band * 0.45;
      ctx.beginPath();
      for (var i = 0; i < crest.length; i++) {
        var y = crest[i].y + offset + Math.sin(gx(crest[i].x) * (0.05 + band * 0.018) + band * 1.3) * wobble;
        if (i === 0) ctx.moveTo(crest[i].x, y);
        else ctx.lineTo(crest[i].x, y);
      }
      var ink = 0.08 - band * 0.015 + day * 0.06;
      ctx.strokeStyle = 'rgba(16,36,52,' + ink.toFixed(3) + ')';
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * Snow on the crests that stand above the snow line.
   *
   * A region with a lower edge rather than an outline: a stroke along the crest reads as a white
   * wire laid over the mountains, because snow stops at a height and does not follow the rock.
   * Each run of crest above the line is closed along a wandering snow line and filled, then a
   * softer fringe is laid under that edge so the cap does not end in a hard cut.
   */
  function drawSnow(crest, peak, snowLine, p) {
    // Snow under an aurora is the colour of the aurora, so the white is pulled toward the palette
    // rather than left neutral against a sky that has no neutral in it. In daylight it goes back
    // to being snow - and it has to be opaque enough to read on lit rock, because screen-blend
    // white on a pale daytime face disappears.
    var day = 1 - nightness;
    var tone = mixColor(mixColor([214, 232, 250], p.a, 0.3), [248, 252, 255], day);

    // One gradient for every cap, keyed to the global peak and snow line rather than to each cap's
    // own extent, so a cap split across the seam is shaded identically in both halves.
    var topA = 0.34 + day * 0.42;
    var midA = 0.13 + day * 0.22;
    var shade = ctx.createLinearGradient(0, peak, 0, snowLine);
    shade.addColorStop(0, rgba(tone, topA));
    shade.addColorStop(0.5, rgba(tone, midA));
    shade.addColorStop(1, rgba(tone, 0));

    ctx.save();
    ctx.globalCompositeOperation = day > 0.4 ? 'source-over' : 'screen';
    ctx.fillStyle = shade;

    var cap = null;
    for (var i = 0; i < crest.length; i++) {
      var line = snowLineAt(gx(crest[i].x), snowLine);
      var above = crest[i].y < line;
      if (above) {
        if (!cap) cap = [];
        cap.push({ x: crest[i].x, y: crest[i].y, line: line });
      }
      // Flushed at the far side of the summit, and again at the end of the samples so a cap still
      // open when the screen runs out is drawn rather than dropped.
      if ((!above || i === crest.length - 1) && cap) {
        if (cap.length > 1) {
          fillCap(cap);
          fillSnowFringe(cap, tone);
        }
        cap = null;
      }
    }

    ctx.restore();
  }

  function fillCap(cap) {
    ctx.beginPath();
    ctx.moveTo(cap[0].x, cap[0].line);
    for (var i = 0; i < cap.length; i++) ctx.lineTo(cap[i].x, cap[i].y);
    ctx.lineTo(cap[cap.length - 1].x, cap[cap.length - 1].line);
    ctx.closePath();
    ctx.fill();
  }

  /** Soft falloff under a snow cap so the lower edge melts into rock instead of cutting it. */
  function fillSnowFringe(cap, tone) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.beginPath();
    ctx.moveTo(cap[0].x, cap[0].line);
    for (var i = 0; i < cap.length; i++) ctx.lineTo(cap[i].x, cap[i].line);
    for (var j = cap.length - 1; j >= 0; j--) {
      ctx.lineTo(cap[j].x, cap[j].line + 5 + Math.sin(gx(cap[j].x) * 0.27) * 1.5);
    }
    ctx.closePath();
    ctx.fillStyle = rgba(tone, 0.06);
    ctx.fill();
    ctx.restore();
  }

  /** A thin lit edge along the crest: the one line in the range that is the colour of the sky. */
  function drawRim(crest, p) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.beginPath();
    for (var i = 0; i < crest.length; i++) {
      if (i === 0) ctx.moveTo(crest[i].x, crest[i].y);
      else ctx.lineTo(crest[i].x, crest[i].y);
    }
    // At night the crest catches the aurora. In daylight the same edge has to go the other way,
    // because a lit range against a bright sky is defined by being darker than it, not brighter.
    if (nightness < 0.5) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = 'rgba(20,28,36,' + (0.62 * (1 - nightness)).toFixed(3) + ')';
      ctx.lineWidth = 1.7;
      ctx.stroke();
      ctx.globalCompositeOperation = 'screen';
    }

    ctx.strokeStyle = rgba(p.a, (0.22 + level * 0.06) * nightness);
    ctx.lineWidth = 1.35;
    ctx.stroke();

    // A second, softer pass just below the crest. On its own the rim is a wire; together they read
    // as a lit thickness of rock rather than a stroke.
    ctx.beginPath();
    for (var k = 0; k < crest.length; k++) {
      var y = crest[k].y + 1.6;
      if (k === 0) ctx.moveTo(crest[k].x, y);
      else ctx.lineTo(crest[k].x, y);
    }
    ctx.strokeStyle = rgba(mixColor(p.a, [160, 200, 230], 0.35), 0.08);
    ctx.lineWidth = 2.6;
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Short descending ridges off the secondary peaks.
   *
   * Only the sharper local minima in crest y (the peaks, not the cols) get one, and each spur is a
   * short diagonal stroke rather than a full face. They give the silhouette small shoulders without
   * changing the outline the aurora sits on.
   */
  function drawSpurs(crest, p) {
    var day = 1 - nightness;
    ctx.save();
    ctx.globalCompositeOperation = day > 0.4 ? 'source-over' : 'screen';
    ctx.strokeStyle = day > 0.4
      ? 'rgba(24,34,44,' + (0.28 * day).toFixed(3) + ')'
      : rgba(mixColor(p.a, [120, 160, 190], 0.4), 0.12);
    ctx.lineWidth = 1;

    // Same fixed-distance neighbours as the gullies, and for the same reason: at the fine sample
    // spacing almost every ripple in the relief is a local minimum, and a spur on each one turned
    // the rim into a fringe instead of marking the handful of peaks that actually stand out.
    var sampleGap = crest.length > 1 ? crest[1].x - crest[0].x : 1;
    var off = Math.max(1, Math.round(42 / Math.max(1, sampleGap)));

    for (var i = 3 * off; i < crest.length - 3 * off; i++) {
      var y = crest[i].y;
      if (y >= crest[i - off].y || y >= crest[i + off].y) continue;
      if (y >= crest[i - 2 * off].y || y >= crest[i + 2 * off].y) continue;

      // Skip mild humps: a spur on every micro-peak turns the rim into a fringe.
      var rise = Math.min(crest[i - 2 * off].y, crest[i + 2 * off].y) - y;
      if (rise < 8) continue;

      var gx0 = gx(crest[i].x);
      var lean = Math.sin(gx0 * 0.029 + 0.4) >= 0 ? 1 : -1;
      var length = 10 + rise * 0.55;
      ctx.beginPath();
      ctx.moveTo(crest[i].x, crest[i].y + 0.5);
      ctx.lineTo(crest[i].x + lean * length * 0.55, crest[i].y + length);
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * The cold band where the range meets the sky, from the original scene, now breathing.
   *
   * A five-minute period and an amplitude of about two thirds of the band's own opacity. It is the
   * only thing down here that moves at all, which is what keeps the range from reading as a still
   * image pasted under a moving one, and it is slow enough never to be caught doing it.
   */
  function drawHaze(horizon, t, p) {
    var day = 1 - nightness;
    var drift = Math.sin(t * 0.000021) * 0.5 + 0.5;
    var glow = ctx.createLinearGradient(0, horizon - 28, 0, horizon + 110);
    if (day > 0.4) {
      glow.addColorStop(0, 'rgba(210,228,242,0)');
      glow.addColorStop(0.4, 'rgba(176,200,222,' + (0.10 + 0.06 * drift).toFixed(3) + ')');
      glow.addColorStop(1, 'rgba(120,150,176,0)');
    } else {
      glow.addColorStop(0, rgba(p.a, 0));
      glow.addColorStop(0.45, rgba(p.a, 0.024 + 0.016 * drift));
      glow.addColorStop(1, rgba(p.b, 0));
    }
    ctx.fillStyle = glow;
    ctx.fillRect(0, horizon - 28, width, 140);
  }

  // ---------------------------------------------------------- living world

  /**
   * Grass on the lower face as short blade tufts.
   *
   * Filled ellipses looked like discs on the rock. At wallpaper distance grass is a texture of
   * thin strokes, so each meadow is only an anchor for a handful of blades that take seasonal
   * colour (green, straw, frost) without inventing a second landform.
   */
  function drawMeadows() {
    ensureLife();
    var green = greenAt(worldDays);
    var season = seasonAt(worldDays);
    if (meadows.length === 0) return;
    if (green < 0.02 && season.snowCover < 0.18) return;

    var horizon = height * HORIZON;
    var day = 1 - nightness;
    var turf = season.turf;
    var tone = mixColor(turf, [
      Math.min(255, turf[0] + 40),
      Math.min(255, turf[1] + 34),
      Math.min(255, turf[2] + 24)
    ], day * 0.55);
    // Winter blades go pale rather than staying a green tuft under snow.
    if (season.snowCover > 0.35) {
      tone = mixColor(tone, [230, 236, 244], season.snowCover * 0.85);
    }

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.lineCap = 'round';

    for (var i = 0; i < meadows.length; i++) {
      var md = meadows[i];
      if (worldDays < md.bornDay) continue;

      var grown = smoothstep((worldDays - md.bornDay) / md.growDays) * md.fertile;
      grown *= Math.max(green, season.snowCover * 0.45);
      if (grown < 0.05) continue;

      var x = (md.gx - originX) / pxPerCss;
      var crestY = crestAt(md.gx, horizon);
      var y = crestY + md.down * height;
      var span = md.span * (0.5 + grown * 0.7) / pxPerCss;
      if (x < -span * 2 || x > width + span * 2) continue;
      if (y < crestY + 2 || y > height - 2) continue;

      var bladeH = (2.2 + grown * 5.5) * (0.7 + season.grass * 0.5);
      var alpha = 0.16 + grown * 0.34;
      ctx.strokeStyle = rgba(tone, alpha);
      ctx.lineWidth = Math.max(0.6, 0.7 + grown * 0.5);

      var count = Math.max(4, Math.round(md.blades * (0.7 + grown * 0.85)));
      for (var b = 0; b < count; b++) {
        var u = (b + 0.5) / count;
        var ox = (u - 0.5) * span * 2.2 + Math.sin(md.phase + b * 1.7) * span * 0.14;
        var oy = Math.sin(md.phase * 1.3 + b * 2.1) * 2.4;
        var lean = Math.sin(md.phase + b * 0.9) * bladeH * 0.28;
        var h = bladeH * (0.7 + (b % 3) * 0.12);
        ctx.beginPath();
        ctx.moveTo(x + ox, y + oy);
        ctx.quadraticCurveTo(
          x + ox + lean * 0.4,
          y + oy - h * 0.55,
          x + ox + lean,
          y + oy - h);
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  /**
   * Spruce and deciduous stands that sprout and grow on the lower face of the range.
   *
   * Drawn as simple silhouettes on purpose: at wallpaper distance a forest is a texture of dark
   * spikes, and anything with trunks and branches turns into noise. Birth days are staggered and
   * growDays are long so warp speed shows the slope going green over minutes rather than flipping
   * a tint. Deciduous canopies take the season's colour; evergreens hold - until snow load paints
   * every canopy white the same way the rock gets capped.
   */
  function drawForest() {
    ensureLife();
    var cover = forestAt(worldDays);
    if (cover < 0.015 || trees.length === 0) return;

    var horizon = height * HORIZON;
    var day = 1 - nightness;
    var season = seasonAt(worldDays);
    var weather = weatherAt(worldDays);
    // Snow on trees follows ground cover and active snowfall so a green spruce does not sit
    // under a white sky while the slope is already winter.
    var snowLoad = clamp01(season.snowCover * 0.95 + (weather.snowfall || 0) * 0.55);
    var snowTone = mixColor([236, 242, 250], [248, 252, 255], day * 0.5);

    var evergreen = mixColor([18, 36, 28], [42, 72, 48], day * 0.55);
    var deciduous = mixColor(season.foliage, [42, 72, 48], day * 0.15);
    deciduous = mixColor(deciduous, [200, 206, 212], season.bare * 0.55);
    var trunk = mixColor([28, 22, 18], [56, 44, 34], day);

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    for (var i = 0; i < trees.length; i++) {
      var tr = trees[i];
      if (worldDays < tr.bornDay) continue;

      // Ease-in growth so the first half of growDays stays a sapling rather than a near-full tree.
      var age = smoothstep((worldDays - tr.bornDay) / tr.growDays);
      var grown = Math.pow(age, 1.55) * tr.fertile * cover;
      if (grown < 0.035) continue;

      var x = (tr.gx - originX) / pxPerCss;
      var h = tr.maxH * grown;
      if (x < -h * 2 || x > width + h * 2) continue;

      var crestY = crestAt(tr.gx, horizon);
      var y = crestY + tr.down * height + h * 0.15;
      // Keep off snow caps and out of the open sky above the ridge.
      if (y < crestY + 4 || y > height - 4) continue;

      var lean = tr.lean * h;
      var needle = tr.deciduous ? deciduous : evergreen;
      // Every tree takes snow - evergreen and deciduous alike - so winter is a white forest.
      needle = mixColor(needle, snowTone, snowLoad * (tr.deciduous ? 0.92 : 0.88));
      var canopyAlpha = 0.38 + grown * 0.45;
      if (tr.deciduous) canopyAlpha *= 1 - season.bare * (1 - snowLoad) * 0.55;

      // Trunk
      ctx.strokeStyle = rgba(trunk, 0.55 + grown * 0.35);
      ctx.lineWidth = Math.max(0.7, h * 0.06);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + lean * 0.3, y - h * 0.55);
      ctx.stroke();

      // Bare winter deciduous without snow: thin branch forks. With snow, keep a frosted canopy.
      if (tr.deciduous && season.bare > 0.55 && canopyAlpha < 0.28 && snowLoad < 0.35) {
        ctx.strokeStyle = rgba(trunk, 0.35 + grown * 0.25);
        ctx.lineWidth = Math.max(0.5, h * 0.03);
        for (var b = 0; b < 3; b++) {
          var by = y - h * (0.35 + b * 0.15);
          ctx.beginPath();
          ctx.moveTo(x + lean * 0.2, by);
          ctx.lineTo(x + lean * 0.2 - h * 0.18, by - h * 0.12);
          ctx.moveTo(x + lean * 0.2, by);
          ctx.lineTo(x + lean * 0.2 + h * 0.16, by - h * 0.1);
          ctx.stroke();
        }
        continue;
      }

      // Three stacked triangles - a spruce / canopy at wallpaper scale.
      for (var tier = 0; tier < 3; tier++) {
        var ty = y - h * (0.22 + tier * 0.22);
        var tw = h * (0.42 - tier * 0.09) * (tr.deciduous ? 1.08 : 1);
        var th = h * (0.28 - tier * 0.04) * (tr.deciduous ? 0.92 : 1);
        var tipX = x + lean * (0.15 + tier * 0.1);
        var tipY = ty - th;
        var leftX = x - tw + lean * 0.1;
        var rightX = x + tw + lean * 0.1;
        var baseY = ty + th * 0.35;

        ctx.beginPath();
        ctx.moveTo(tipX, tipY);
        ctx.lineTo(leftX, baseY);
        ctx.lineTo(rightX, baseY);
        ctx.closePath();
        ctx.fillStyle = rgba(needle, canopyAlpha - tier * 0.05);
        ctx.fill();

        // Snow settles on the upper faces: a lighter wedge on each tier when winter is in.
        if (snowLoad > 0.2) {
          var snowA = (0.22 + snowLoad * 0.55 - tier * 0.04) * grown;
          ctx.beginPath();
          ctx.moveTo(tipX, tipY);
          ctx.lineTo(lerp(tipX, leftX, 0.55), lerp(tipY, baseY, 0.45));
          ctx.lineTo(lerp(tipX, rightX, 0.55), lerp(tipY, baseY, 0.45));
          ctx.closePath();
          ctx.fillStyle = rgba(snowTone, snowA);
          ctx.fill();
        }
      }
    }

    ctx.restore();
  }

  /**
   * Rain streaks and snowfall flakes driven by the season's weather wish.
   *
   * Positions are pure functions of wall time and worldSeed so both monitors agree, and intensity
   * comes from weatherAt so spring showers and winter storms arrive with the year rather than
   * as a separate clock.
   */
  function drawPrecipitation(t, weather) {
    ensurePrecip();
    var rain = weather.rain || 0;
    var snow = weather.snowfall || 0;
    if ((rain < 0.04 && snow < 0.04) || precip.length === 0) return;

    var day = 1 - nightness;
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    if (rain >= snow && rain > 0.04) {
      var rainA = 0.08 + rain * 0.22;
      ctx.strokeStyle = 'rgba(' + Math.round(170 + day * 40) + ',' +
        Math.round(190 + day * 30) + ',' + Math.round(210 + day * 20) + ',' +
        rainA.toFixed(3) + ')';
      ctx.lineWidth = 1;
      var count = Math.floor(precip.length * clamp01(0.35 + rain * 0.9));
      for (var i = 0; i < count; i++) {
        var d = precip[i];
        var fall = mod(d.y + t * 0.00055 * d.speed, 1.15);
        var globalX = mod(d.gx + t * d.drift * 0.02, PARTICLE_WRAP) - PARTICLE_WRAP * 0.5;
        var x = (globalX - originX) / pxPerCss;
        var y = fall * height * 1.05 - height * 0.02;
        if (x < -4 || x > width + 4) continue;
        var len = 6 + d.size * 7 * (0.6 + rain);
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + d.drift * 4, y + len);
        ctx.stroke();
      }
    } else if (snow > 0.04) {
      var snowA = 0.12 + snow * 0.35;
      ctx.fillStyle = 'rgba(236,242,250,' + snowA.toFixed(3) + ')';
      var flakes = Math.floor(precip.length * clamp01(0.4 + snow * 0.85));
      for (var s = 0; s < flakes; s++) {
        var f = precip[s];
        var fy = mod(f.y + t * 0.00018 * f.speed, 1.12);
        var sway = Math.sin(t * 0.0011 + f.phase * 6.28) * 18;
        var sgx = mod(f.gx + t * f.drift * 0.012 + sway, PARTICLE_WRAP) - PARTICLE_WRAP * 0.5;
        var sx = (sgx - originX) / pxPerCss;
        var sy = fy * height * 1.05 - height * 0.02;
        if (sx < -6 || sx > width + 6) continue;
        var r = 0.7 + f.size * 1.1;
        ctx.beginPath();
        ctx.arc(sx, sy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
  }

  /**
   * Settlements that appear one valley at a time and then densify.
   *
   * Day: dark roof blocks and a thin chimney plume. Night: warm windows and a soft hearth glow.
   * That day/night split is what sells "people live here" rather than "orange dots on a mountain".
   */
  function drawCivilization() {
    ensureLife();
    if (hamlets.length === 0) return;

    var horizon = height * HORIZON;
    var day = 1 - nightness;
    var civ = civAt(worldDays);
    if (civ < 0.02) return;

    ctx.save();

    for (var i = 0; i < hamlets.length; i++) {
      var ham = hamlets[i];
      if (worldDays < ham.bornDay) continue;

      var grown = smoothstep((worldDays - ham.bornDay) / ham.growDays) * civ;
      if (grown < 0.05) continue;

      var x = (ham.gx - originX) / pxPerCss;
      var crestY = crestAt(ham.gx, horizon);
      var y = crestY + ham.down * height;
      var rooms = Math.max(1, Math.round(ham.rooms * grown));
      var span = rooms * 5.2 * (0.7 + grown * 0.5);
      if (x < -span || x > width + span) continue;

      // Path stub climbing from the foot - appears once the hamlet is established.
      if (grown > 0.45) {
        ctx.strokeStyle = 'rgba(36,32,28,' + (0.18 * grown * (0.5 + day * 0.5)).toFixed(3) + ')';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, Math.min(height - 2, y + 18));
        ctx.quadraticCurveTo(x + 10, y + 8, x, y + 2);
        ctx.stroke();
      }

      // Roof line
      ctx.fillStyle = 'rgba(22,26,32,' + (0.55 + grown * 0.35).toFixed(3) + ')';
      for (var r = 0; r < rooms; r++) {
        var rx = x - span * 0.5 + r * (span / rooms) + 1;
        var rw = span / rooms - 1.5;
        var rh = 3.2 + grown * 2.4;
        ctx.fillRect(rx, y - rh, rw, rh);
        // Peak
        ctx.beginPath();
        ctx.moveTo(rx - 0.5, y - rh);
        ctx.lineTo(rx + rw * 0.5, y - rh - 2.4 * grown);
        ctx.lineTo(rx + rw + 0.5, y - rh);
        ctx.closePath();
        ctx.fill();
      }

      // Windows / hearth - night only, otherwise the village reads as cardboard.
      if (nightness > 0.15) {
        var glow = ctx.createRadialGradient(x, y - 2, 0, x, y - 2, 28 + rooms * 4);
        glow.addColorStop(0, 'rgba(255,170,90,' + (0.22 * grown * ham.warmth * nightness).toFixed(3) + ')');
        glow.addColorStop(0.45, 'rgba(255,120,60,' + (0.08 * grown * nightness).toFixed(3) + ')');
        glow.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = glow;
        ctx.fillRect(x - 40, y - 40, 80, 70);
        ctx.globalCompositeOperation = 'source-over';

        for (var w = 0; w < rooms; w++) {
          var wx = x - span * 0.5 + w * (span / rooms) + span / rooms * 0.3;
          ctx.fillStyle = 'rgba(255,196,120,' + (0.55 * grown * ham.warmth * nightness).toFixed(3) + ')';
          ctx.fillRect(wx, y - 3.6 * grown, 1.6, 1.8);
        }
      }

      // Daytime smoke so civilization still shows when the sun is up.
      if (ham.smoke && grown > 0.35 && day > 0.25) {
        var sx = x + span * 0.15;
        var sy = y - 6 * grown;
        var plume = ctx.createLinearGradient(sx, sy, sx, sy - 22);
        plume.addColorStop(0, 'rgba(160,168,176,' + (0.22 * day * grown).toFixed(3) + ')');
        plume.addColorStop(1, 'rgba(160,168,176,0)');
        ctx.fillStyle = plume;
        ctx.beginPath();
        ctx.moveTo(sx - 1, sy);
        ctx.quadraticCurveTo(sx + 4 + Math.sin(worldDays * 3.1 + i) * 3, sy - 12, sx + 2, sy - 22);
        ctx.quadraticCurveTo(sx - 2, sy - 12, sx + 1, sy);
        ctx.fill();
      }
    }

    ctx.restore();
  }

  /**
   * Dark bowls painted onto the face so a crater is readable as a scar, not only as a dent in the
   * silhouette. The crest displacement alone is too subtle at warp when the dial is flying.
   */
  function drawCraterScars() {
    if (visibleImpacts.length === 0) return;

    var horizon = height * HORIZON;
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    for (var i = 0; i < visibleImpacts.length; i++) {
      var im = visibleImpacts[i];
      if (im.day > worldDays) continue;
      var since = worldDays - im.day;
      var settled = smoothstep(since / 1.2);
      var weathered = 1 - smoothstep(since / IMPACT_ERODE);
      var strength = settled * weathered;
      if (strength < 0.04) continue;

      var x = (im.gx - originX) / pxPerCss;
      var y = crestAt(im.gx, horizon) + im.depth * 0.35;
      var rx = (im.radius * 0.55) / pxPerCss;
      var ry = Math.max(3, im.depth * 0.55);
      if (x < -rx || x > width + rx) continue;

      ctx.beginPath();
      ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(6,10,16,' + (0.55 * strength).toFixed(3) + ')';
      ctx.fill();

      // Raised rim catch-light
      ctx.strokeStyle = 'rgba(170,186,200,' + (0.18 * strength * (0.4 + (1 - nightness) * 0.6)).toFixed(3) + ')';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.ellipse(x, y - ry * 0.15, rx * 0.92, ry * 0.7, 0, Math.PI * 1.05, Math.PI * 1.95);
      ctx.stroke();
    }

    ctx.restore();
  }

  // --------------------------------------------------------------------- loop

  function draw(t, dt) {
    // The host ticks at 30Hz, so a fast flick arrives as a teleport rather than as motion, and the
    // curtains chasing it at the old rate covered a fifth of the screen in a single frame. A 200ms
    // time constant still reaches the pointer well inside the time it takes to notice it has
    // stopped, and it is the difference between the aurora being pushed and being snapped.
    cursor.x = approach(cursor.x, cursorTarget.x, 5.0, dt);
    cursor.y = approach(cursor.y, cursorTarget.y, 5.0, dt);
    presence = approach(presence, presenceTarget, 2.6, dt);

    // Slower than the pointer itself follows. Changing mode moves every curtain in the scene at
    // once, and a change of that size has to take long enough to read as the aurora settling
    // rather than as the picture being replaced.
    attractMix = approach(attractMix, cursorMotion === CURSOR_ATTRACT ? 1 : 0, 1.6, dt);
    repelMix = approach(repelMix, cursorMotion === CURSOR_REPEL ? 1 : 0, 1.6, dt);

    // Energy decays on its own between ticks: a stationary pointer reports no velocity at all
    // rather than reporting zero.
    energyTarget = approach(energyTarget, 0, 2.2, dt);
    energy = approach(energy, energyTarget, 5.0, dt);

    level = approach(level, audioReactive ? levelTarget : 0, 7.0, dt);
    bass = approach(bass, audioReactive ? bassTarget : 0, 9.0, dt);
    treble = approach(treble, audioReactive ? trebleTarget : 0, 12.0, dt);

    // A beat is an impulse, not a level: it is set on detection and decays on its own. Easing it
    // toward a target would round off the attack, which is the part that reads as a beat.
    pulse = audioReactive ? pulse * Math.exp(-3.4 * dt) : 0;

    // The world is advanced once per frame and everything below reads the result, so a single
    // frame can never be drawn from two different ages.
    var wall = t + EPOCH;
    syncWorld(wall);
    worldDays = ageInDays(wall);
    worldGrowth = growth(worldDays);
    refreshImpacts(worldDays);

    // Where the sun is, and therefore whether any of the night's features are on show at all.
    dayFrac = dayFraction(wall);
    sunAlt = sunHeight(dayFrac);
    nightness = 1 - smoothstep((sunAlt + 0.14) / 0.30);

    var weather = weatherAt(worldDays);
    stormNow = stormAt(worldDays);
    auroraDetail = worldGrowth;
    auroraStorm = stormNow ? stormNow.strength : 0;
    starVisibility = 1 - weather.cloud * 0.8;

    var p = paletteAt(t);
    sky(t, p);
    drawStars(t);
    drawSun(dayFrac, p);
    drawMoon(p, weather);
    drawAurora(t, p);
    // Clouds sit below the aurora and above everything else in the sky, so they pass in front of
    // the curtains and the moon the way real cloud does.
    drawClouds(t, p, weather);
    drawParticles(t, p);
    drawBackdrop(p);
    drawRange(t, p);
    drawMeadows();
    drawForest();
    drawCivilization();
    // Last, so a strike lights the range it just hit rather than being drawn behind it.
    drawImpacts(p);
    // Precipitation sits in front of the landscape so rain and snow read as weather in the air.
    drawPrecipitation(t, weather);
  }

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);
    var interval = 1000 / (maxFps || 30);
    if (lastFrame && now - lastFrame < interval - 0.5) return;

    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.25) : 0;
    lastFrame = now;

    // The shared timeline, not a per-instance accumulator. Two displays must be at the same point
    // in the animation, and one that was paused has to rejoin where the other one got to.
    draw(Date.now() - EPOCH, dt);

    frames++;
    beatFrames++;
    stamps.push(now);

    if (!lastBeat) lastBeat = now;
    else if (now - lastBeat >= 1000) {
      post({
        v: SCHEMA,
        type: 'heartbeat',
        fps: Math.round(beatFrames * 10000 / (now - lastBeat)) / 10,
        // The host's only evidence of stutter: it compares this against fps to decide whether to
        // ask the scene to scale down, and a mean rate cannot tell an even cadence from a hitching
        // one.
        fpsFloor: worstFps(),
        frames: frames
      });
      lastBeat = now;
      beatFrames = 0;
      stamps = stamps.length ? [stamps[stamps.length - 1]] : [];
    }
  }

  // The slowest frame since the last heartbeat, as a rate. Scoped to the interval rather than a
  // rolling window: the host counts consecutive bad heartbeats, so a longer window reports one
  // hitch several times over and makes it look like sustained stutter.
  function worstFps() {
    if (stamps.length < 3) return 0;

    var worst = 0;
    for (var i = 1; i < stamps.length; i++) {
      var gap = stamps[i] - stamps[i - 1];
      if (gap > worst) worst = gap;
    }

    return worst > 0 ? Math.round(10000 / worst) / 10 : 0;
  }

  function start() {
    if (rafHandle) return;
    lastFrame = 0;
    lastBeat = 0;
    beatFrames = 0;
    // A pause is a gap of arbitrary length between two rendered frames. Left in the window it is
    // reported as the worst frame of the next second, and the host reads a resume as catastrophic
    // stutter.
    stamps.length = 0;
    rafHandle = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  // ----------------------------------------------------------------- messages

  function applyOptions(options) {
    if (!options) return;

    if (options.cursorMotion === CURSOR_ATTRACT ||
        options.cursorMotion === CURSOR_REPEL ||
        options.cursorMotion === CURSOR_OFF) {
      cursorMotion = options.cursorMotion;
    }

    if (typeof options.audioReactive === 'string') {
      audioReactive = options.audioReactive === 'true';
    }

    if (typeof options.dayNightCycle === 'string') {
      dayNightCycle = options.dayNightCycle === 'true';
    }

    if (options.fixedSky === 'day' || options.fixedSky === 'night') {
      fixedSky = options.fixedSky;
    }

    // The dial rescales the whole of the world's history rather than only what happens next, so
    // moving it jumps the world to the age it would have been at that rate. That is what makes it
    // useful for looking at day 40 without waiting, and it is why the default is the real rate.
    if (typeof options.evolutionSpeed === 'string' &&
        Object.prototype.hasOwnProperty.call(SPEEDS, options.evolutionSpeed)) {
      evolutionRate = SPEEDS[options.evolutionSpeed];
    }
  }

  /**
   * Adopts the initial mode outright instead of easing into it.
   *
   * The mode carried by life.init is not a change, it is where the scene starts; easing from the
   * built-in default would show a second of attract on a desktop configured for repel. Called
   * unconditionally, because an init with no options block still settles on the default.
   */
  function settleMode() {
    if (modeSettled) return;
    modeSettled = true;
    attractMix = cursorMotion === CURSOR_ATTRACT ? 1 : 0;
    repelMix = cursorMotion === CURSOR_REPEL ? 1 : 0;
  }

  function applyCursor(c) {
    // onDisplay false still carries the last on-display position, so the response fades out from
    // where the pointer left instead of freezing there or snapping to an edge.
    if (c.onDisplay === false) {
      presenceTarget = 0;
      return;
    }

    presenceTarget = 1;
    if (typeof c.x === 'number') cursorTarget.x = c.x;
    if (typeof c.y === 'number') cursorTarget.y = c.y;

    // vx/vy are the change since the previous tick in normalized units, not a rate per second. A
    // brisk sweep is around 0.04 of the width per tick, which is what saturates the flare.
    var vx = typeof c.vx === 'number' ? c.vx : 0;
    var vy = typeof c.vy === 'number' ? c.vy : 0;
    energyTarget = Math.max(energyTarget, Math.min(1, Math.sqrt(vx * vx + vy * vy) / 0.04));
  }

  function applyAudio(a) {
    // active is the host's silence gate. Honouring it is what keeps the curtains from sitting at a
    // permanently boosted size on a quiet desktop.
    if (!a || !a.active) {
      levelTarget = 0;
      bassTarget = 0;
      trebleTarget = 0;
      return;
    }

    // Expanded rather than used raw. RMS of ordinary music sits low - a loud track measures
    // around 0.1 to 0.3, not 1 - so passing it straight through makes the difference between
    // silence and a track about as large as the scene's own drift, which is to say invisible.
    // The square root is the usual perceptual curve and it lifts the quiet end where the
    // interesting variation is.
    levelTarget = typeof a.rms === 'number' ? Math.min(1, Math.sqrt(Math.max(0, a.rms)) * 1.3) : 0;

    var b = a.bands;
    if (!b || b.length < BAND_COUNT) return;

    // Three numbers out of sixteen. The curtains are broad, slow shapes and cannot show a
    // sixteen-band spectrum without turning into a graph, so the bands are folded into the
    // qualities the scene actually has: size, swell and sparkle.
    var low = 0, high = 0;
    for (var i = 0; i < 4; i++) low += b[i];
    for (var j = BAND_COUNT - 5; j < BAND_COUNT; j++) high += b[j];

    bassTarget = Math.min(1, Math.sqrt(low / 4) * 1.25);
    trebleTarget = Math.min(1, Math.sqrt(high / 5) * 1.25);

    // Onset detection against a slow running mean of the low end. Loudness alone makes the
    // curtains breathe with the track; this is what makes them move *on* it, which is the
    // difference between reacting to music and reacting to volume.
    bassAverage = bassAverage * 0.92 + bassTarget * 0.08;
    var jump = bassTarget - bassAverage;
    if (jump > 0.06) pulse = Math.min(1, pulse + jump * 2.6);
  }

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { return; }
    }
    if (!msg || typeof msg.type !== 'string') return;

    switch (msg.type) {
      case 'life.init':
        if (msg.performance && msg.performance.maxFps) maxFps = msg.performance.maxFps;
        applyOptions(msg.options);
        settleMode();
        resize();
        placeOnDesktop(msg.display);
        break;
      case 'life.pause':
        stop();
        break;
      case 'life.resume':
        start();
        break;
      case 'life.resize':
        resize();
        placeOnDesktop(msg.display);
        break;
      case 'life.destroy':
        stop();
        break;
      case 'env.tick':
        if (msg.cursor) applyCursor(msg.cursor);
        if (msg.audio) applyAudio(msg.audio);
        break;
      case 'rt.options':
        applyOptions(msg.options);
        break;
      case 'rt.performance':
        if (msg.maxFps) maxFps = msg.maxFps;
        break;
      default:
        break;
    }
  }

  window.addEventListener('resize', function () {
    resize();
    skyKey = '';
  });
  window.addEventListener('error', function (e) {
    post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });

  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) {
      onMessage(e.data);
    });
  }

  resize();
  loadWorld();
  seed();
  post({ v: SCHEMA, type: 'ready', sceneId: sceneId, renderer: 'canvas2d' });
  start();
})();
