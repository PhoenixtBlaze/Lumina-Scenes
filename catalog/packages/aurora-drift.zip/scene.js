// Aurora Drift - aurora borealis over a detailed range, for Lumina.
//
// Canvas2D, offline, no external assets. Soft vertical shafts of light rather
// than stroked waves or thin vertical folds: those two shapes were what made
// earlier versions read as a line drawing instead of a sky.
(function () {
  'use strict';

  var SCHEMA = 1;
  var canvas = document.getElementById('scene');
  var ctx = canvas.getContext('2d', { alpha: false });
  var sceneId = document.body.dataset.sceneId || 'aurora-drift';

  var width = 0, height = 0, dpr = 1;
  var maxFps = 30;
  var rafHandle = 0, lastFrame = 0, lastBeat = 0;
  var beatFrames = 0, frames = 0, elapsed = 0;
  var stamps = [];

  // Soft half-resolution buffer for the aurora. Blur is expensive at full
  // resolution and the light is meant to be atmospheric rather than sharp, so
  // drawing it small and scaling up is both cheaper and closer to the look.
  var auroraCanvas = document.createElement('canvas');
  var auroraCtx = auroraCanvas.getContext('2d');

  var palettes = [
    { tip: [170, 110, 255], core: [48, 255, 168], base: [30, 210, 200] },
    { tip: [210, 90, 255], core: [60, 255, 150], base: [40, 220, 230] },
    { tip: [120, 140, 255], core: [70, 255, 140], base: [35, 230, 190] },
    { tip: [255, 100, 200], core: [55, 250, 175], base: [40, 200, 255] },
    { tip: [140, 100, 255], core: [40, 245, 200], base: [80, 255, 150] }
  ];
  var paletteIndex = 0;
  var currentPalette = palettes[0];
  var targetPalette = palettes[1];
  var paletteBlend = 0;
  var nextPaletteAt = 50000;

  var curtains = [];
  var stars = [];

  // ----------------------------------------------------------------- helpers

  function post(message) {
    if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(message);
  }

  function rgba(c, a) {
    return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + a + ')';
  }

  function mix(a, b, t) {
    return [
      a[0] + (b[0] - a[0]) * t,
      a[1] + (b[1] - a[1]) * t,
      a[2] + (b[2] - a[2]) * t
    ];
  }

  function palette() {
    return {
      tip: mix(currentPalette.tip, targetPalette.tip, paletteBlend),
      core: mix(currentPalette.core, targetPalette.core, paletteBlend),
      base: mix(currentPalette.base, targetPalette.base, paletteBlend)
    };
  }

  function approach(current, target, rate, dt) {
    return current + (target - current) * (1 - Math.exp(-rate * dt));
  }

  // -------------------------------------------------------------------- seed

  function seed() {
    // A few curtain fields that paint as one continuous glow, not as separate
    // ribbons or pillars. Parameters drive a height field sampled densely so
    // neighbouring strips overlap and the eye never sees the samples.
    curtains = [
      { phase: 0.2, speed: 0.000014, y: 0.16, len: 0.42, amp: 0.035, freq: 1.2, intensity: 0.75, tip: 0.55 },
      { phase: 1.7, speed: 0.000011, y: 0.22, len: 0.36, amp: 0.028, freq: 1.8, intensity: 0.55, tip: 0.35 },
      { phase: 3.1, speed: 0.000009, y: 0.28, len: 0.30, amp: 0.022, freq: 0.85, intensity: 0.4, tip: 0.2 }
    ];

    stars = [];
    for (var s = 0; s < 220; s++) {
      stars.push({
        x: (s * 0.6180339887) % 1,
        y: ((s * 0.3819660113) % 0.72),
        r: 0.35 + (s % 5) * 0.22,
        a: 0.2 + (s % 7) * 0.08,
        phase: s * 0.37,
        speed: 0.00035 + (s % 9) * 0.00008
      });
    }
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.max(1, Math.round(width * dpr));
    canvas.height = Math.max(1, Math.round(height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    auroraCanvas.width = Math.max(1, Math.round(width * dpr * 0.5));
    auroraCanvas.height = Math.max(1, Math.round(height * dpr * 0.5));
  }

  // --------------------------------------------------------------------- sky

  function sky(p) {
    var g = ctx.createLinearGradient(0, 0, 0, height);
    g.addColorStop(0, '#01030a');
    g.addColorStop(0.4, '#020817');
    g.addColorStop(0.72, '#051420');
    g.addColorStop(1, '#01050b');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, width, height);

    // Vertical wash only - a radial centred on the screen would brighten each
    // display differently and break a multi-monitor desktop.
    var wash = ctx.createLinearGradient(0, height * 0.15, 0, height * 0.7);
    wash.addColorStop(0, rgba(p.tip, 0.02));
    wash.addColorStop(0.45, rgba(p.core, 0.05));
    wash.addColorStop(1, rgba(p.base, 0));
    ctx.fillStyle = wash;
    ctx.fillRect(0, 0, width, height);
  }

  function drawStars(t) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      ctx.globalAlpha = s.a * (0.75 + 0.25 * Math.sin(t * s.speed + s.phase));
      ctx.fillStyle = '#d9efff';
      ctx.beginPath();
      ctx.arc(s.x * width, s.y * height, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // ------------------------------------------------------------------ aurora

  /**
   * Soft aurora without ribbons or pillars.
   *
   * Built from large overlapping radial glows anchored along a few drifting
   * arcs. Continuous filled sheets read as waves; dense fillRect strips read
   * as vertical lines; soft clouds of light are what is left that still looks
   * like the northern lights.
   */
  function drawAurora(t, p) {
    var aw = auroraCanvas.width;
    var ah = auroraCanvas.height;
    if (aw < 2 || ah < 2) return;

    auroraCtx.setTransform(1, 0, 0, 1, 0, 0);
    auroraCtx.clearRect(0, 0, aw, ah);
    auroraCtx.globalCompositeOperation = 'lighter';

    // Sky bowl the aurora sits in.
    var bowl = auroraCtx.createRadialGradient(aw * 0.5, ah * 0.32, 0, aw * 0.5, ah * 0.32, aw * 0.58);
    bowl.addColorStop(0, rgba(p.core, 0.16));
    bowl.addColorStop(0.45, rgba(p.base, 0.05));
    bowl.addColorStop(1, 'rgba(0,0,0,0)');
    auroraCtx.fillStyle = bowl;
    auroraCtx.fillRect(0, 0, aw, ah);

    for (var i = 0; i < curtains.length; i++) {
      drawAuroraArc(auroraCtx, curtains[i], t, p, aw, ah);
    }

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.drawImage(auroraCanvas, 0, 0, width, height);
    ctx.restore();
  }

  function drawAuroraArc(aCtx, c, t, p, aw, ah) {
    var tip = mix(p.tip, p.core, c.tip);
    var pulse = 0.88 + 0.12 * Math.sin(t * c.speed * 1.5 + c.phase);
    // A handful of large soft patches along the arc - not enough to look like
    // a dotted line, not so few that each reads as its own object.
    var patches = 11;

    for (var i = 0; i < patches; i++) {
      var u = i / (patches - 1);
      var nx = u + Math.sin(t * c.speed + c.phase + i * 0.9) * 0.025;
      var cy = (curtainTop(c, nx, t) + curtainLen(c, nx, t) * 0.32) * ah;
      var cx = nx * aw;
      var rx = aw * (0.16 + 0.06 * Math.sin(i * 2.1 + c.phase));
      var ry = ah * (0.1 + 0.04 * Math.sin(i * 1.4 + c.phase * 0.6)) * (0.9 + 0.2 * c.len);
      var a = c.intensity * pulse * (0.45 + 0.55 * Math.sin(u * Math.PI));
      var tilt = Math.sin(c.phase + i * 0.55) * 0.2;

      var g = aCtx.createRadialGradient(cx, cy - ry * 0.3, 0, cx, cy, Math.max(rx, ry));
      g.addColorStop(0, rgba(tip, 0.2 * a));
      g.addColorStop(0.22, rgba(p.core, 0.26 * a));
      g.addColorStop(0.5, rgba(p.core, 0.09 * a));
      g.addColorStop(0.78, rgba(p.base, 0.025 * a));
      g.addColorStop(1, 'rgba(0,0,0,0)');
      aCtx.fillStyle = g;
      aCtx.beginPath();
      aCtx.ellipse(cx, cy, rx, ry, tilt, 0, Math.PI * 2);
      aCtx.fill();
    }

    // A longer, fainter veil under the patches so they join into one curtain
    // of light rather than a row of separate orbs.
    var veilY = curtainTop(c, 0.5, t) * ah + c.len * ah * 0.35;
    var veil = aCtx.createRadialGradient(aw * 0.5, veilY, 0, aw * 0.5, veilY, aw * 0.62);
    veil.addColorStop(0, rgba(p.core, 0.18 * c.intensity * pulse));
    veil.addColorStop(0.4, rgba(p.base, 0.07 * c.intensity * pulse));
    veil.addColorStop(1, 'rgba(0,0,0,0)');
    aCtx.fillStyle = veil;
    aCtx.fillRect(0, veilY - ah * 0.28, aw, ah * 0.6);
  }

  function curtainTop(c, nx, t) {
    return c.y +
      Math.sin(nx * Math.PI * c.freq + c.phase + t * c.speed) * c.amp +
      Math.sin(nx * Math.PI * (c.freq * 0.37) - c.phase * 0.7 + t * c.speed * 0.55) * c.amp * 0.5 +
      Math.sin(t * c.speed * 0.4 + c.phase) * 0.012;
  }

  function curtainLen(c, nx, t) {
    return c.len * (
      0.82 +
      0.12 * Math.sin(nx * Math.PI * 1.3 + c.phase + t * c.speed) +
      0.06 * Math.sin(nx * Math.PI * 2.7 - c.phase + t * c.speed * 1.1)
    );
  }

  // ------------------------------------------------------------------- range

  var HORIZON = 0.76;
  var CREST_MID = 14;
  var CREST_AMP = 58;
  var SNOW_LINE = 0.28;

  function crestAt(x, horizon) {
    // Richer than a three-sine silhouette: enough octaves that the edge is
    // broken rock, still one continuous range rather than stacked layers.
    var rough = 0.4 + 0.6 * (Math.sin(x * 0.0055 + 0.4) * 0.5 + 0.5);
    return horizon + CREST_MID +
      Math.sin(x * 0.011) * 22 +
      Math.sin(x * 0.027 + 1.1) * 14 +
      Math.sin(x * 0.053 + 0.6) * 8 +
      Math.sin(x * 0.097 + 2.0) * 4.5 +
      rough * (
        Math.sin(x * 0.19 + 1.4) * 2.4 +
        Math.sin(x * 0.37 + 2.8) * 1.3 +
        Math.sin(x * 0.71 + 0.5) * 0.7 +
        Math.sin(x * 1.35 + 3.1) * 0.35);
  }

  function snowLineAt(x, base) {
    return base +
      Math.sin(x * 0.067 + 0.8) * 4.5 +
      Math.sin(x * 0.17 + 2.2) * 2.0;
  }

  function drawRange(t, p) {
    var horizon = height * HORIZON;
    var step = Math.max(2, width / 520);
    var peak = horizon + CREST_MID - CREST_AMP;
    var snowLine = horizon + CREST_MID - CREST_AMP * SNOW_LINE;

    // Far and mid ridges first, so the main range sits in front of them.
    drawFarRidge(horizon, step, p, 0.055, 0.55, 0.12);
    drawFarRidge(horizon, step, p, 0.028, 0.72, 0.2);

    var crest = [];
    for (var x = -step; x <= width + step; x += step) {
      crest.push({ x: x, y: crestAt(x, horizon) });
    }

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(crest[0].x, crest[0].y);
    for (var i = 1; i < crest.length; i++) ctx.lineTo(crest[i].x, crest[i].y);
    ctx.lineTo(crest[crest.length - 1].x, height);
    ctx.lineTo(crest[0].x, height);
    ctx.closePath();

    var body = ctx.createLinearGradient(0, horizon, 0, height);
    body.addColorStop(0, 'rgba(2,10,16,0.35)');
    body.addColorStop(0.18, 'rgba(1,6,11,0.92)');
    body.addColorStop(1, '#010308');
    ctx.fillStyle = body;
    ctx.fill();

    ctx.clip();
    drawSlopes(peak, p);
    drawGullies(crest);
    drawFoothills(crest, horizon, p);
    drawSnow(crest, peak, snowLine, p);
    drawRockGrain(crest, peak);
    ctx.restore();

    drawRim(crest, p);
    drawSpurs(crest, p);
    drawHaze(horizon, t, p);
  }

  /**
   * A quieter ridge behind the main range.
   *
   * Depth without inventing a second scene: same crest language, scaled down and
   * lifted, so the silhouette reads as a range rather than a cardboard cutout.
   */
  function drawFarRidge(horizon, step, p, lift, scale, alpha) {
    ctx.save();
    ctx.beginPath();
    var first = true;
    for (var x = -step; x <= width + step; x += step) {
      var y = horizon - height * lift + (crestAt(x * 0.85 + 120, horizon) - horizon) * scale;
      if (first) { ctx.moveTo(x, y); first = false; }
      else ctx.lineTo(x, y);
    }
    ctx.lineTo(width + step, height);
    ctx.lineTo(-step, height);
    ctx.closePath();
    ctx.fillStyle = 'rgba(1,8,14,' + alpha.toFixed(2) + ')';
    ctx.fill();
    ctx.restore();
  }

  function drawSlopes(peak, p) {
    var depth = height * 0.12;
    var wash = ctx.createLinearGradient(0, peak, 0, peak + depth);
    wash.addColorStop(0, rgba(mix(p.core, [140, 190, 220], 0.4), 0.1));
    wash.addColorStop(0.45, rgba(mix(p.base, [50, 80, 105], 0.45), 0.04));
    wash.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = wash;
    ctx.fillRect(0, peak, width, depth);
    ctx.restore();
  }

  /**
   * Soft mottling on the upper face.
   *
   * Replaces the old per-facet strips, which read as vertical lines under the
   * aurora. A few large soft patches give the rock variation without a grid.
   */
  function drawRockGrain(crest, peak) {
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    for (var i = 0; i < 18; i++) {
      var x = ((i * 0.6180339887) % 1) * width;
      var y = peak + height * (0.03 + (i % 5) * 0.018);
      var rx = 40 + (i % 4) * 18;
      var ry = 16 + (i % 3) * 8;
      var g = ctx.createRadialGradient(x, y, 0, x, y, rx);
      g.addColorStop(0, 'rgba(0,0,0,' + (0.14 + (i % 3) * 0.03).toFixed(3) + ')');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(x, y, rx, ry, (i % 2) * 0.4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawFoothills(crest, horizon, p) {
    var drop = height * 0.065;
    ctx.save();
    ctx.beginPath();
    for (var i = 0; i < crest.length; i++) {
      var y = crest[i].y + drop + Math.sin(crest[i].x * 0.022 + 1.5) * 6;
      y = Math.min(y, horizon + height * 0.16);
      if (i === 0) ctx.moveTo(crest[i].x, y);
      else ctx.lineTo(crest[i].x, y);
    }
    ctx.lineTo(crest[crest.length - 1].x, height);
    ctx.lineTo(crest[0].x, height);
    ctx.closePath();

    var shade = ctx.createLinearGradient(0, horizon, 0, height);
    shade.addColorStop(0, 'rgba(0,0,0,0)');
    shade.addColorStop(0.2, 'rgba(0,0,0,0.28)');
    shade.addColorStop(0.55, 'rgba(0,0,0,0.12)');
    shade.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = shade;
    ctx.fill();
    ctx.restore();
  }

  function drawGullies(crest) {
    ctx.save();
    for (var i = 5; i < crest.length - 5; i += 2) {
      var y = crest[i].y;
      if (y <= crest[i - 1].y || y <= crest[i + 1].y) continue;
      if (y <= crest[i - 3].y || y <= crest[i + 3].y) continue;

      var drop = Math.min(crest[i - 3].y, crest[i + 3].y) - y;
      if (drop > -7) continue;

      var depth = height * 0.09;
      var halfTop = Math.max(4, Math.abs(crest[i + 2].x - crest[i - 2].x) * 0.7);
      var halfBot = halfTop * 0.15;
      var lean = Math.sin(crest[i].x * 0.03) * depth * 0.1;

      var wash = ctx.createLinearGradient(crest[i].x, y, crest[i].x + lean, y + depth);
      wash.addColorStop(0, 'rgba(0,0,0,0.28)');
      wash.addColorStop(0.45, 'rgba(0,0,0,0.1)');
      wash.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = wash;
      ctx.beginPath();
      ctx.moveTo(crest[i].x - halfTop, y);
      ctx.lineTo(crest[i].x + halfTop, y);
      ctx.lineTo(crest[i].x + lean + halfBot, y + depth);
      ctx.lineTo(crest[i].x + lean - halfBot, y + depth);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  function drawSnow(crest, peak, snowLine, p) {
    var tone = mix([230, 244, 255], p.core, 0.22);
    var shade = ctx.createLinearGradient(0, peak, 0, snowLine);
    shade.addColorStop(0, rgba(tone, 0.62));
    shade.addColorStop(0.4, rgba(tone, 0.26));
    shade.addColorStop(1, rgba(tone, 0));

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = shade;

    var cap = null;
    for (var i = 0; i < crest.length; i++) {
      var line = snowLineAt(crest[i].x, snowLine);
      var above = crest[i].y < line;
      if (above) {
        if (!cap) cap = [];
        cap.push({ x: crest[i].x, y: crest[i].y, line: line });
      }
      if ((!above || i === crest.length - 1) && cap) {
        if (cap.length > 1) {
          fillCap(cap);
          fillSnowFringe(cap, tone);
        }
        cap = null;
      }
    }
    ctx.restore();
  }

  function fillCap(cap) {
    ctx.beginPath();
    ctx.moveTo(cap[0].x, cap[0].line);
    for (var i = 0; i < cap.length; i++) ctx.lineTo(cap[i].x, cap[i].y);
    ctx.lineTo(cap[cap.length - 1].x, cap[cap.length - 1].line);
    ctx.closePath();
    ctx.fill();
  }

  function fillSnowFringe(cap, tone) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.beginPath();
    ctx.moveTo(cap[0].x, cap[0].line);
    for (var i = 0; i < cap.length; i++) ctx.lineTo(cap[i].x, cap[i].line);
    for (var j = cap.length - 1; j >= 0; j--) {
      ctx.lineTo(cap[j].x, cap[j].line + 6 + Math.sin(cap[j].x * 0.25) * 1.8);
    }
    ctx.closePath();
    ctx.fillStyle = rgba(tone, 0.07);
    ctx.fill();
    ctx.restore();
  }

  function drawRim(crest, p) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.beginPath();
    for (var i = 0; i < crest.length; i++) {
      if (i === 0) ctx.moveTo(crest[i].x, crest[i].y);
      else ctx.lineTo(crest[i].x, crest[i].y);
    }
    ctx.strokeStyle = rgba(p.core, 0.2);
    ctx.lineWidth = 1.35;
    ctx.stroke();

    ctx.beginPath();
    for (var k = 0; k < crest.length; k++) {
      var y = crest[k].y + 2.0;
      if (k === 0) ctx.moveTo(crest[k].x, y);
      else ctx.lineTo(crest[k].x, y);
    }
    ctx.strokeStyle = rgba(mix(p.core, [170, 215, 235], 0.35), 0.07);
    ctx.lineWidth = 2.6;
    ctx.stroke();
    ctx.restore();
  }

  function drawSpurs(crest, p) {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.strokeStyle = rgba(mix(p.core, [120, 170, 195], 0.5), 0.08);
    ctx.lineWidth = 1;

    for (var i = 3; i < crest.length - 3; i++) {
      var y = crest[i].y;
      if (y >= crest[i - 1].y || y >= crest[i + 1].y) continue;
      if (y >= crest[i - 2].y || y >= crest[i + 2].y) continue;

      var rise = Math.min(crest[i - 2].y, crest[i + 2].y) - y;
      if (rise < 6) continue;

      var lean = Math.sin(crest[i].x * 0.03) >= 0 ? 1 : -1;
      var length = 12 + rise * 0.55;
      ctx.beginPath();
      ctx.moveTo(crest[i].x, crest[i].y + 0.5);
      ctx.lineTo(crest[i].x + lean * length * 0.55, crest[i].y + length);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawHaze(horizon, t, p) {
    var drift = Math.sin(t * 0.00002) * 0.5 + 0.5;
    var glow = ctx.createLinearGradient(0, horizon - 24, 0, horizon + 100);
    glow.addColorStop(0, rgba(p.core, 0));
    glow.addColorStop(0.45, rgba(p.core, 0.03 + 0.02 * drift));
    glow.addColorStop(1, rgba(p.base, 0));
    ctx.fillStyle = glow;
    ctx.fillRect(0, horizon - 24, width, 130);
  }

  // --------------------------------------------------------------- lifecycle

  function updatePalette(t, dt) {
    if (t >= nextPaletteAt) {
      currentPalette = targetPalette;
      var next;
      do { next = (paletteIndex + 1 + Math.floor(Math.random() * (palettes.length - 1))) % palettes.length; }
      while (next === paletteIndex && palettes.length > 1);
      paletteIndex = next;
      targetPalette = palettes[paletteIndex];
      paletteBlend = 0;
      nextPaletteAt = t + 70000 + Math.random() * 50000;
    }
    paletteBlend = approach(paletteBlend, 1, 0.08, dt);
  }

  function draw(t, dt) {
    updatePalette(t, dt);
    var p = palette();
    sky(p);
    drawStars(t);
    drawAurora(t, p);
    drawRange(t, p);
  }

  function worstFps(now) {
    var floor = Infinity;
    for (var i = 1; i < stamps.length; i++) {
      var dt = stamps[i] - stamps[i - 1];
      if (dt > 0) floor = Math.min(floor, 1000 / dt);
    }
    return Number.isFinite(floor) ? Math.round(floor * 10) / 10 : 0;
  }

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);
    var interval = 1000 / (maxFps || 30);
    if (lastFrame && now - lastFrame < interval - 0.5) return;
    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.25) : 0;
    lastFrame = now;
    elapsed += dt * 1000;
    draw(elapsed, dt);
    frames++;
    beatFrames++;
    stamps.push(now);
    while (stamps.length > 1 && now - stamps[0] > 1100) stamps.shift();

    if (!lastBeat) lastBeat = now;
    else if (now - lastBeat >= 1000) {
      post({
        v: SCHEMA,
        type: 'heartbeat',
        fps: Math.round(beatFrames * 10000 / (now - lastBeat)) / 10,
        fpsFloor: worstFps(now),
        frames: frames
      });
      lastBeat = now;
      beatFrames = 0;
      stamps.length = 0;
    }
  }

  function start() {
    if (rafHandle) return;
    lastFrame = 0;
    lastBeat = 0;
    beatFrames = 0;
    stamps.length = 0;
    rafHandle = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { return; }
    }
    if (!msg || typeof msg.type !== 'string') return;
    switch (msg.type) {
      case 'life.init':
        if (msg.performance && msg.performance.maxFps) maxFps = msg.performance.maxFps;
        resize();
        break;
      case 'life.pause': stop(); break;
      case 'life.resume': start(); break;
      case 'life.resize': resize(); break;
      case 'life.destroy': stop(); break;
      case 'rt.performance':
        if (msg.maxFps) maxFps = msg.maxFps;
        break;
    }
  }

  window.addEventListener('resize', resize);
  window.addEventListener('error', function (e) {
    post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) { onMessage(e.data); });
  }

  resize();
  seed();
  post({ v: SCHEMA, type: 'ready', sceneId: sceneId, renderer: 'canvas2d' });
  start();
})();
