// Aurora Drift - volumetric aurora over an arctic valley, for Lumina.
//
// WebGL2. The aurora is raymarched through a slab of sky rather than painted: curtains are sheets
// standing along wandering lines in a 3D volume, sampled at stacked altitudes the way the real
// thing is stacked, so folds, rays and the colour change with height all come from one model
// instead of being drawn as separate effects. Everything else - stars, the valley, the lake, the
// forest and the people who settle there share one pass. Shore spruces are Blender-baked
// billboards bundled with the scene (no network); far slope forest stays a cheap albedo tint.
//
// Like Wave Drift, this scene lives on the desktop rather than on a display. Azimuth is computed
// from virtual-desktop pixels and every phase from Date.now(), so two screens are two windows onto
// one continuous valley. A per-instance random seed or elapsed counter would show up as a seam.
//
// Signals are optional by contract. No cursor means the curtains drift on their own, no audio
// means the activity follows the night's own cycle, and a library preview with neither still
// looks like the scene.
(function () {
  'use strict';

  var SCHEMA = 1;
  var BAND_COUNT = 16;

  // Feature sizes and angles are expressed against this nominal width in CSS pixels. FOV_SPAN is
  // how much of the sky that width covers: about seventy degrees, which keeps curtains large on a
  // single 1080p screen and still lets a second screen continue the sky instead of repeating it.
  var SPAN = 1920;
  var FOV_SPAN = 1.22;
  var HORIZON = 0.62;            // horizon height as a fraction of the display, from the top

  var EPOCH = Date.UTC(2026, 0, 1);
  var DAY_MS = 86400000;

  var canvas = document.getElementById('scene');
  var sceneId = document.body.dataset.sceneId || 'aurora-drift';

  function post(message) {
    if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(message);
  }

  function fail(message) {
    post({ v: SCHEMA, type: 'error', message: String(message), fatal: true });
  }

  var gl = canvas.getContext('webgl2', {
    alpha: false,
    antialias: false,
    depth: false,
    stencil: false,
    powerPreference: 'high-performance',
    preserveDrawingBuffer: false
  });

  if (!gl) { fail('WebGL2 unavailable'); return; }

  // Blender hero spruces, baked to RGBA billboards so wallpaper stays at 30 fps without mesh tris.
  var spruceTex = [null, null, null];
  var spruceReady = 0;
  function makeEmptySpruceTex() {
    var tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));
    return tex;
  }
  spruceTex[0] = makeEmptySpruceTex();
  spruceTex[1] = makeEmptySpruceTex();
  spruceTex[2] = makeEmptySpruceTex();
  function loadSpruceBillboards() {
    // Cache-bust so WebView2 does not keep washed/old PNGs after a scene update.
    var paths = [
      'assets/spruce/spruce_mature.png?v=2.1.14',
      'assets/spruce/spruce_mid.png?v=2.1.14',
      'assets/spruce/spruce_young.png?v=2.1.14'
    ];
    var remaining = paths.length;
    paths.forEach(function (src, i) {
      var img = new Image();
      img.onload = function () {
        var tex = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
        // No mipmaps: mip alpha bleed made needle gaps show the bright snow bank
        // through the billboard, washing whole trees mint/white.
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
        if (spruceTex[i]) gl.deleteTexture(spruceTex[i]);
        spruceTex[i] = tex;
        remaining--;
        if (remaining === 0) spruceReady = 1;
      };
      img.onerror = function () {
        remaining--;
      };
      img.src = src;
    });
  }
  loadSpruceBillboards();

  // ------------------------------------------------------------------ options

  var CURSOR_ATTRACT = 'attract', CURSOR_REPEL = 'repel', CURSOR_OFF = 'off';
  var cursorMotion = CURSOR_ATTRACT;
  var audioReactive = true;
  var dayNightCycle = true;
  // With the cycle off the sky holds one look: full night, or the blue polar noon.
  var fixedSky = 'night';
  var attractMix = 1, repelMix = 0;
  var modeSettled = false;

  // ---------------------------------------------------------------- state

  var width = 0, height = 0, dpr = 1;
  var bufW = 0, bufH = 0;
  var originX = 0, pxPerCss = 1;
  var preview = false;
  var maxFps = 30;
  var quality = 'high';
  var rafHandle = 0, lastFrame = 0, lastBeat = 0;
  var beatFrames = 0, frames = 0;
  var stamps = [];
  var contextLost = false;
  var resumeAfterRestore = false;

  var cursor = { x: 0.5, y: 0.5 };
  var cursorTarget = { x: 0.5, y: 0.5 };
  var presence = 0, presenceTarget = 0;
  var energy = 0, energyTarget = 0;

  var level = 0, levelTarget = 0;
  var bass = 0, bassTarget = 0;
  var treble = 0, trebleTarget = 0;
  var pulse = 0, bassAverage = 0;
  // Integrals of the music over time: colour turns and the curtains flow faster while it plays.
  var musicHue = 0, musicFlow = 0;

  // ----------------------------------------------------------------- helpers

  function lerp(a, b, t) { return a + (b - a) * t; }
  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
  function mod(v, n) { return ((v % n) + n) % n; }
  function smoothstep(v) { v = clamp01(v); return v * v * (3 - 2 * v); }

  function approach(current, target, rate, dt) {
    return current + (target - current) * (1 - Math.exp(-rate * dt));
  }

  // Mulberry32. Every instance must derive the same world, so Math.random() is never used.
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function hashInt(seed, n) {
    return rng((seed ^ Math.imul(n | 0, 0x9E3779B1)) >>> 0)();
  }

  // Shader time has to stay small: a float32 holding seconds since 2026 is only good to about two
  // seconds. Every moving term in the shaders is therefore either a sine fed a phase wrapped to
  // 2*pi here, or periodic noise fed an offset wrapped to the noise period here, both in double
  // precision. The motion is continuous across the wrap because the shader function is periodic
  // in exactly that period.
  var NOISE_PERIOD = 512;
  var TAU = Math.PI * 2;
  function wrapPhase(tSec, rate) { return mod(tSec * rate, TAU); }
  function wrapNoise(tSec, rate) { return mod(tSec * rate, NOISE_PERIOD); }

  // ---------------------------------------------------------------- the world

  /**
   * Same clock as Wave Drift, so the two worlds age together: day and night follow the wall clock
   * at the live rate, while snow, ice, forest and settlement advance twelve world days per real
   * day. The world is two numbers in localStorage, an epoch and a seed, and everything below is a
   * pure function of the age they give, which is what lets two displays agree without talking.
   */
  var WORLD_KEY = 'lumina.world.aurora-drift';
  var WORLD_SYNC_MS = 2000;

  var worldEpoch = 0;
  var worldSeed = 0xA11;
  var worldDays = 0;
  var lastWorldSync = 0;
  var epochDayOffset = 0;

  var SPEEDS = { live: 1, hour: 24, minute: 1440, fast: 8640, warp: 43200 };
  var evolutionRate = 1;
  var LIFE_PER_REAL_DAY = 12;
  var YEAR_DAYS = 365;
  var MOON_CYCLE = 29.53;

  function ecologyRate() {
    return evolutionRate > 1 ? evolutionRate : LIFE_PER_REAL_DAY;
  }

  function loadWorld() {
    var stored = readWorld();
    if (stored) {
      worldEpoch = stored.epoch;
      worldSeed = stored.seed;
    } else {
      // Quantized to the minute so instances starting seconds apart on a first run agree.
      worldEpoch = Math.floor(Date.now() / 60000) * 60000;
      worldSeed = (Math.imul(worldEpoch >>> 9, 0x9E3779B1) ^ 0xA11) >>> 0;
      writeWorld();
    }
    anchorDay();
    seedWorld();
  }

  function anchorDay() {
    var d = new Date(worldEpoch);
    epochDayOffset = ((d.getHours() * 60 + d.getMinutes()) * 60 + d.getSeconds()) * 1000;
  }

  function readWorld() {
    try {
      var raw = window.localStorage.getItem(WORLD_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed.epoch !== 'number' || !isFinite(parsed.epoch)) return null;
      return { epoch: parsed.epoch, seed: (parsed.seed >>> 0) || 0xA11 };
    } catch (e) {
      // Storage disabled: the world lasts as long as the process.
      return null;
    }
  }

  function writeWorld() {
    try {
      window.localStorage.setItem(WORLD_KEY, JSON.stringify({ epoch: worldEpoch, seed: worldSeed }));
    } catch (e) {
      /* storage unavailable */
    }
  }

  function syncWorld(wall) {
    if (wall - lastWorldSync < WORLD_SYNC_MS) return;
    lastWorldSync = wall;
    var stored = readWorld();
    if (stored && (stored.epoch !== worldEpoch || stored.seed !== worldSeed)) {
      worldEpoch = stored.epoch;
      worldSeed = stored.seed;
      anchorDay();
      seedWorld();
    }
  }

  function ageInDays(wall) {
    return Math.max(0, (wall - worldEpoch) * ecologyRate() / DAY_MS);
  }

  function dayFraction(wall) {
    if (!dayNightCycle) return fixedSky === 'twilight' ? 0.5 : 0;
    return mod((epochDayOffset + (wall - worldEpoch) * evolutionRate) / DAY_MS, 1);
  }

  function seasonWeight(phase, center, halfWidth) {
    var d = Math.abs(phase - center);
    d = Math.min(d, 1 - d);
    return clamp01(1 - d / halfWidth);
  }

  // Phase 0 is late winter, so a new world opens on deep snow and frozen ice, the arctic as most
  // people picture it, and reaches the thaw about a week of real time later.
  function seasonAt(days) {
    var phase = mod(days / YEAR_DAYS + 0.9, 1);
    var spring = seasonWeight(phase, 0.20, 0.18);
    var summer = seasonWeight(phase, 0.45, 0.17);
    var autumn = seasonWeight(phase, 0.68, 0.16);
    var winter = seasonWeight(phase, 0.92, 0.26);
    var sum = spring + summer + autumn + winter;
    if (sum > 0.001) { spring /= sum; summer /= sum; autumn /= sum; winter /= sum; }
    return { phase: phase, spring: spring, summer: summer, autumn: autumn, winter: winter };
  }

  /**
   * The lake through the year. Frozen through winter, breaking up in late spring, open through
   * summer and refreezing in late autumn. A ramp per transition rather than the season weights,
   * because ice does not half-exist for a month: it is either holding or it is going.
   */
  function iceAt(phase) {
    if (phase < 0.24) return 1;
    if (phase < 0.32) return 1 - smoothstep((phase - 0.24) / 0.08);
    if (phase < 0.72) return 0;
    if (phase < 0.80) return smoothstep((phase - 0.72) / 0.08);
    return 1;
  }

  /** Low-frequency value noise over world days, for weather that changes by the day. */
  function dayNoise(days, salt) {
    var i = Math.floor(days), f = days - i;
    var a = hashInt(worldSeed ^ salt, i), b = hashInt(worldSeed ^ salt, i + 1);
    return lerp(a, b, f * f * (3 - 2 * f));
  }

  // Each world day gets its own aurora: mostly moderate, some quiet single arcs, some storms.
  function activityLevel(n) {
    var r = hashInt(worldSeed ^ 0xA0A0, n);
    var s = hashInt(worldSeed ^ 0x0B0B, n);
    if (r < 0.30) return 0.18 + s * 0.17;
    if (r < 0.80) return 0.45 + s * 0.2;
    return 0.8 + s * 0.2;
  }

  function activityAt(days, tSec) {
    var i = Math.floor(days), f = days - i;
    var v = lerp(activityLevel(i), activityLevel(i + 1), f * f * (3 - 2 * f));
    // Breathing over half an hour inside a night, from the shared clock.
    return clamp01(v + 0.06 * Math.sin(wrapPhase(tSec, TAU / 1800)));
  }

  /**
   * Substorm breakups. Each ten-minute slot of the shared clock may hold one, more likely on an
   * active night. Returns 0..1 envelope and how far through it is, so the curtains can whip
   * sideways during it and settle back afterwards without any per-instance accumulator.
   */
  var BREAKUP_SLOT = 600000;
  function breakupAt(wall, activity) {
    var slot = Math.floor(wall / BREAKUP_SLOT);
    var best = { s: 0, u: 0 };
    for (var k = -1; k <= 0; k++) {
      var r = rng((worldSeed ^ Math.imul(slot + k, 0x85EBCA6B)) >>> 0);
      var chance = r(), at = r(), len = r();
      if (chance > 0.15 + 0.55 * activity) continue;
      var start = (slot + k) * BREAKUP_SLOT + at * BREAKUP_SLOT * 0.6;
      var dur = 25000 + len * 40000;
      var u = (wall - start) / dur;
      if (u <= 0 || u >= 1) continue;
      // Fast rise, slow decay, as a breakup does.
      var s = Math.pow(Math.sin(Math.PI * Math.pow(u, 0.55)), 2);
      if (s > best.s) best = { s: s, u: u };
    }
    return best;
  }

  /** Meteors: rare sporadics, plus two showers a world year. One at a time is plenty. */
  var METEOR_SLOT = 5000;
  function meteorAt(wall, days, night) {
    var phase = mod(days / YEAR_DAYS, 1);
    var shower = Math.exp(-Math.pow((phase - 0.61) / 0.012, 2)) +
      Math.exp(-Math.pow((phase - 0.95) / 0.01, 2));
    var slot = Math.floor(wall / METEOR_SLOT);
    var r = rng((worldSeed ^ Math.imul(slot, 0xC2B2AE35)) >>> 0);
    if (r() > (0.025 + 0.55 * shower) * night) return null;
    var start = slot * METEOR_SLOT + r() * 3000;
    var dur = 500 + r() * 900;
    var u = (wall - start) / dur;
    if (u <= 0 || u >= 1) return null;
    return {
      az: -0.65 + r() * 1.3,
      el: 0.22 + r() * 0.3,
      angle: -Math.PI / 2 + (r() - 0.5) * 1.8,
      len: 0.08 + r() * 0.14,
      bright: 0.6 + r() * 1.4,
      u: u
    };
  }

  // Settlement. The cabin arrives first, then a campfire on the near shore, then a village along
  // the far shore on the same schedule Wave Drift's hamlets follow.
  var HOUSE_COUNT = 9;
  var houses = new Float32Array(HOUSE_COUNT * 4);
  var VILLAGE_BORN = [8, 18, 36, 60, 100, 160, 240, 360];
  var FIRE_AZ = -0.24, FIRE_BORN = 5;
  var CABIN_BORN = 3;
  var PATH_BORN = 12;

  function seedWorld() {
    var r = rng(worldSeed ^ 0x4C0D);
    houses[0] = 0.17 + (r() - 0.5) * 0.04;
    houses[1] = 0.0105;
    houses[2] = CABIN_BORN;
    houses[3] = r() * 6.28;
    for (var i = 1; i < HOUSE_COUNT; i++) {
      // Spread along the far shore to the left of the cabin, valleys first.
      houses[i * 4] = -0.62 + (i - 1) * 0.085 + (r() - 0.5) * 0.04;
      houses[i * 4 + 1] = 0.0042 + r() * 0.0022;
      houses[i * 4 + 2] = VILLAGE_BORN[i - 1];
      houses[i * 4 + 3] = r() * 6.28;
    }
  }

  function forestAt(days) {
    return clamp01(
      smoothstep((days - 1) / 8) * 0.5 +
      smoothstep((days - 16) / 28) * 0.32 +
      smoothstep((days - 50) / 70) * 0.18);
  }

  // ------------------------------------------------------------------ shaders

  var VERT = `#version 300 es
in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`;

  var COMMON = `#version 300 es
precision highp float;
precision highp int;

uniform vec2  uRes;      // render target, buffer pixels
uniform vec2  uCss;      // display, CSS pixels
uniform float uAz0;      // azimuth at the display's left edge
uniform float uRpc;      // radians per CSS pixel
uniform float uHorizon;  // horizon, CSS pixels from the top

#define PI 3.14159265
#define TAU 6.2831853

float h11(float n) { n = fract(n * 0.1031); n *= n + 33.33; n *= n + n; return fract(n); }
float h21(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec2  h22(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973)); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.xx + p3.yz) * p3.zy); }

float n1(float x) { float i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(h11(i), h11(i + 1.0), f); }

// Periodic in x with integer period, so an offset wrapped to that period host-side moves the
// pattern continuously forever.
float pn1(float x) {
  float i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
  return mix(h11(mod(i, 512.0)), h11(mod(i + 1.0, 512.0)), f);
}

float n2(vec2 p) {
  vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), u.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), u.x), u.y);
}

float fbm1(float x) { float s = 0.0, a = 0.5; for (int i = 0; i < 5; i++) { s += a * n1(x); x = x * 2.03 + 17.1; a *= 0.5; } return s; }
float fbm2(vec2 p) { float s = 0.0, a = 0.5; for (int i = 0; i < 4; i++) { s += a * n2(p); p = mat2(1.6, 1.2, -1.2, 1.6) * p + 3.7; a *= 0.5; } return s; }

vec2 anglesAt(vec2 frag) {
  float cx = frag.x / uRes.x * uCss.x;
  float cy = (1.0 - frag.y / uRes.y) * uCss.y;
  return vec2(uAz0 + cx * uRpc, (uHorizon - cy) * uRpc);
}

vec3 dirOf(vec2 ae) { float ce = cos(ae.y); return vec3(sin(ae.x) * ce, sin(ae.y), cos(ae.x) * ce); }

float aDiff(float a, float b) { return mod(a - b + PI, TAU) - PI; }
`;

  // ------------------------------------------------------------- aurora pass
  //
  // Altitude-stacked raymarch. Each step is a horizontal layer of the slab; the ray's crossing of
  // that layer is tested against every curtain's line at that height. A curtain is then the stack
  // of those crossings, which is exactly what makes the rays read as vertical and lets near
  // curtains tower while far ones lie down along the horizon. Steps are jittered per pixel and
  // per frame and accumulated over frames, so the stack never shows as bands.
  var AURORA_FRAG = COMMON + `
out vec4 frag;

uniform sampler2D uPrev;
uniform float uBlend;
uniform float uFrame;
uniform float uLayers;
uniform vec4  uCur[4];     // distance, gain, seed, amplitude
uniform vec4  uOffA;       // meander, fold roll, ray drift, ray shimmer
uniform vec4  uOffB;       // patches, edge wobble, edge flicker, breakup sweep
uniform vec4  uPhase;      // fold, kink, tilt, pulse travel (radians)
uniform float uActivity;
uniform float uStorm;
uniform float uBright;
uniform float uFringe;
uniform float uRedTop;
uniform float uViolet;
uniform vec4  uCursor;     // azimuth, elevation, presence, energy
uniform vec2  uMode;       // attract, repel
uniform float uRipple;     // ripple phase
uniform vec4  uAudio;      // level, bass, treble, pulse
uniform vec4  uHue;        // hue field drift, global hue shift, variety, unused
uniform float uStore;

float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

// A cyclic palette of auroral (and slightly dreamed) emission colours. Neighbouring stops are
// chosen so blends between them stay saturated instead of passing through grey.
vec3 hueRamp(float t) {
  t = fract(t) * 6.0;
  float i = floor(t), f = smoothstep(0.0, 1.0, fract(t));
  vec3 a, b;
  if      (i < 1.0) { a = vec3(0.10, 1.00, 0.36); b = vec3(0.04, 0.88, 0.82); }
  else if (i < 2.0) { a = vec3(0.04, 0.88, 0.82); b = vec3(0.28, 0.42, 1.00); }
  else if (i < 3.0) { a = vec3(0.28, 0.42, 1.00); b = vec3(0.78, 0.26, 1.00); }
  else if (i < 4.0) { a = vec3(0.78, 0.26, 1.00); b = vec3(1.00, 0.24, 0.58); }
  else if (i < 5.0) { a = vec3(1.00, 0.24, 0.58); b = vec3(0.62, 1.00, 0.22); }
  else              { a = vec3(0.62, 1.00, 0.22); b = vec3(0.10, 1.00, 0.36); }
  return mix(a, b, f);
}

// The curtain's line across the ground. Large swings in depth over short runs are what make a
// sheet fold: where it turns toward the eye the line of sight runs along it, so successive
// altitude layers keep landing inside it and the fold stands out as a bright, tall drape.
float curveZ(float x, vec4 c) {
  float s = c.z * 37.0;
  float z = c.x;
  z += c.w * (pn1(x * 0.16 + uOffA.x + s) - 0.5) * 3.4;
  z += c.w * 0.95 * sin(x * 0.9 + uPhase.x + s);
  z += c.w * 0.42 * sin(x * 2.3 - uPhase.y + s * 1.7);
  z += c.w * (pn1(x * 1.6 + uOffA.y + s) - 0.5) * 0.7;
  return z;
}

vec3 curtain(vec2 p, float h, float fp, vec4 c, float cw, float zTarget, float ripple, float bright) {
  float x = p.x, z = p.y;
  if (abs(z - c.x) > c.w * 2.4 + 1.6) return vec3(0.0);

  float g = curveZ(x, c);
  float slope = c.w * (0.855 * cos(x * 0.9 + uPhase.x + c.z * 37.0) + 0.966 * cos(x * 2.3 - uPhase.y + c.z * 62.9));

  // Upper parts lean, so a curtain is a sheet and not a wall.
  g += (h - 1.0) * 0.28 * sin(x * 0.31 + uPhase.z + c.z * 5.0);

  // The pointer as a magnetic disturbance: the sheet under it bends toward the cursor's line of
  // sight or parts around it, and a moving pointer sends a ripple along the curtain.
  g = mix(g, zTarget, cw * uMode.x * 0.85);
  float away = g - zTarget;
  g += sign(away) * cw * uMode.y * 1.5 * exp(-abs(away) * 0.5);
  g += ripple;

  float d = abs(z - g) / sqrt(1.0 + slope * slope);
  float w = 0.05 + 0.035 * pn1(x * 0.7 + c.z * 9.0);
  // Widen the sheet to at least the distance between successive layer samples so a thin
  // curtain seen at a low angle is not missed between steps (which shows as contour lines),
  // scaling it down to keep the same total light.
  float we = sqrt(w * w + fp * fp);
  float sheet = exp(-d * d / (we * we)) * (w / we) + 0.10 * exp(-d / (we * 6.0));
  if (sheet < 0.003) return vec3(0.0);

  float yb = 1.0 + 0.11 * (pn1(x * 0.42 + uOffB.y + c.z * 3.0) - 0.5) - 0.12 * uStorm - 0.03 * uAudio.w;
  float rel = h - yb;
  float H = 0.42 + 0.5 * uActivity + 0.35 * uStorm;
  // A sharp, bright lower edge and a long fade upward with no hard top.
  float vert = rel < 0.0 ? exp(-rel * rel / 0.0012) : exp(-rel / H) * (1.0 + 1.6 * exp(-rel / 0.07));

  // Rays: fine vertical striations drifting along the sheet. Sharper during a breakup.
  float r1 = pn1(x * 7.0 + uOffA.z + c.z * 11.0);
  float r2 = pn1(x * 19.0 - uOffA.w + c.z * 5.0);
  float r3 = pn1(x * 43.0 + uOffA.z * 1.7 + c.z * 2.0);
  float rays = 0.22 + 1.6 * r1 * r1 * (0.45 + 0.55 * r2) * (0.75 + 0.25 * r3);
  rays = mix(1.0, rays, 0.72 + 0.25 * uStorm);

  float patchy = 0.12 + 0.88 * smoothstep(0.18, 0.7, pn1(x * 0.11 + uOffB.x + c.z * 2.0));

  // Colour by altitude: a thin pink lower fringe, the green body, teal above it and crimson tops
  // on strong nights; violet-blue tops only in a breakup.
  // Each curtain has its own place on the palette, and a slow field drifts colour along the
  // sheets and up them; the global shift turns the whole sky faster while music plays.
  vec3 green = vec3(0.10, 1.0, 0.36);
  float hf = c.z * 0.9 + x * 0.035 + pn1(x * 0.33 + uHue.x + c.z * 13.0) * 1.1 + uHue.y + max(rel, 0.0) * 0.28;
  float spread = 0.45 + 0.55 * smoothstep(0.2, 0.8, pn1(x * 0.09 - uHue.x * 0.7 + c.z * 5.0));
  vec3 col = mix(green, hueRamp(hf), uHue.z * spread);
  float fringeAt = uFringe * smoothstep(0.35, 0.75, pn1(x * 0.6 + uOffB.x * 1.3 + c.z * 4.0));
  col = mix(vec3(1.0, 0.18, 0.52), col, mix(1.0, smoothstep(-0.005, 0.035, rel), fringeAt));
  float up = clamp(rel / (H * 2.4), 0.0, 1.0);
  col = mix(col, vec3(0.10, 0.82, 0.78), smoothstep(0.25, 0.75, up) * 0.3);
  col = mix(col, vec3(0.95, 0.10, 0.20), smoothstep(0.42, 1.0, up) * uRedTop);
  col = mix(col, vec3(0.45, 0.30, 1.0), smoothstep(0.5, 1.0, up) * uViolet);
  float redGlow = uRedTop * 0.3 * exp(-pow((rel - 1.3 * H) / (H * 1.1), 2.0));

  // Lower edge: treble flickers it, bass onsets run a bright pulse along it.
  float edge = exp(-max(rel, 0.0) / 0.07);
  float flick = 1.0 + edge * (0.12 + 0.45 * uAudio.z) * (pn1(x * 29.0 + uOffB.z) - 0.5) * 2.0;
  float pls = 1.0 + edge * uAudio.w * 1.8 * (0.55 + 0.45 * sin(x * 2.2 - uPhase.w));

  float k = c.y * sheet * patchy * rays * flick * pls * bright;
  return (col * vert + vec3(0.95, 0.10, 0.22) * redGlow) * k;
}

void main() {
  vec2 ae = anglesAt(gl_FragCoord.xy);
  vec3 prev = texelFetch(uPrev, ivec2(gl_FragCoord.xy), 0).rgb;
  vec3 acc = vec3(0.0);

  if (ae.y > -0.02) {
    vec3 d = dirOf(vec2(ae.x, max(ae.y, 0.01)));
    float jit = fract(ign(gl_FragCoord.xy) + uFrame * 0.618034);

    float dc = aDiff(ae.x, uCursor.x);
    float cw = exp(-dc * dc / 0.036) * uCursor.z;
    float elc = clamp(uCursor.y, 0.035, 0.6);
    float zTarget = cos(uCursor.x) / tan(elc);
    float ripple = uCursor.w * uCursor.z * 0.4 * sin(dc * 26.0 - uRipple) * exp(-abs(dc) * 3.5);
    float bright = 1.0 + cw * (1.0 * uMode.x + 0.45 * uMode.y) + cw * uCursor.w * 0.7;

    float hb = 0.84, ht = 3.7;
    float invY = min(1.0 / d.y, 12.0);
    for (int i = 0; i < 64; i++) {
      if (float(i) >= uLayers) break;
      float f = (float(i) + jit) / uLayers;
      float h = mix(hb, ht, f * f);
      float dh = (ht - hb) * 2.0 * f / uLayers;
      // A ring at the forward-view distance, not a flat slab in front of the primary.
      // The left display looks about 100 degrees off axis; a slab has slid out of frame
      // before that screen's outer edge. The ring stays in front of both.
      float el = max(ae.y, 0.01);
      float radius = h * min(cos(el) / sin(el), 12.0);
      vec2 p = vec2(ae.x * radius, radius);
      float fp = 0.5 * dh * length(d.xz) * invY;
      vec3 c = curtain(p, h, fp, uCur[0], cw, zTarget, ripple, bright)
             + curtain(p, h, fp, uCur[1], cw, zTarget, ripple, bright)
             + curtain(p, h, fp, uCur[2], cw, zTarget, ripple, bright)
             + curtain(p, h, fp, uCur[3], cw, zTarget, ripple, bright);
      acc += c * dh * invY;
    }
    acc *= uBright * smoothstep(-0.02, 0.06, ae.y);
  }

  frag = vec4(mix(prev, acc * uStore, uBlend), 1.0);
}
`;

  // ------------------------------------------------------------ terrain pass
  //
  // The mountain range as a heightfield around the lake, raymarched from the camera. It depends
  // only on the view, so it is rendered once (in strips, over a few frames) whenever the view
  // changes and then lit every frame by the main pass. The terrain lives in world space rather
  // than per display, so the range continues unbroken across monitors.
  var TERRAIN_FRAG = COMMON + `
layout(location = 0) out vec4 g0;
layout(location = 1) out vec4 g1;
uniform float uGPx;     // radians per buffer pixel
uniform vec4  uGeo;     // margin columns, first row, horizon row, unused
// Loop counts arrive as uniforms so the D3D compiler behind ANGLE cannot unroll them: unrolled,
// every inlined terrain call multiplies and the first draw stalls for seconds while it builds.
uniform ivec4 uCounts;  // vertical samples, march steps, refinement steps, surface samples (17)

const float CAMH = 0.035;
const float T_DMAX = 130.0;
const float T_HMAX = 16.0;
const mat2 OCT = mat2(1.6, 1.2, -1.2, 1.6);

// Gradient noise with quintic fade: value noise leaves creases in lit normals.
vec2 grad2(vec2 i) { return h22(i) * 2.0 - 1.0; }
float gn(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  float a = dot(grad2(i), f);
  float b = dot(grad2(i + vec2(1.0, 0.0)), f - vec2(1.0, 0.0));
  float c = dot(grad2(i + vec2(0.0, 1.0)), f - vec2(0.0, 1.0));
  float d = dot(grad2(i + vec2(1.0, 1.0)), f - vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Ridged multifractal over a warped domain: each octave is weighted by the one before, so fine
// detail gathers on the crests and the valleys stay smooth, the way erosion leaves real ranges.
float terrain(vec2 xz, int oct) {
  float r = length(xz);
  float rise = smoothstep(6.4, 13.0, r);
  if (rise <= 0.0) return -0.05;
  vec2 p = xz * 0.17 + vec2(31.7, -12.3);
  p += vec2(gn(p * 0.4), gn(p * 0.4 + vec2(5.2, 1.3))) * 1.7;
  // Secondary ridges. Enough of them to break the skyline into separate summits, not so much
  // that the flat view turns each crest into a comb with sky between the teeth.
  float fine = mix(0.22, 0.7, smoothstep(14.0, 36.0, r));
  // The first octaves are the massif; the rest are surface detail. Only the massif is scaled by
  // the range height: detail scaled with it turns into cliff-sized spires, steeper than a
  // heightfield can show, and their texture smears down the faces.
  float sum = 0.0, detail = 0.0, amp = 0.55, weight = 1.0;
  for (int i = 0; i < oct; i++) {
    // The massif keeps a rounded crest. Later octaves are broad bumps: a ridged crest here
    // is a thin tooth, and from the lake those teeth leave horizontal gaps of sky.
    float g = gn(p) * 1.5;
    float n = max(0.0, 1.0 - sqrt(g * g + 0.02)) * 1.02;
    n *= n;
    if (i > 0) n = clamp(0.5 + 0.5 * gn(p), 0.0, 1.0);
    float v = n * amp * weight * (i < 1 ? 1.0 : fine);
    if (i < 2) sum += v; else detail += v;
    weight = i == 0 ? clamp(n * 1.35, 0.4, 1.0) : clamp(0.65 + 0.35 * n, 0.0, 1.0);
    p = OCT * p + vec2(3.1, 1.7);
    amp *= 0.5;
  }
  // Broad massifs with low passes between them, so farther ranges show through the gaps.
  float massif = smoothstep(-0.25, 0.35, gn(xz * 0.032 + vec2(7.0, 2.0)));
  float scale = mix(0.55, 8.5, smoothstep(10.0, 46.0, r)) * (0.42 + 0.58 * massif);
  // Squaring the crests lets a few summits stand clear of the rest and opens the valleys into
  // broad troughs, instead of every ridge reaching the same height.
  float s = sum * 1.3;
  float shape = s * s * 0.85 + s * 0.3;
  // A light ceiling only. A hard one parks every summit at the same height, so the tips look
  // rubbed flat. The detail stays small: at this viewing angle a tall fine ridge compresses
  // into horizontal streaks.
  shape /= 1.0 + shape * 0.06;
  // Fine detail is left out of the height. At this flat viewing angle it doesn't read as rock,
  // it stretches into horizontal streaks across the faces.
  return (shape * scale + 0.12) * rise;
}

// The highest the terrain can reach at a given radius: the scale envelope at its maximum crest.
// Above it there is nothing to hit, so the march can cross open air without evaluating terrain.
float boundAt(float r) {
  return (1.6 * mix(0.55, 8.5, smoothstep(10.0, 46.0, r)) + 0.45) * smoothstep(6.2, 13.0, r);
}

int octavesFor(float footprint) {
  // Stop once an octave's wavelength drops under about three pixels.
  return int(clamp(log2(5.9 / (footprint * 3.0)), 3.0, 9.0));
}

void main() {
  vec3 ro = vec3(0.0, CAMH, 0.0);
  float ss = float(uCounts.x);
  vec4 acc0 = vec4(0.0), acc1 = vec4(0.0);
  float covSum = 0.0;
  // Supersampled vertically only: ridgelines run across the screen, so that is where the
  // aliasing is.
  for (int sy = 0; sy < uCounts.x; sy++) {
    {
      vec2 off = vec2(0.0, (float(sy) + 0.5) / ss - 0.5);
      vec2 fc = vec2(gl_FragCoord.x - uGeo.x, gl_FragCoord.y + uGeo.y) + off;
      vec2 ae = vec2(uAz0 + fc.x * uGPx, (fc.y - uGeo.z) * uGPx);
      if (ae.y < -0.004) continue;
      vec3 rd = dirOf(ae);

      float t = 6.0 / max(length(rd.xz), 1e-3);
      float tPrev = t;
      bool hit = false;
      float minC = 1e9, tMin = t;
      for (int i = 0; i < uCounts.y; i++) {
        vec3 p = ro + rd * t;
        if (t > T_DMAX || p.y > T_HMAX) break;
        float fp = t * uGPx;
        float above = p.y - boundAt(length(p.xz));
        if (above > fp) {
          // The bound rises at most about 0.6 per unit of distance; stepping by the clearance
          // over that keeps the ray above it.
          tPrev = t;
          t += max(above * 1.4, t * 0.009);
          continue;
        }
        float d = p.y - terrain(p.xz, min(octavesFor(fp) - 1, 5));
        float c = d / fp;
        if (c < minC) { minC = c; tMin = t; }
        if (d < 0.3 * fp) { hit = true; break; }
        tPrev = t;
        // A floor proportional to distance: rays grazing a long ridge would otherwise crawl and
        // run out of steps before reaching the far ranges, which cuts the summits off flat.
        // Close to the surface the floor drops, or the ray leaps through thin summits and
        // neighbouring rows alternate hit and miss, which smears the peaks sideways.
        float floorStep = d < t * 0.012 ? t * 0.003 : t * 0.009;
        t += max(d * 0.55, max(fp * 0.7, floorStep));
      }
      // A near miss used to be painted at partial coverage. Along a ridge that fringe is several
      // pixels of mountain colour blended into the sky, which is what rubs the summits out.
      // The vertical supersample is enough to keep the skyline from aliasing.
      float cov = hit ? 1.0 : 0.0;
      if (cov <= 0.0) continue;
      if (hit) {
        float lo = tPrev, hi = t;
        for (int k = 0; k < uCounts.z; k++) {
          float mid = 0.5 * (lo + hi);
          vec3 q = ro + rd * mid;
          if (q.y - terrain(q.xz, octavesFor(mid * uGPx)) < 0.0) hi = mid; else lo = mid;
        }
        t = hi;
      } else {
        t = tMin;
      }

      vec3 p = ro + rd * t;
      float fp = t * uGPx;
      int oct = max(octavesFor(fp) - 1, 3);
      // A slightly wide normal kernel: snow-covered ground reads soft and rounded. Whether snow
      // can hold is judged on a broader one still: fine creases change the light but not where
      // the snow lies, which keeps the cover soft and continuous. Occlusion compares the point
      // with two rings around it, so hollows and valley floors darken and crests open up.
      // All of it is one loop over one terrain call, which keeps the compiled shader small.
      float e = max(fp * 1.15, 0.0035);
      // Wide on purpose. A tight slope, seen this flat, breaks into horizontal streaks.
      float eb = 0.85;
      float hx = 0.0, hz = 0.0, bx = 0.0, bz = 0.0, hc = 0.0, r1 = 0.0, r2 = 0.0;
      for (int k = 0; k < uCounts.w; k++) {
        int j = k - (k / 4) * 4;
        vec2 axis = vec2(j == 0 ? 1.0 : (j == 1 ? -1.0 : 0.0), j == 2 ? 1.0 : (j == 3 ? -1.0 : 0.0));
        float ang = float(k) * 1.5708 + 0.4;
        vec2 ring = vec2(cos(ang), sin(ang));
        vec2 o;
        int oc;
        if (k < 4) { o = axis * e; oc = oct; }
        else if (k < 8) { o = axis * eb; oc = 5; }
        else if (k == 8) { o = vec2(0.0); oc = 6; }
        else if (k < 13) { o = ring * 0.35; oc = 6; }
        else { o = ring * 1.3; oc = 4; }
        float h = terrain(p.xz + o, oc);
        float sgn = axis.x + axis.y;
        if (k < 2) hx += h * sgn;
        else if (k < 4) hz += h * sgn;
        else if (k < 6) bx += h * sgn;
        else if (k < 8) bz += h * sgn;
        else if (k == 8) hc = h;
        else if (k < 13) r1 += h;
        else r2 += h;
      }
      // Faces use the wide slope. The tight one, seen this flat, breaks into a stippled grid.
      vec3 nB = normalize(vec3(-bx, 2.0 * eb, -bz));
      vec3 n = nB;
      float ao = clamp(0.92 + (hc - r1 * 0.25) * 0.12, 0.8, 1.0);
      float snowN = clamp(0.5 + gn(p.xz * 0.18) * 0.5, 0.0, 1.0);
      float gentle = smoothstep(0.28, 0.72, nB.y + (snowN - 0.5) * 0.12);
      float forestN = clamp(0.5 + gn(p.xz * 0.28) * 0.5, 0.0, 1.0);

      acc0 += vec4(n.x * 0.5 + 0.5, n.z * 0.5 + 0.5, 1.0, forestN) * cov;
      acc1 += vec4(t / T_DMAX, clamp(p.y / T_HMAX, 0.0, 1.0), ao, gentle) * cov;
      covSum += cov;
    }
  }
  float inv = 1.0 / ss;
  // Premultiplied by coverage: attribute * coverage, and coverage itself in g0.z.
  g0 = acc0 * inv;
  g1 = acc1 * inv;
}
`;

  // --------------------------------------------------------------- main pass
  //
  // Sky, stars, moon and the valley, at full resolution, with the aurora buffer composited in.
  // The terrain mask is evaluated here at full resolution, which is what keeps the half-resolution
  // aurora from bleeding over the ridgelines.
  var MAIN_FRAG = COMMON + `
out vec4 frag;

uniform sampler2D uAur;
uniform float uAurStore;
uniform float uPx;          // radians per buffer pixel
uniform float uNight;       // 1 night, 0 polar noon
uniform vec2  uSun;         // height (-1..1), azimuth
uniform vec4  uMoon;        // azimuth, elevation, phase, illumination
uniform float uMoonLight;
uniform vec3  uAurLight;
uniform float uSnow;
uniform float uIce;
uniform float uFog;
uniform float uSnowfall;
uniform float uDays;
uniform float uSlopeForest;
uniform vec4  uHouse[9];    // azimuth, size, born day, flicker seed
uniform float uLit;
uniform vec4  uFire;        // azimuth, flicker, intensity, visible
uniform float uPath;
uniform vec4  uMeteor;      // azimuth, elevation, angle, progress (negative = none)
uniform vec2  uMeteorB;     // length, brightness
uniform float uCam;
uniform vec4  uT;           // twinkle phase, snowfall offset, fog drift, ripple drift
uniform vec4  uT2;          // smoke rise, wind, unused, unused
uniform float uSeed;
uniform sampler2D uSpruceM;   // Blender Spruce_Mature billboard
uniform sampler2D uSpruceD;   // Blender Spruce_Mid billboard
uniform sampler2D uSpruceY;   // Blender Spruce_Young billboard
uniform float uSpruceReady;   // 1 once textures are bound

const float CAMH = 0.035;
const vec3 SNOW = vec3(0.80, 0.86, 0.97);

float cover(float inside, float px) { return clamp(inside / px + 0.5, 0.0, 1.0); }
float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

// ---------------------------------------------------------------- sky

vec3 skyCol(vec2 ae) {
  float e = max(ae.y, 0.0);
  float g = exp(-e * 8.0);
  vec3 night = mix(vec3(0.0016, 0.0035, 0.010), vec3(0.007, 0.012, 0.024), g);
  vec3 day = mix(vec3(0.020, 0.048, 0.13), vec3(0.20, 0.25, 0.38), pow(g, 1.6));
  float side = exp(-pow(aDiff(ae.x, uSun.y) / 1.1, 2.0));
  day += vec3(0.36, 0.17, 0.10) * exp(-e * 20.0) * (0.25 + 0.75 * side) * smoothstep(-0.6, 0.6, uSun.x);
  vec3 c = mix(day, night, uNight);
  // Airglow: the faint green band real night skies carry near the horizon.
  c += vec3(0.004, 0.009, 0.005) * exp(-e * 14.0) * uNight;
  return c;
}

vec3 stars(vec2 ae, float pxPerRad) {
  vec3 s = vec3(0.0);
  for (int L = 0; L < 3; L++) {
    float fl = float(L);
    float cell = L == 0 ? 0.0052 : (L == 1 ? 0.012 : 0.034);
    float prob = L == 0 ? 0.22 : (L == 1 ? 0.18 : 0.16);
    vec2 g = ae / cell + fl * 17.31;
    vec2 id = floor(g);
    vec2 f = fract(g);
    float r = h21(id + 3.1 * fl);
    if (r > prob) continue;
    vec2 pos = 0.15 + 0.7 * h22(id + 9.7 * fl);
    float distPx = length(f - pos) * cell * pxPerRad;
    float m = h21(id + 1.3 + fl);
    float mag = pow(m, 7.0 - fl * 2.0);
    float b = (L == 0 ? 0.07 : (L == 1 ? 0.30 : 1.1)) * (0.25 + 2.5 * mag);
    float size = 0.6 + 0.25 * fl + mag * 0.7;
    float core = exp(-distPx * distPx / (size * size));
    float tw = 1.0 + (0.12 + 0.45 * exp(-ae.y * 9.0)) * sin(uT.x * (1.0 + floor(r * 7.0)) + r * 40.0);
    float t = h21(id + 5.5);
    vec3 tint = t > 0.85 ? vec3(1.0, 0.80, 0.58) : (t < 0.18 ? vec3(0.68, 0.80, 1.0) : vec3(0.88, 0.92, 1.0));
    s += tint * b * core * tw;
  }
  return s * smoothstep(0.0, 0.07, ae.y);
}

vec3 milkyWay(vec2 ae) {
  float c = 0.30 + 0.20 * sin(ae.x * 0.8 + 1.4);
  float w = 0.11;
  float band = exp(-pow((ae.y - c) / w, 2.0));
  if (band < 0.01) return vec3(0.0);
  vec2 q = ae * vec2(12.0, 18.0);
  float glow = 0.45 + 0.55 * fbm2(q);
  float dust = smoothstep(0.45, 0.72, fbm2(q * 1.7 + 4.0)) * exp(-pow((ae.y - c - 0.01) / (w * 0.35), 2.0));
  float grain = pow(n2(ae * 900.0), 6.0) * 0.6;
  return vec3(0.024, 0.026, 0.034) * band * max(glow - dust * 0.9, 0.0) * (1.0 + grain);
}

vec3 moon(vec2 ae, out float glow) {
  glow = 0.0;
  if (uMoon.y < -0.03 || uMoon.w < 0.02) return vec3(0.0);
  vec2 q = vec2(aDiff(ae.x, uMoon.x) * cos(ae.y), ae.y - uMoon.y);
  float R = 0.0085;
  float dist = length(q);
  float up = smoothstep(-0.02, 0.03, uMoon.y);
  glow = (exp(-dist / 0.05) * 0.06 + exp(-dist / 0.012) * 0.25) * uMoon.w * up;
  vec3 col = vec3(0.0);
  if (dist < R * 1.02) {
    vec2 u = q / R;
    float z = sqrt(max(0.0, 1.0 - dot(u, u)));
    float th = uMoon.z * TAU;
    vec3 l = vec3(sin(th), 0.0, -cos(th));
    float lit = smoothstep(-0.05, 0.12, dot(vec3(u, z), l));
    float maria = 0.72 + 0.28 * smoothstep(0.35, 0.65, fbm2(u * 2.5 + 7.0));
    float disc = cover((R - dist), uPx);
    col = vec3(1.0, 0.97, 0.9) * 2.4 * lit * maria * disc + vec3(0.02, 0.025, 0.035) * disc;
  }
  return col * up + vec3(0.65, 0.72, 0.85) * glow;
}

vec3 meteor(vec2 ae) {
  if (uMeteor.w < 0.0) return vec3(0.0);
  vec2 dir = vec2(cos(uMeteor.z), sin(uMeteor.z));
  vec2 start = uMeteor.xy;
  float travel = uMeteorB.x * uMeteor.w;
  vec2 head = start + dir * travel;
  float tail = min(travel, uMeteorB.x * 0.45);
  vec2 rel = vec2(aDiff(ae.x, head.x), ae.y - head.y);
  float along = -dot(rel, dir);
  float across = abs(rel.x * dir.y - rel.y * dir.x);
  if (along < -uPx * 3.0 || along > tail) return vec3(0.0);
  float fade = (1.0 - clamp(along / max(tail, 1e-4), 0.0, 1.0));
  float width = uPx * (0.6 + 0.8 * fade);
  float line = exp(-across * across / (width * width));
  float life = sin(PI * clamp(uMeteor.w, 0.0, 1.0));
  return vec3(0.85, 0.95, 1.0) * line * fade * fade * life * uMeteorB.y * 2.5;
}

// ------------------------------------------------------------- terrain
//
// The mountains are a real heightfield, raymarched once per view by the terrain pass into a
// geometry buffer (normal, coverage, distance, height, occlusion and two material noises). Here
// that buffer is only lit, which is what lets the range be fully 3D at the cost of a few texture
// reads: the light, the snow line, the forest and the haze change every frame, the shape never
// does. Values are stored premultiplied by coverage so bilinear filtering across a ridgeline
// stays correct.

uniform sampler2D uG0;     // normal.x, normal.z, coverage, forest noise
uniform sampler2D uG1;     // distance, height, occlusion, snow hold
uniform vec4 uGeo;         // margin columns, first row, horizon row, reveal
uniform vec2 uGSize;

const float T_DMAX = 130.0;
const float T_HMAX = 16.0;

vec4 terrainLayer(vec2 ae, vec3 L, vec3 moonL, vec3 fogCol) {
  // The whole range is far enough away to parallax as one layer.
  float ax = ae.x - uCam / 22.0;
  vec2 g = vec2((ax - uAz0) / uPx + uGeo.x, ae.y / uPx + uGeo.z - uGeo.y);
  vec2 uv = g / uGSize;
  if (uv.y < 0.0 || uv.y > 1.0) return vec4(0.0);
  vec4 a = texture(uG0, uv);
  float cov = a.z;
  if (cov < 0.004) return vec4(0.0);
  // The row above. A summit texel filtered against empty sky is what rubs the tip out.
  float aboveCov = texture(uG0, uv + vec2(0.0, 1.25 / uGSize.y)).z;
  float rim = smoothstep(0.45, 0.0, aboveCov) * smoothstep(0.004, 0.12, cov);
  vec4 b = texture(uG1, uv);
  float ic = 1.0 / cov;
  vec2 nxz = a.xy * ic * 2.0 - 1.0;
  vec3 n = vec3(nxz.x, sqrt(max(0.0, 1.0 - dot(nxz, nxz))), nxz.y);
  float forestN = a.w * ic;
  float dist = b.x * ic * T_DMAX;
  float hgt = b.y * ic * T_HMAX;
  float ao = b.z * ic;
  float gentle = b.w * ic;

  // Snow lies on the gentler faces and leaves steep rock bare; the snow line climbs out of the
  // valleys in summer and comes down to the shore in winter. The highest peaks stay capped.
  float snowLine = mix(5.2, -2.0, uSnow);
  float snow = gentle * smoothstep(snowLine - 1.4, snowLine + 1.4, hgt + (forestN - 0.5) * 0.6);
  // The broad slope points up at a summit, so the tip is lit like flat snow and disappears
  // into the sky. The skyline is rock, and its light comes from the side.
  n = normalize(mix(n, vec3(n.x, 0.08, n.z), rim));
  snow *= 1.0 - rim * 0.8;
  vec3 rock = vec3(0.045, 0.042, 0.044);
  vec3 alb = mix(rock, SNOW, snow);
  // Spruce climbing the lower slopes as the world ages, in broad stands rather than speckle.
  float treeline = 0.9 + 1.0 * uSlopeForest;
  float tree = uSlopeForest * smoothstep(treeline, treeline - 0.8, hgt)
             * smoothstep(0.55, 0.9, n.y) * smoothstep(0.2, 0.8, forestN) * smoothstep(45.0, 16.0, dist);
  // Far slopes only: one mip lookup from the Blender spruce bake (no extra geometry).
  vec3 spruceAlb = uSpruceReady > 0.5
    ? textureLod(uSpruceM, vec2(0.52, 0.42), 7.0).rgb
    : vec3(0.006, 0.010, 0.008);
  alb = mix(alb, mix(spruceAlb, SNOW * 0.5, uSnow * 0.45), tree);

  // Light. The aurora hangs over the lake, between us and the peaks, so the faces turned toward
  // the viewer catch it; wrap lighting keeps the shadowed side of the snow soft rather than black.
  vec3 aDir = normalize(vec3(0.0, 0.8, -0.6));
  float hemi = 0.5 + 0.5 * n.y;
  float wrapA = clamp((dot(n, aDir) + 0.55) / 1.55, 0.0, 1.0);
  vec3 mDir = dirOf(vec2(uMoon.x, max(uMoon.y, 0.03)));
  float wrapM = clamp((dot(n, mDir) + 0.2) / 1.2, 0.0, 1.0);
  vec3 sDir = dirOf(vec2(uSun.y, 0.1));
  float wrapS = clamp((dot(n, sDir) + 0.3) / 1.3, 0.0, 1.0);
  vec3 dayTint = vec3(0.30, 0.17, 0.12) * (1.0 - uNight) * smoothstep(-0.6, 0.6, uSun.x);
  vec3 light = L * (hemi * 0.45 + wrapA * wrapA * 1.5) * ao
             + moonL * wrapM * wrapM * 2.6 * (0.35 + 0.65 * ao)
             + dayTint * wrapS * ao * 0.3;
  // Light scattered inside the snowpack fills the creases a little.
  light += snow * L * 0.22 * (1.0 - ao * 0.5);
  vec3 col = alb * light;
  col /= 1.0 + max(col.r, max(col.g, col.b)) * 0.7;

  // Air between the ranges: haze with distance, settling in the valleys.
  float haze = 1.0 - exp(-dist * 0.016);
  haze += 0.3 * exp(-hgt * 1.3) * smoothstep(10.0, 35.0, dist);
  col = mix(col, fogCol * mix(0.8, 1.0, uNight), clamp(haze, 0.0, 0.8));
  cov = max(cov, rim * 0.92);
  cov *= uGeo.w;
  return vec4(col * cov, cov);
}
float shoreTop(float a) { return 0.0022 + 0.0042 * fbm1(a * 11.0 + 9.0); }

// Azimuth offset for a spruce. qy is 0 at the trunk base and 1 at the crown.
// The base stays planted; the crown leans with a shared gust plus a per-tree flutter.
// uT.y is seconds wrapped to 64. Every frequency here is an integer number of cycles
// in that window, so the lean matches on both sides of the wrap (a non-integer multiple
// of uT.x used to pop the trees every few seconds).
// uT2.y is the slow wind strength already driven from the host (about 0.3..0.6).
float spruceWind(float qy, float seed, float H) {
  float bend = clamp(qy, 0.0, 1.0);
  bend *= bend;
  float gustPh = uT.y * (TAU / 16.0);
  float gust = sin(gustPh) * 0.72 + sin(gustPh * 2.0 + seed * 5.2) * 0.28;
  float flutter = sin(gustPh * 5.0 + seed * 13.0 + qy * 5.0) * 0.2;
  float strength = 0.55 + uT2.y;
  return (gust + flutter) * strength * 0.11 * H * bend;
}

// One Blender billboard per spruce. Round it with cone shading, then let the aurora
// overhead raise and tint that shade. The bake stays the color; only the light moves.
// Cap follows the glow so a bright curtain can light the crown without blowing the snow.
vec3 auroraOver(float az) {
  float u = clamp((az - uAz0) / max(uRpc * uCss.x, 1e-4), 0.0, 1.0);
  return textureLod(uAur, vec2(u, 0.78), 1.4).rgb * uAurStore;
}

vec4 sampleSpruceBillboard(vec2 q, float seed, vec3 aur) {
  if (q.y < -0.04 || q.y > 1.05 || abs(q.x) > 0.62) return vec4(0.0);
  float rad = max(mix(0.56, 0.07, smoothstep(0.02, 1.0, q.y)), q.y < 0.16 ? 0.09 : 0.0);
  if (abs(q.x) > rad) return vec4(0.0);
  float pick = h11(seed * 13.1 + uSeed);
  vec2 uv = vec2(clamp(q.x * 0.9 + 0.5, 0.001, 0.999), clamp(1.0 - q.y, 0.001, 0.999));
  vec4 tex = pick < 0.34 ? texture(uSpruceY, uv)
           : (pick < 0.67 ? texture(uSpruceD, uv) : texture(uSpruceM, uv));
  float a = smoothstep(0.35, 0.55, tex.a);
  if (a <= 0.02) return vec4(0.0);
  float rim = clamp(1.0 - abs(q.x) / max(rad, 1e-3), 0.0, 1.0);
  float lumA = max(aur.r, max(aur.g, aur.b));
  float glow = clamp(lumA * 1.8, 0.0, 1.0);
  float shade = mix(0.5, 1.0, rim) * mix(0.82, 1.65, glow);
  shade *= 0.7 + 0.3 * clamp(0.35 + q.x * 1.2, 0.0, 1.0);
  vec3 col = tex.rgb * mix(0.28, 0.14, uNight) * shade;
  vec3 hue = aur / max(lumA, 1e-3);
  col = mix(col, col * hue, 0.5 * glow);
  col = min(col, vec3(mix(0.10, 0.17, glow)));
  col *= mix(0.72, 1.0, smoothstep(-0.02, 0.16, q.y));
  return vec4(col * a, a);
}

vec4 forestEdge(vec2 ae, float a6, vec3 L, vec3 moonL) {
  vec4 res = vec4(0.0);
  if (uSpruceReady < 0.5) return res;
  vec3 aur = auroraOver(ae.x);
  float cw = 0.0042;
  float g = a6 / cw;
  float id = floor(g);
  for (int k = 1; k >= -1; k--) {
    float cid = id + float(k);
    float r = h11(cid * 1.37 + uSeed);
    float born = 1.0 + r * 90.0;
    float grow = clamp((uDays - born) / (6.0 + 18.0 * h11(cid * 3.1 + uSeed)), 0.0, 1.0);
    if (grow <= 0.0) continue;
    grow = grow * grow * (3.0 - 2.0 * grow);
    float exist = step(h11(cid * 7.7 + uSeed), 0.86);
    if (exist < 0.5) continue;
    float H = (0.005 + 0.010 * h11(cid * 5.3 + uSeed)) * grow;
    float cx = (cid + 0.5 + (h11(cid * 9.1 + uSeed) - 0.5) * 0.7) * cw;
    float base = shoreTop(cx) - H * 0.02;
    float qy = (ae.y - base) / H;
    vec2 q = vec2(aDiff(a6, cx + spruceWind(qy, r, H)) / max(H * 0.55, 1e-4), qy);
    vec4 tc = sampleSpruceBillboard(q, r, aur);
    res = res * (1.0 - tc.a) + tc;
  }
  return res;
}

// A cabin: walls, a pitched roof that carries snow, a lit window and a chimney.
vec4 house(vec2 ae, float a6, vec4 h, vec3 L, float isCabin) {
  float s = h.y;
  float dx = aDiff(a6, h.x);
  if (abs(dx) > s * 1.4 || uDays < h.z) return vec4(0.0);
  float build = clamp((uDays - h.z) / 1.5, 0.0, 1.0);
  float base = shoreTop(h.x) - s * 0.04;
  vec2 q = vec2(dx, ae.y - base) / s;
  float px = uPx / s;
  float wallH = 0.42 * build;
  float body = cover(0.5 - abs(q.x), px) * cover(q.y, px) * cover(wallH - q.y, px);
  float ry = q.y - wallH;
  float roofH = 0.34 * build;
  float roof = cover(ry, px) * cover(0.64 * (1.0 - ry / max(roofH, 1e-3)) - abs(q.x), px);
  float chim = isCabin * cover(0.07 - abs(q.x - 0.3), px) * cover(q.y - wallH, px) * cover(wallH + roofH * 0.95 - q.y, px) * build;
  float win = cover(0.10 - abs(q.x - 0.17), px) * cover(0.11 - abs(q.y - 0.2), px) * step(0.99, build);
  float win2 = isCabin * cover(0.08 - abs(q.x + 0.22), px) * cover(0.10 - abs(q.y - 0.2), px) * step(0.99, build);
  float shape = max(max(body, roof), chim);
  if (shape <= 0.0) return vec4(0.0);
  vec3 wall = vec3(0.030, 0.018, 0.012) * (L * 6.0 + 0.004);
  vec3 roofCol = mix(vec3(0.012, 0.010, 0.010), SNOW * (L * 1.15), smoothstep(0.15, 0.5, uSnow));
  vec3 c = mix(wall, roofCol, roof * (1.0 - body));
  float flick = 0.88 + 0.12 * sin(uT.x * 3.0 + h.w);
  vec3 lamp = vec3(1.0, 0.56, 0.22) * 3.2 * uLit * flick;
  c = mix(c, lamp, max(win, win2) * body);
  return vec4(c * shape, shape);
}

float smoke(vec2 ae, vec2 src, float scale) {
  float dy = ae.y - src.y;
  if (dy < 0.0 || dy > scale * 14.0) return 0.0;
  float drift = dy * (0.35 + 0.25 * uT2.y) + sin(dy / scale * 0.9 - uT2.x * 0.6) * scale * 0.3;
  float dx = aDiff(ae.x, src.x) - drift;
  float w = scale * 0.25 + dy * 0.22;
  float body = exp(-dx * dx / (w * w));
  float puffs = n2(vec2(dx / scale * 3.0, dy / scale * 1.4 - uT2.x));
  return body * exp(-dy / (scale * 5.0)) * smoothstep(0.25, 0.75, puffs) * smoothstep(0.0, scale * 0.5, dy);
}

// Everything above the lake from the far shore back, premultiplied. Shared with the reflection.
vec4 landscape(vec2 ae, vec3 L, vec3 moonL, vec3 fogCol, float detail) {
  vec4 res = vec4(0.0);
  if (ae.y > 0.36) return res;

  float a6 = ae.x - uCam / 6.0;
  res = terrainLayer(ae, L, moonL, fogCol);

  float base = shoreTop(a6);
  float bankC = cover(base - ae.y, uPx) * cover(ae.y - (base - 0.006), uPx * 2.0);
  if (bankC > 0.0) {
    vec3 bank = SNOW * mix(0.35, 1.0, uSnow) * (L * 1.2 + moonL * 0.6);
    bank = mix(bank, fogCol, 0.18);
    res = res * (1.0 - bankC) + vec4(bank * bankC, bankC);
  }
  vec4 edge = forestEdge(ae, a6, L, moonL);
  edge.rgb = mix(edge.rgb, fogCol * edge.a, 0.18);
  res = res * (1.0 - edge.a) + edge;

  for (int i = 0; i < 9; i++) {
    vec4 hc = house(ae, a6, uHouse[i], L, i == 0 ? 1.0 : 0.0);
    res = res * (1.0 - hc.a) + hc;
  }
  return res;
}

// ---------------------------------------------------------------- lake

float crackLines(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  float d1 = 8.0, d2 = 8.0;
  for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
    vec2 g = vec2(float(x), float(y));
    vec2 r = g + h22(i + g) - f;
    float d = dot(r, r);
    if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) { d2 = d; }
  }
  return 1.0 - smoothstep(0.0, 0.05, sqrt(d2) - sqrt(d1));
}

vec3 lake(vec2 ae, vec2 uv, vec3 L, vec3 moonL, vec3 fogCol, float aurLum) {
  vec3 d = dirOf(ae);
  float sd = max(-d.y, 1e-4);
  float t = CAMH / sd;
  vec2 P = d.xz * t + vec2(uCam, 0.0);
  float ice = uIce;
  float water = 1.0 - ice;

  vec2 rp = P * vec2(2.2, 7.0);
  float rip = n2(rp + vec2(0.0, uT.w)) + 0.5 * n2(rp * 2.3 - vec2(uT.w * 1.3, 0.0)) - 0.75;
  float calm = smoothstep(0.0, 0.08, sd);
  float elr = -ae.y + rip * 0.007 * water * (0.3 + 0.7 * calm);
  vec2 aer = vec2(ae.x + rip * 0.0025 * water, max(elr, 0.0004));

  vec3 refl = skyCol(aer) + stars(aer, 1.0 / uPx) * 0.5 * water;
  float vr = 1.0 - (uHorizon - aer.y / uRpc) / uCss.y;
  float lod = mix(0.6, 2.2, ice);
  refl += textureLod(uAur, vec2(uv.x, min(vr, 0.995)), lod).rgb * uAurStore * smoothstep(1.1, 0.97, vr);
  vec4 rl = landscape(aer, L, moonL, fogCol, 0.6);
  refl = refl * (1.0 - rl.a) + rl.rgb;

  float fresWater = 0.02 + 0.98 * pow(1.0 - sd, 5.0);
  float fresIce = 0.10 + 0.55 * pow(1.0 - sd, 3.0);
  float F = mix(fresWater, fresIce, ice);

  vec3 waterCol = vec3(0.001, 0.002, 0.004);
  vec3 iceCol = vec3(0.010, 0.019, 0.028) * (L * 5.0 + moonL * 1.5 + 0.02);
  vec3 col = mix(waterCol, iceCol, ice);
  col = mix(col, refl, F);

  float drift = ice * smoothstep(0.52, 0.80, fbm2(P * vec2(0.65, 1.7) + 7.0) + (uSnow - 0.5) * 0.6);
  float crack = crackLines(P * 2.2) * exp(-t * 0.22) * ice * (1.0 - drift);
  col += crack * (refl * 0.5 + vec3(0.01, 0.03, 0.035) * (1.0 + aurLum * 4.0));

  // A trodden trail over the ice from the near shore toward the cabin, once people live here.
  if (uPath > 0.0) {
    vec2 from = vec2(sin(uFire.x), cos(uFire.x)) * 0.22;
    vec2 to = vec2(sin(uHouse[0].x), cos(uHouse[0].x));
    vec2 dir = normalize(to);
    vec2 rel = P - from - vec2(uCam, 0.0);
    float s = dot(rel, dir);
    float lat = dot(rel, vec2(-dir.y, dir.x)) - sin(s * 0.9) * 0.18;
    float vis = step(0.0, s) * smoothstep(14.0 * uPath, 14.0 * uPath - 1.5, s) * smoothstep(7.0, 1.5, t);
    float trail = exp(-lat * lat / 0.0016);
    float step2 = fract(s / 0.08);
    float side = mod(floor(s / 0.08), 2.0) * 2.0 - 1.0;
    float print = exp(-pow((lat - side * 0.018) / 0.009, 2.0)) * smoothstep(0.5, 0.2, abs(step2 - 0.5));
    col *= 1.0 - (trail * 0.18 + print * 0.35) * vis * ice;
  }

  col = mix(col, SNOW * (L * 1.25 + moonL * 0.7), drift);

  // Light paths across the surface: the moon, and the windows once the village is lit.
  float rough = 0.006 + 0.03 * ice + 0.006 * abs(rip);
  float moonUp = smoothstep(-0.01, 0.04, uMoon.y);
  float ms = exp(-pow(aDiff(ae.x, uMoon.x) / rough, 2.0)) * exp(-sd * 5.0) * uMoon.w * moonUp;
  col += vec3(0.7, 0.72, 0.8) * ms * 0.35 * (1.0 - drift);
  for (int i = 0; i < 9; i++) {
    vec4 h = uHouse[i];
    if (uDays < h.z + 1.5) continue;
    float hs = exp(-pow(aDiff(ae.x - uCam / 6.0, h.x) / (h.y * 0.25 + rough * 0.3), 2.0)) * exp(-sd / (0.02 + 0.02 * water));
    col += vec3(1.0, 0.5, 0.18) * hs * uLit * 0.18 * (1.0 - drift * 0.7);
  }

  col = mix(col, fogCol, smoothstep(3.0, 30.0, t) * 0.55);
  return col;
}

// ----------------------------------------------------------- foreground

float shoreNear(float a) { return -0.172 + 0.034 * fbm1(a * 2.6 + 2.0) + 0.012 * n1(a * 13.0); }

vec3 bank(vec2 ae, float a1, float sn, vec3 L, vec3 moonL, float fireGlow) {
  float dn = fbm2(vec2(a1 * 14.0, ae.y * 26.0));
  float rim = exp(-(sn - ae.y) / 0.012);
  float depth = smoothstep(-0.32, sn, ae.y);
  vec3 lightC = L * (0.55 + 0.6 * dn) + moonL * (0.5 + 0.5 * dn) + L * rim * 0.8;
  vec3 col = SNOW * mix(0.45, 1.0, uSnow) * lightC * (0.45 + 0.55 * depth);
  // Bare tundra showing through when the snow is thin.
  // Patches only exist while the snow is thinning; with no snow the bank is all tundra.
  float patches = fbm2(vec2(a1 * 22.0, ae.y * 60.0) + 3.0);
  float bare = clamp(smoothstep(-0.12, 0.12, patches - uSnow * 1.1 + 0.05) + (1.0 - smoothstep(0.0, 0.25, uSnow)), 0.0, 1.0);
  float moss = fbm2(vec2(a1 * 90.0, ae.y * 160.0));
  vec3 tundra = mix(vec3(0.010, 0.011, 0.007), vec3(0.016, 0.014, 0.008), moss) * (L * 4.0 + moonL * 1.5 + 0.01);
  col = mix(col, tundra * (0.6 + 0.4 * depth), bare);
  col += vec3(1.0, 0.45, 0.15) * fireGlow * SNOW * 0.08;
  return col;
}

// Near-shore spruces: a short cone of Blender slices, not a single card.
vec4 nearTrees(vec2 ae, float a1, vec3 L, vec3 moonL) {
  vec4 res = vec4(0.0);
  if (uSpruceReady < 0.5) return res;
  vec3 aur = auroraOver(ae.x);
  float cw = 0.062;
  float g = a1 / cw;
  float id = floor(g);
  for (int k = 1; k >= -1; k--) {
    float cid = id + float(k);
    float r = h11(cid * 2.71 + uSeed);
    if (r > 0.58) continue;
    float r2 = h11(cid * 4.13 + uSeed);
    float born = 1.0 + r2 * 40.0;
    float grow = clamp((uDays - born) / (6.0 + 18.0 * r), 0.0, 1.0);
    if (grow <= 0.0) continue;
    grow = grow * grow * (3.0 - 2.0 * grow);
    float cx = (cid + 0.5 + (h11(cid * 6.7 + uSeed) - 0.5) * 0.6) * cw;
    float base = shoreNear(cx) - 0.008 - r2 * 0.03;
    float H = (0.07 + 0.17 * h11(cid * 8.9 + uSeed)) * (0.25 + 0.75 * grow);
    float qy = (ae.y - base) / H;
    vec2 q = vec2(aDiff(a1, cx + spruceWind(qy, r, H)) / max(H * 0.62, 1e-4), qy);
    vec4 tc = sampleSpruceBillboard(q, r, aur);
    res = res * (1.0 - tc.a) + tc;
  }
  return res;
}

// --------------------------------------------------------------- snowfall

vec3 snowfall(vec2 frag, vec3 L) {
  if (uSnowfall <= 0.01) return vec3(0.0);
  vec2 css = vec2(frag.x / uRes.x * uCss.x + (uAz0 / uRpc), (1.0 - frag.y / uRes.y) * uCss.y);
  vec3 s = vec3(0.0);
  for (int l = 0; l < 3; l++) {
    float fl = float(l);
    float cs = l == 0 ? 26.0 : (l == 1 ? 48.0 : 90.0);
    float rad = l == 0 ? 0.9 : (l == 1 ? 1.5 : 2.4);
    vec2 p = css;
    p.y -= mod(uT.y * cs, cs * 64.0);
    p.x += sin(p.y / (cs * 2.3) + fl * 2.0 + uT.y * 0.2) * cs * 0.4 + uT2.y * p.y * 0.15;
    vec2 g = p / cs;
    vec2 id = floor(g);
    id.y = mod(id.y, 64.0);
    vec2 f = fract(g);
    if (h21(id + fl * 13.0) > 0.35 * uSnowfall + 0.05) continue;
    vec2 pos = 0.2 + 0.6 * h22(id + fl * 3.0);
    float dist = length((f - pos) * cs);
    float flake = exp(-dist * dist / (rad * rad));
    s += SNOW * flake * (L * 2.5 + 0.02) * (0.4 + 0.3 * fl);
  }
  return s * uSnowfall;
}

void main() {
  vec2 fragC = gl_FragCoord.xy;
  vec2 uv = fragC / uRes;
  vec2 ae = anglesAt(fragC);

  // Light cast by the aurora onto the ground: a wide average of the sky above, so individual
  // rays do not print stripes onto the terrain.
  vec3 aurTop = (textureLod(uAur, vec2(uv.x - 0.12, 0.75), 7.0).rgb
               + textureLod(uAur, vec2(uv.x, 0.75), 7.0).rgb * 2.0
               + textureLod(uAur, vec2(uv.x + 0.12, 0.75), 7.0).rgb) * 0.25 * uAurStore * 1.4;
  float aurLum = lum(aurTop);
  vec3 amb = mix(vec3(0.045, 0.068, 0.11), vec3(0.0045, 0.007, 0.013), uNight);
  vec3 L = amb + uAurLight + aurTop * 0.22;
  vec3 moonL = vec3(0.45, 0.5, 0.6) * uMoonLight;
  vec3 fogCol = skyCol(vec2(ae.x, 0.01)) * 1.1 + aurTop * 0.05 + moonL * 0.05;

  vec3 col;
  if (ae.y >= 0.0) {
    vec3 sky = skyCol(ae);
    vec3 aur = textureLod(uAur, uv, 0.6).rgb * uAurStore;
    float al = lum(aur);
    float dim = uNight * uNight / (1.0 + al * 6.0);
    float mglow;
    sky += stars(ae, 1.0 / uPx) * dim * (1.0 - uMoonLight * 0.4);
    sky += milkyWay(ae) * dim * (1.0 - uMoonLight * 1.2);
    sky += moon(ae, mglow);
    sky += meteor(ae);
    sky += aur;
    vec4 land = landscape(ae, L, moonL, fogCol, 1.0);
    col = sky * (1.0 - land.a) + land.rgb;
  } else {
    col = lake(ae, uv, L, moonL, fogCol, aurLum);
  }

  // Low fog over the lake, thickest at the water and when open water meets cold air.
  float fogBand = uFog * exp(-abs(ae.y) / 0.03) * (0.5 + 0.5 * fbm2(vec2(ae.x * 6.0 + uT.z, ae.y * 45.0)));
  col = mix(col, fogCol * 1.1 + L * 0.2, clamp(fogBand, 0.0, 0.85));

  // Campfire on the near shore.
  float a1 = ae.x - uCam / 1.5;
  float fireEl = shoreNear(uFire.x) - 0.002;
  vec2 fr = vec2(aDiff(a1, uFire.x), ae.y - fireEl);
  float fireGlow = uFire.w * uFire.z * exp(-length(fr / vec2(0.045, 0.022)));

  float sn = shoreNear(a1);
  float cb = cover(sn - ae.y, uPx);
  if (cb > 0.0) col = mix(col, bank(ae, a1, sn, L, moonL, fireGlow), cb);

  if (uFire.w > 0.0) {
    float sm = smoke(vec2(a1, ae.y), vec2(uFire.x, fireEl + 0.006), 0.006) * uFire.w;
    col = mix(col, (L * 1.6 + moonL * 0.4) * 0.6 + vec3(0.25, 0.1, 0.03) * fireGlow, clamp(sm * 0.45, 0.0, 1.0));
    float flame = exp(-dot(fr / vec2(0.0035, 0.007) - vec2(0.0, 0.6), fr / vec2(0.0035, 0.007) - vec2(0.0, 0.6)));
    col += vec3(1.0, 0.42, 0.10) * flame * 5.0 * uFire.y * uFire.z * uFire.w;
    col += vec3(1.0, 0.40, 0.12) * fireGlow * 0.03;
  }

  // Chimney smoke from the cabin.
  if (uDays > uHouse[0].z + 1.5) {
    float a6 = ae.x - uCam / 6.0;
    vec2 chimney = vec2(uHouse[0].x + 0.3 * uHouse[0].y, shoreTop(uHouse[0].x) + uHouse[0].y * 0.78);
    float sm = smoke(vec2(a6, ae.y), chimney, uHouse[0].y * 0.35);
    col = mix(col, L * 1.4 + moonL * 0.3, clamp(sm * 0.35, 0.0, 1.0));
  }

  vec4 tr = nearTrees(ae, a1, L, moonL);
  col = col * (1.0 - tr.a) + tr.rgb;

  col += snowfall(fragC, L);

  frag = vec4(col, 1.0);
}
`;

  // ------------------------------------------------------------- post passes

  var BRIGHT_FRAG = `#version 300 es
precision highp float;
out vec4 frag;
uniform sampler2D uSrc;
uniform vec2 uTexel;
void main() {
  vec2 uv = gl_FragCoord.xy * uTexel;
  vec3 c = vec3(0.0);
  c += texture(uSrc, uv + vec2(-1.0, -1.0) * uTexel * 0.5).rgb;
  c += texture(uSrc, uv + vec2( 1.0, -1.0) * uTexel * 0.5).rgb;
  c += texture(uSrc, uv + vec2(-1.0,  1.0) * uTexel * 0.5).rgb;
  c += texture(uSrc, uv + vec2( 1.0,  1.0) * uTexel * 0.5).rgb;
  c *= 0.25;
  float l = max(c.r, max(c.g, c.b));
  float k = max(l - 0.35, 0.0);
  k = k * k / (k + 0.4);
  frag = vec4(c * k / max(l, 1e-4), 1.0);
}`;

  var BLUR_FRAG = `#version 300 es
precision highp float;
out vec4 frag;
uniform sampler2D uSrc;
uniform vec2 uDir;
uniform vec2 uTexel;
void main() {
  vec2 uv = gl_FragCoord.xy * uTexel;
  vec3 c = texture(uSrc, uv).rgb * 0.2270270;
  c += texture(uSrc, uv + uDir * 1.3846154).rgb * 0.3162162;
  c += texture(uSrc, uv - uDir * 1.3846154).rgb * 0.3162162;
  c += texture(uSrc, uv + uDir * 3.2307692).rgb * 0.0702703;
  c += texture(uSrc, uv - uDir * 3.2307692).rgb * 0.0702703;
  frag = vec4(c, 1.0);
}`;

  var FINAL_FRAG = `#version 300 es
precision highp float;
out vec4 frag;
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform vec2 uRes;
uniform float uBloomGain;
uniform float uExposure;

vec3 aces(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec3 c = texture(uScene, uv).rgb + texture(uBloom, uv).rgb * uBloomGain;
  c = aces(c * uExposure);
  c = pow(c, vec3(1.0 / 2.2));
  // Dither below one 8-bit step. The night sky is almost all near-black gradient, which is where
  // banding shows first.
  float n = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
  float n2 = fract(sin(dot(gl_FragCoord.xy + 17.0, vec2(39.346, 11.135))) * 24634.6345);
  c += (n + n2 - 1.0) / 255.0;
  frag = vec4(c, 1.0);
}`;

  // ------------------------------------------------------------------ GL setup

  var progAurora, progMain, progBright, progBlur, progFinal, progTerrain;
  var vao = null;
  var hdr = false;
  var aurTex = [null, null], aurFbo = [null, null], aurW = 0, aurH = 0, aurMips = 1;
  var sceneTex = null, sceneFbo = null;
  var bloomTex = [null, null], bloomFbo = [null, null], bloomW = 0, bloomH = 0;
  // Terrain geometry buffer: two attachments, rebuilt in strips whenever the view changes.
  var geo = null, geoKey = '', geoDone = 0, geoStrip = 8, geoFade = 0;
  var cur = 0;
  var freshHistory = true;
  var uniformCache = new Map();

  function compile(type, src) {
    var s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS) && !gl.isContextLost()) {
      throw new Error('shader compile failed: ' + gl.getShaderInfoLog(s));
    }
    return s;
  }

  function program(fragSrc) {
    var p = gl.createProgram();
    gl.attachShader(p, compile(gl.VERTEX_SHADER, VERT));
    gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fragSrc));
    gl.bindAttribLocation(p, 0, 'aPos');
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS) && !gl.isContextLost()) {
      throw new Error('program link failed: ' + gl.getProgramInfoLog(p));
    }
    uniformCache.set(p, {});
    return p;
  }

  // The terrain shader is large enough that a driver can take seconds to compile it. It is
  // linked without waiting, polled each frame through KHR_parallel_shader_compile where the
  // browser has it, and the range simply stays hidden until it is ready.
  var parallelCompile = null, terrainJob = null;

  function programAsync(fragSrc) {
    var vs = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vs, VERT);
    gl.compileShader(vs);
    var fs = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fs, fragSrc);
    gl.compileShader(fs);
    var p = gl.createProgram();
    gl.attachShader(p, vs);
    gl.attachShader(p, fs);
    gl.bindAttribLocation(p, 0, 'aPos');
    gl.linkProgram(p);
    return { prog: p, fs: fs, ready: false };
  }

  function terrainReady() {
    if (!terrainJob) return false;
    if (terrainJob.ready) return true;
    if (parallelCompile && !gl.getProgramParameter(terrainJob.prog, parallelCompile.COMPLETION_STATUS_KHR)) {
      return false;
    }
    if (!gl.getProgramParameter(terrainJob.prog, gl.LINK_STATUS)) {
      if (gl.isContextLost()) return false;
      throw new Error('terrain shader failed: ' +
        (gl.getShaderInfoLog(terrainJob.fs) || gl.getProgramInfoLog(terrainJob.prog)));
    }
    progTerrain = terrainJob.prog;
    uniformCache.set(progTerrain, {});
    terrainJob.ready = true;
    return true;
  }

  function U(p, name) {
    var cache = uniformCache.get(p);
    if (!(name in cache)) cache[name] = gl.getUniformLocation(p, name);
    return cache[name];
  }

  function initGL() {
    hdr = !!gl.getExtension('EXT_color_buffer_float');
    gl.getExtension('OES_texture_float_linear');
    uniformCache = new Map();
    progAurora = program(AURORA_FRAG);
    progMain = program(MAIN_FRAG);
    progBright = program(BRIGHT_FRAG);
    progBlur = program(BLUR_FRAG);
    progFinal = program(FINAL_FRAG);
    parallelCompile = gl.getExtension('KHR_parallel_shader_compile');
    progTerrain = null;
    terrainJob = programAsync(TERRAIN_FRAG);

    vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.BLEND);
    aurTex = [null, null];
    sceneTex = null;
    bloomTex = [null, null];
    geo = null;
    geoKey = '';
  }

  function makeTarget(w, h, levels) {
    var tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texStorage2D(gl.TEXTURE_2D, levels, hdr ? gl.RGBA16F : gl.RGBA8, w, h);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, levels > 1 ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    var fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    return { tex: tex, fbo: fbo };
  }

  function release(tex, fbo) {
    if (tex) gl.deleteTexture(tex);
    if (fbo) gl.deleteFramebuffer(fbo);
  }

  function auroraScale() { return quality === 'low' ? 0.4 : 0.5; }
  function layerCount() { return quality === 'low' ? 22 : (quality === 'medium' ? 30 : 40); }

  function allocTargets() {
    if (contextLost || bufW < 1 || bufH < 1) return;
    var aw = Math.max(2, Math.ceil(bufW * auroraScale()));
    var ah = Math.max(2, Math.ceil(bufH * auroraScale()));
    if (aw !== aurW || ah !== aurH || !aurTex[0]) {
      for (var i = 0; i < 2; i++) release(aurTex[i], aurFbo[i]);
      aurMips = Math.floor(Math.log2(Math.max(aw, ah))) + 1;
      for (var j = 0; j < 2; j++) {
        var t = makeTarget(aw, ah, aurMips);
        aurTex[j] = t.tex; aurFbo[j] = t.fbo;
      }
      aurW = aw; aurH = ah;
      freshHistory = true;
    }

    var sw = bufW, sh = bufH;
    if (!sceneTex || sceneTex.w !== sw || sceneTex.h !== sh) {
      if (sceneTex) release(sceneTex.tex, sceneFbo);
      var s = makeTarget(sw, sh, 1);
      sceneTex = { tex: s.tex, w: sw, h: sh };
      sceneFbo = s.fbo;
    }

    var bw = Math.max(2, Math.ceil(bufW / 4)), bh = Math.max(2, Math.ceil(bufH / 4));
    if (bw !== bloomW || bh !== bloomH || !bloomTex[0]) {
      for (var k = 0; k < 2; k++) release(bloomTex[k], bloomFbo[k]);
      for (var m = 0; m < 2; m++) {
        var b = makeTarget(bw, bh, 1);
        bloomTex[m] = b.tex; bloomFbo[m] = b.fbo;
      }
      bloomW = bw; bloomH = bh;
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  function geoSupersample() { return quality === 'low' ? 1 : 2; }

  // Lays out the geometry buffer for the current view: the rows from just under the horizon to
  // above the highest summit, plus a margin of columns either side for the camera's parallax.
  // Any change of size, view or quality invalidates it and the strips start over.
  function ensureTerrain(v) {
    var px = v.rpc * width / bufW;
    var rowH = bufH * (1 - HORIZON);
    var row0 = Math.floor(rowH) - 2;
    var h = Math.max(2, Math.min(bufH - row0, Math.ceil(0.36 / px) + 4));
    var margin = Math.ceil(0.0035 / px) + 2;
    var w = bufW + margin * 2;
    var key = [w, h, row0, rowH, v.az0.toFixed(7), v.rpc.toFixed(9), geoSupersample()].join('|');
    if (key === geoKey && geo) return;

    if (!geo || geo.w !== w || geo.h !== h) {
      if (geo) {
        gl.deleteTexture(geo.t0); gl.deleteTexture(geo.t1); gl.deleteFramebuffer(geo.fbo);
      }
      var fmt = hdr ? gl.RGBA16F : gl.RGBA8;
      var mk = function () {
        var t = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, t);
        gl.texStorage2D(gl.TEXTURE_2D, 1, fmt, w, h);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        return t;
      };
      var t0 = mk(), t1 = mk();
      var fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t0, 0);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT1, gl.TEXTURE_2D, t1, 0);
      gl.drawBuffers([gl.COLOR_ATTACHMENT0, gl.COLOR_ATTACHMENT1]);
      geo = { t0: t0, t1: t1, fbo: fbo, w: w, h: h };
    }
    geo.row0 = row0; geo.rowH = rowH; geo.margin = margin; geo.px = px;
    gl.bindFramebuffer(gl.FRAMEBUFFER, geo.fbo);
    gl.clearBufferfv(gl.COLOR, 0, [0, 0, 0, 0]);
    gl.clearBufferfv(gl.COLOR, 1, [0, 0, 0, 0]);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    geoKey = key;
    geoDone = 0;
    geoFade = 0;
  }

  // One strip of the geometry buffer per frame, bottom up, so a rebuild never stalls a frame.
  // The strip is sized from the frame time it caused: GPUs differ by more than an order of
  // magnitude here, and a fixed size either crawls on a fast card or stutters on a slow one.
  function drawTerrainStrip(v, dt) {
    if (!geo || geoDone >= geo.h || !terrainReady()) return;
    var budget = 1 / (maxFps || 30);
    // A frame longer than this was the tab stalling, not the GPU. Shrinking the strip on it
    // leaves the range rebuilding one row at a time long after the stall ends.
    if (geoDone > 0 && dt > 0.0 && dt < 0.1) {
      if (dt > budget * 1.35) geoStrip = Math.max(4, Math.floor(geoStrip * 0.6));
      else if (dt < budget * 1.12) geoStrip = Math.min(96, Math.ceil(geoStrip * 1.3));
    }
    var rows = Math.min(geoStrip, geo.h - geoDone);
    for (var unit = 1; unit <= 2; unit++) {
      gl.activeTexture(gl.TEXTURE0 + unit);
      gl.bindTexture(gl.TEXTURE_2D, null);
    }
    gl.activeTexture(gl.TEXTURE0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, geo.fbo);
    gl.viewport(0, 0, geo.w, geo.h);
    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(0, geoDone, geo.w, rows);
    gl.useProgram(progTerrain);
    setCommon(progTerrain, bufW, bufH, v);
    gl.uniform1f(U(progTerrain, 'uGPx'), geo.px);
    gl.uniform4f(U(progTerrain, 'uGeo'), geo.margin, geo.row0, geo.rowH, 0);
    gl.uniform4i(U(progTerrain, 'uCounts'), geoSupersample(), 360, 6, 17);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.disable(gl.SCISSOR_TEST);
    geoDone += rows;
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = Math.max(1, window.innerWidth);
    height = Math.max(1, window.innerHeight);
    bufW = Math.max(1, Math.round(width * dpr));
    bufH = Math.max(1, Math.round(height * dpr));
    canvas.width = bufW;
    canvas.height = bufH;
    allocTargets();
  }

  function placeOnDesktop(display) {
    if (!display) return;
    preview = display.id === 'PREVIEW';
    originX = typeof display.x === 'number' ? display.x : 0;
    pxPerCss = (typeof display.width === 'number' && width > 0) ? display.width / width : 1;
    if (!isFinite(pxPerCss) || pxPerCss <= 0) pxPerCss = 1;
  }

  // The view, as the shaders need it. A library card is one small screen, so it fits the whole
  // composition rather than showing the slice of sky its pixel width would otherwise cover.
  function view() {
    if (preview) {
      var rpcP = FOV_SPAN / Math.max(width, 1) * 0.9;
      return { az0: -width * rpcP * 0.5, rpc: rpcP };
    }
    var rpc = FOV_SPAN / SPAN;
    var deskCss = originX / pxPerCss;
    return { az0: (deskCss - SPAN * 0.5) * rpc, rpc: rpc };
  }

  function setCommon(p, w, h, v) {
    gl.uniform2f(U(p, 'uRes'), w, h);
    gl.uniform2f(U(p, 'uCss'), width, height);
    gl.uniform1f(U(p, 'uAz0'), v.az0);
    gl.uniform1f(U(p, 'uRpc'), v.rpc);
    gl.uniform1f(U(p, 'uHorizon'), height * HORIZON);
  }

  // --------------------------------------------------------------------- frame

  var curtainData = new Float32Array(16);

  function render(dt) {
    cursor.x = approach(cursor.x, cursorTarget.x, 5.0, dt);
    cursor.y = approach(cursor.y, cursorTarget.y, 5.0, dt);
    presence = approach(presence, presenceTarget, 2.6, dt);
    attractMix = approach(attractMix, cursorMotion === CURSOR_ATTRACT ? 1 : 0, 1.6, dt);
    repelMix = approach(repelMix, cursorMotion === CURSOR_REPEL ? 1 : 0, 1.6, dt);
    energyTarget = approach(energyTarget, 0, 2.2, dt);
    energy = approach(energy, energyTarget, 5.0, dt);

    level = approach(level, audioReactive ? levelTarget : 0, 7.0, dt);
    bass = approach(bass, audioReactive ? bassTarget : 0, 9.0, dt);
    treble = approach(treble, audioReactive ? trebleTarget : 0, 12.0, dt);
    pulse = audioReactive ? pulse * Math.exp(-3.4 * dt) : 0;
    musicHue = mod(musicHue + dt * (level * 0.05 + bass * 0.04 + pulse * 0.25), 1);
    // Left unwrapped: its uses scale it into different periods, so wrapping here would jump.
    musicFlow += dt * (level * 0.9 + bass * 0.6 + pulse * 1.5);

    var wall = Date.now();
    var tSec = (wall - EPOCH) / 1000;
    syncWorld(wall);
    worldDays = ageInDays(wall);

    var season = seasonAt(worldDays);
    var dayFrac = dayFraction(wall);
    var sunHeight = -Math.cos(dayFrac * TAU);
    // Polar night: the sun never clears the horizon, so "day" is the blue noon twilight and the
    // aurora fades rather than vanishing.
    var nightness = 1 - smoothstep((sunHeight + 0.35) / 0.65);
    var auroraGain = lerp(0.16, 1.0, nightness);

    var activity = clamp01(activityAt(worldDays, tSec) + level * 0.25);
    var breakup = breakupAt(wall, activity);
    var storm = breakup.s;

    var snow = clamp01(season.winter * 1.0 + season.autumn * 0.45 + season.spring * 0.6 + season.summer * 0.12);
    var ice = iceAt(season.phase);
    var openCold = (1 - ice) * (season.autumn + season.spring);
    var fog = clamp01(0.12 + 0.55 * openCold + 0.25 * dayNoise(worldDays * 0.8, 0xF06) * (1 - season.winter * 0.5));
    var snowing = smoothstep((dayNoise(worldDays * 1.3, 0x5A0) - 0.5) / 0.3);
    var snowfall = clamp01((season.winter * 0.9 + season.autumn * 0.35 + season.spring * 0.3) * snowing);

    var v = view();
    var aw = aurW, ah = aurH;

    // -------- aurora
    var prev = cur ^ 1;
    gl.bindVertexArray(vao);
    gl.bindFramebuffer(gl.FRAMEBUFFER, aurFbo[cur]);
    gl.viewport(0, 0, aw, ah);
    gl.useProgram(progAurora);
    setCommon(progAurora, aw, ah, v);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, aurTex[prev]);
    gl.uniform1i(U(progAurora, 'uPrev'), 0);
    gl.uniform1f(U(progAurora, 'uBlend'), freshHistory ? 1 : 0.38);
    gl.uniform1f(U(progAurora, 'uFrame'), frames % 1024);
    gl.uniform1f(U(progAurora, 'uLayers'), layerCount());

    var sweep = storm * breakup.u * 7.0;
    var g1 = clamp01(smoothstep((activity - 0.28) / 0.25) + level * 0.3);
    var g2 = clamp01(smoothstep((activity - 0.5) / 0.3) * 0.9 + level * 0.2);
    var g3 = Math.max(smoothstep((activity - 0.82) / 0.18), storm) * 0.8;
    curtainData.set([
      6.5 + 1.4 * Math.sin(wrapPhase(tSec, TAU / 1500)), 1.0, 0.13, 1.0,
      4.2 + 0.9 * Math.sin(wrapPhase(tSec, TAU / 2100) + 1.0), g1, 0.61, 1.3,
      10.5 + 2.0 * Math.sin(wrapPhase(tSec, TAU / 2700) + 2.0), g2, 0.37, 0.85,
      2.4 + 0.5 * Math.sin(wrapPhase(tSec, TAU / 1300) + 4.0), g3, 0.89, 1.6
    ]);
    gl.uniform4fv(U(progAurora, 'uCur'), curtainData);
    gl.uniform4f(U(progAurora, 'uOffA'),
      mod(wrapNoise(tSec, 0.08) + sweep + musicFlow * 0.08, NOISE_PERIOD),
      mod(wrapNoise(tSec, 0.22) + musicFlow * 0.2, NOISE_PERIOD),
      mod(wrapNoise(tSec, 0.55) + musicFlow * 0.6, NOISE_PERIOD), wrapNoise(tSec, 1.2));
    gl.uniform4f(U(progAurora, 'uOffB'),
      wrapNoise(tSec, 0.015), wrapNoise(tSec, 0.08), wrapNoise(tSec, 7.0 + treble * 6.0), 0);
    gl.uniform4f(U(progAurora, 'uPhase'),
      mod(wrapPhase(tSec, 0.18) + sweep * 0.3 + musicFlow * 0.25, TAU),
      mod(wrapPhase(tSec, 0.25) + musicFlow * 0.35, TAU),
      wrapPhase(tSec, 0.08), wrapPhase(tSec, 5.0));
    gl.uniform4f(U(progAurora, 'uHue'),
      mod(wrapNoise(tSec, 0.05) + musicFlow * 0.15, NOISE_PERIOD),
      mod(tSec * 0.0015 + musicHue, 1), 1, 0);
    gl.uniform1f(U(progAurora, 'uActivity'), activity);
    gl.uniform1f(U(progAurora, 'uStorm'), storm);
    gl.uniform1f(U(progAurora, 'uBright'), auroraGain * (0.55 + 0.3 * activity + 0.8 * storm + 0.45 * level + 0.25 * bass));
    gl.uniform1f(U(progAurora, 'uFringe'), clamp01(smoothstep((activity - 0.4) / 0.4) + storm * 0.6));
    gl.uniform1f(U(progAurora, 'uRedTop'), clamp01(smoothstep((activity - 0.62) / 0.35) * 0.75 + storm * 0.5));
    gl.uniform1f(U(progAurora, 'uViolet'), storm * 0.45 * smoothstep((activity - 0.7) / 0.2));

    var cssX = cursor.x * width, cssY = cursor.y * height;
    gl.uniform4f(U(progAurora, 'uCursor'),
      v.az0 + cssX * v.rpc, (height * HORIZON - cssY) * v.rpc, presence, energy);
    gl.uniform2f(U(progAurora, 'uMode'), attractMix, repelMix);
    gl.uniform1f(U(progAurora, 'uRipple'), wrapPhase(tSec, 6.0));
    gl.uniform4f(U(progAurora, 'uAudio'), level, bass, treble, pulse);
    gl.uniform1f(U(progAurora, 'uStore'), hdr ? 1 : 0.25);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    gl.bindTexture(gl.TEXTURE_2D, aurTex[cur]);
    gl.generateMipmap(gl.TEXTURE_2D);
    freshHistory = false;

    // -------- terrain geometry (only while a rebuild is in progress)
    ensureTerrain(v);
    drawTerrainStrip(v, dt);

    // -------- main
    gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFbo);
    gl.viewport(0, 0, bufW, bufH);
    gl.useProgram(progMain);
    setCommon(progMain, bufW, bufH, v);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, geo.t0);
    gl.uniform1i(U(progMain, 'uG0'), 1);
    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, geo.t1);
    gl.uniform1i(U(progMain, 'uG1'), 2);
    // The range rises out of the haze once its buffer is complete, rather than building upward
    // strip by strip in view.
    geoFade = geoDone >= geo.h ? approach(geoFade, 1, 1.4, dt) : 0;
    gl.uniform4f(U(progMain, 'uGeo'), geo.margin, geo.row0, geo.rowH, geoFade * geoFade * (3 - 2 * geoFade));
    gl.uniform2f(U(progMain, 'uGSize'), geo.w, geo.h);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, aurTex[cur]);
    gl.uniform1i(U(progMain, 'uAur'), 0);
    gl.uniform1f(U(progMain, 'uAurStore'), hdr ? 1 : 4);
    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, spruceTex[0]);
    gl.uniform1i(U(progMain, 'uSpruceM'), 3);
    gl.activeTexture(gl.TEXTURE4);
    gl.bindTexture(gl.TEXTURE_2D, spruceTex[1]);
    gl.uniform1i(U(progMain, 'uSpruceD'), 4);
    gl.activeTexture(gl.TEXTURE5);
    gl.bindTexture(gl.TEXTURE_2D, spruceTex[2]);
    gl.uniform1i(U(progMain, 'uSpruceY'), 5);
    gl.uniform1f(U(progMain, 'uSpruceReady'), spruceReady ? 1 : 0);
    gl.uniform1f(U(progMain, 'uPx'), v.rpc * width / bufW);
    gl.uniform1f(U(progMain, 'uNight'), nightness);
    gl.uniform2f(U(progMain, 'uSun'), sunHeight, dayFrac * TAU);

    var moonPhase = mod(worldDays / MOON_CYCLE, 1);
    var moonS = mod(dayFrac - moonPhase - 0.25, 1);
    var moonEl = 0.36 * Math.sin(moonS * TAU) - 0.02;
    var moonAz = -0.8 + 3.2 * moonS;
    var illum = 0.5 * (1 - Math.cos(moonPhase * TAU));
    gl.uniform4f(U(progMain, 'uMoon'), moonAz, moonEl, moonPhase, illum);
    gl.uniform1f(U(progMain, 'uMoonLight'), illum * smoothstep((moonEl + 0.02) / 0.1) * 0.06 * nightness);

    var aurLight = auroraGain * (0.006 + 0.01 * activity + 0.025 * storm + 0.008 * level);
    gl.uniform3f(U(progMain, 'uAurLight'), aurLight * 0.35, aurLight, aurLight * 0.55);
    gl.uniform1f(U(progMain, 'uSnow'), snow);
    gl.uniform1f(U(progMain, 'uIce'), ice);
    gl.uniform1f(U(progMain, 'uFog'), fog);
    gl.uniform1f(U(progMain, 'uSnowfall'), snowfall);
    gl.uniform1f(U(progMain, 'uDays'), worldDays);
    gl.uniform1f(U(progMain, 'uSlopeForest'), forestAt(worldDays));
    gl.uniform4fv(U(progMain, 'uHouse'), houses);
    gl.uniform1f(U(progMain, 'uLit'), smoothstep((nightness - 0.15) / 0.5) * 0.85 + 0.15);

    var fireVisible = smoothstep((worldDays - FIRE_BORN) / 1.0);
    var fireFlicker = 0.75 + 0.15 * Math.sin(wrapPhase(tSec, 13.0)) + 0.1 * Math.sin(wrapPhase(tSec, 31.0));
    gl.uniform4f(U(progMain, 'uFire'), FIRE_AZ, fireFlicker, smoothstep((nightness - 0.2) / 0.5), fireVisible);
    gl.uniform1f(U(progMain, 'uPath'), smoothstep((worldDays - PATH_BORN) / 10));

    var m = meteorAt(wall, worldDays, nightness);
    if (m) {
      gl.uniform4f(U(progMain, 'uMeteor'), m.az, m.el, m.angle, m.u);
      gl.uniform2f(U(progMain, 'uMeteorB'), m.len, m.bright);
    } else {
      gl.uniform4f(U(progMain, 'uMeteor'), 0, 0, 0, -1);
    }

    // Parallax: a camera drifting a little over a quarter of an hour, plus the pointer's lean.
    var cam = 0.05 * Math.sin(wrapPhase(tSec, TAU / 900)) + (cursor.x - 0.5) * 0.03 * presence;
    gl.uniform1f(U(progMain, 'uCam'), cam);
    gl.uniform4f(U(progMain, 'uT'), wrapPhase(tSec, 1.7), mod(tSec, 64), wrapNoise(tSec, 0.012), wrapNoise(tSec, 0.35));
    gl.uniform4f(U(progMain, 'uT2'), wrapNoise(tSec, 0.6), 0.3 + 0.3 * Math.sin(wrapPhase(tSec, TAU / 300)), 0, 0);
    gl.uniform1f(U(progMain, 'uSeed'), (worldSeed % 997) * 0.731);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    // -------- bloom
    var bloomOn = quality !== 'low';
    if (bloomOn) {
      gl.viewport(0, 0, bloomW, bloomH);
      gl.bindFramebuffer(gl.FRAMEBUFFER, bloomFbo[0]);
      gl.useProgram(progBright);
      gl.bindTexture(gl.TEXTURE_2D, sceneTex.tex);
      gl.uniform1i(U(progBright, 'uSrc'), 0);
      gl.uniform2f(U(progBright, 'uTexel'), 1 / bloomW, 1 / bloomH);
      gl.drawArrays(gl.TRIANGLES, 0, 3);

      gl.useProgram(progBlur);
      gl.uniform1i(U(progBlur, 'uSrc'), 0);
      gl.uniform2f(U(progBlur, 'uTexel'), 1 / bloomW, 1 / bloomH);
      for (var pass = 0; pass < 2; pass++) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, bloomFbo[1]);
        gl.bindTexture(gl.TEXTURE_2D, bloomTex[0]);
        gl.uniform2f(U(progBlur, 'uDir'), (pass + 1) / bloomW, 0);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        gl.bindFramebuffer(gl.FRAMEBUFFER, bloomFbo[0]);
        gl.bindTexture(gl.TEXTURE_2D, bloomTex[1]);
        gl.uniform2f(U(progBlur, 'uDir'), 0, (pass + 1) / bloomH);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
    }

    // -------- final
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, bufW, bufH);
    gl.useProgram(progFinal);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, sceneTex.tex);
    gl.uniform1i(U(progFinal, 'uScene'), 0);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, bloomTex[0]);
    gl.uniform1i(U(progFinal, 'uBloom'), 1);
    gl.uniform2f(U(progFinal, 'uRes'), bufW, bufH);
    gl.uniform1f(U(progFinal, 'uBloomGain'), bloomOn ? 0.6 : 0);
    gl.uniform1f(U(progFinal, 'uExposure'), 1.8);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.activeTexture(gl.TEXTURE0);

    cur ^= 1;
  }

  // --------------------------------------------------------------------- loop

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);
    var interval = 1000 / (maxFps || 30);
    if (lastFrame && now - lastFrame < interval - 0.5) return;
    if (contextLost) return;

    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.25) : 0;
    lastFrame = now;

    render(dt);
    frames++;
    beatFrames++;
    stamps.push(now);

    if (!lastBeat) lastBeat = now;
    else if (now - lastBeat >= 1000) {
      post({
        v: SCHEMA,
        type: 'heartbeat',
        fps: Math.round(beatFrames * 10000 / (now - lastBeat)) / 10,
        fpsFloor: worstFps(),
        frames: frames
      });
      lastBeat = now;
      beatFrames = 0;
      stamps = stamps.length ? [stamps[stamps.length - 1]] : [];
    }
  }

  // The slowest frame since the last heartbeat, as a rate, over that interval only.
  function worstFps() {
    if (stamps.length < 3) return 0;
    var worst = 0;
    for (var i = 1; i < stamps.length; i++) {
      var gap = stamps[i] - stamps[i - 1];
      if (gap > worst) worst = gap;
    }
    return worst > 0 ? Math.round(10000 / worst) / 10 : 0;
  }

  function start() {
    if (rafHandle) return;
    lastFrame = 0;
    lastBeat = 0;
    beatFrames = 0;
    stamps.length = 0;
    // A paused frame's history is stale by however long the pause was.
    freshHistory = true;
    rafHandle = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  // ----------------------------------------------------------------- messages

  function applyOptions(options) {
    if (!options) return;
    if (options.cursorMotion === CURSOR_ATTRACT || options.cursorMotion === CURSOR_REPEL ||
        options.cursorMotion === CURSOR_OFF) {
      cursorMotion = options.cursorMotion;
    }
    if (typeof options.audioReactive === 'string') audioReactive = options.audioReactive === 'true';
    if (typeof options.dayNightCycle === 'string') dayNightCycle = options.dayNightCycle === 'true';
    if (options.fixedSky === 'night' || options.fixedSky === 'twilight') fixedSky = options.fixedSky;
    if (typeof options.evolutionSpeed === 'string' &&
        Object.prototype.hasOwnProperty.call(SPEEDS, options.evolutionSpeed)) {
      evolutionRate = SPEEDS[options.evolutionSpeed];
    }
  }

  function settleMode() {
    if (modeSettled) return;
    modeSettled = true;
    attractMix = cursorMotion === CURSOR_ATTRACT ? 1 : 0;
    repelMix = cursorMotion === CURSOR_REPEL ? 1 : 0;
  }

  function applyCursor(c) {
    if (c.onDisplay === false) { presenceTarget = 0; return; }
    presenceTarget = 1;
    if (typeof c.x === 'number') cursorTarget.x = c.x;
    if (typeof c.y === 'number') cursorTarget.y = c.y;
    var vx = typeof c.vx === 'number' ? c.vx : 0;
    var vy = typeof c.vy === 'number' ? c.vy : 0;
    energyTarget = Math.max(energyTarget, Math.min(1, Math.sqrt(vx * vx + vy * vy) / 0.04));
  }

  function applyAudio(a) {
    if (!a || !a.active) {
      levelTarget = 0; bassTarget = 0; trebleTarget = 0;
      return;
    }
    // RMS of ordinary music sits low, so it is expanded with a square root before use.
    levelTarget = typeof a.rms === 'number' ? Math.min(1, Math.sqrt(Math.max(0, a.rms)) * 1.3) : 0;
    var b = a.bands;
    if (!b || b.length < BAND_COUNT) return;
    var low = 0, high = 0;
    for (var i = 0; i < 4; i++) low += b[i];
    for (var j = BAND_COUNT - 5; j < BAND_COUNT; j++) high += b[j];
    bassTarget = Math.min(1, Math.sqrt(low / 4) * 1.25);
    trebleTarget = Math.min(1, Math.sqrt(high / 5) * 1.25);
    // Onsets against a slow mean of the low end: the curtains move on the beat, not just with
    // the volume.
    bassAverage = bassAverage * 0.92 + bassTarget * 0.08;
    var jump = bassTarget - bassAverage;
    if (jump > 0.06) pulse = Math.min(1, pulse + jump * 2.6);
  }

  function applyPerformance(msg) {
    if (msg.maxFps) maxFps = msg.maxFps;
    if (msg.quality === 'high' || msg.quality === 'medium' || msg.quality === 'low') {
      if (msg.quality !== quality) {
        quality = msg.quality;
        allocTargets();
      }
    }
  }

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { return; }
    }
    if (!msg || typeof msg.type !== 'string') return;
    switch (msg.type) {
      case 'life.init':
        if (msg.performance) applyPerformance(msg.performance);
        applyOptions(msg.options);
        settleMode();
        resize();
        placeOnDesktop(msg.display);
        break;
      case 'life.pause': stop(); break;
      case 'life.resume': start(); break;
      case 'life.resize':
        // Never restarts the loop: a resolution change must not wake a paused scene.
        resize();
        placeOnDesktop(msg.display);
        break;
      case 'life.destroy': stop(); break;
      case 'env.tick':
        if (msg.cursor) applyCursor(msg.cursor);
        if (msg.audio) applyAudio(msg.audio);
        break;
      case 'rt.options': applyOptions(msg.options); break;
      case 'rt.performance': applyPerformance(msg); break;
      default: break;
    }
  }

  canvas.addEventListener('webglcontextlost', function (e) {
    e.preventDefault();
    contextLost = true;
    resumeAfterRestore = !!rafHandle;
    stop();
  });

  canvas.addEventListener('webglcontextrestored', function () {
    contextLost = false;
    try {
      initGL();
      resize();
    } catch (err) {
      fail(err.message);
      return;
    }
    if (resumeAfterRestore) start();
  });

  window.addEventListener('resize', resize);
  window.addEventListener('error', function (e) {
    post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) { onMessage(e.data); });
  }

  try {
    initGL();
  } catch (err) {
    fail(err.message);
    return;
  }
  resize();
  loadWorld();
  post({ v: SCHEMA, type: 'ready', sceneId: sceneId, renderer: 'webgl2' });
  start();
})();
