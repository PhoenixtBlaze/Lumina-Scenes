# Aurora Drift

Volumetric northern lights over a frozen arctic lake. Version 2.1.19.

One full-screen WebGL2 triangle. The wallpaper stays at 30 fps because the valley, lake, curtains, and shore trees are shaded, not meshed.

## What you see

- Curtains are sheets standing in a volume, sampled at stacked altitudes. Folds, rays, and the colour change with height come from that volume.
- On a second monitor the sheets hang on a ring at the same distance as the forward view, so they reach the outer edge instead of sliding out of a flat slab.
- Stars, moon, mountains, a lake that freezes and thaws, and a shore of Blender-baked spruce billboards (`assets/spruce/`).
- Trees sway on a wind that repeats inside the shader clock, so the loop does not pop.
- A bright curtain overhead lifts and tints the spruce under it. The foliage stays the baked tree.
- Far slopes stay a cheap forest tint. Hero GLBs in `assets/library/flora/spruce/` are the source meshes; the wallpaper does not load them.

## How time works

Day and night follow the wall clock. Snow, ice, forest, and the settlement advance twelve world days per real day, so a season turns over in about a week of ownership. A new world opens in late winter: deep snow and a frozen lake.

The world is an epoch and a seed in `localStorage` (`lumina.world.aurora-drift`). Two displays are two windows on one valley. Azimuth comes from the display's virtual-desktop X, and every phase comes from `Date.now()`, so the screens meet without a seam.

## Options

| Option | What it does |
|--------|----------------|
| Pointer response | Curtains bend toward the pointer, part around it, or ignore it. |
| React to audio | Music drives curtain activity. Off, the night follows its own cycle. |
| Day / night cycle | Off holds the sky at night or polar twilight. |
| World evolution | Developer only. Live is the clock above. Faster rates are for watching years pass. |

Signals are optional. No cursor and no audio still looks like the scene.
