# Aurora Drift

Aurora borealis over a detailed mountain range.

### Look
- Soft aurora borealis glow field (dense overlapping light, no stroked waves, no vertical pillars)
- Atmospheric bloom, stars, and a slow palette drift
- Detailed range: crest relief, snow caps, gullies, foothills, rock mottling, rim light

### Lumina
- `life.init`, `life.pause`, `life.resume`, `life.resize`, `life.destroy`
- Heartbeat reports `fps` and `fpsFloor`
- 30 FPS from the manifest
- No network, CDN, or external assets
