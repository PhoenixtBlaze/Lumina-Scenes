# Ember Veil

A Drift-class living wallpaper: warm hearth valley under drifting embers.

## Interactive systems

- Cursor attract / repel / off
- Audio-reactive ember intensity
- Day / night (wall clock) and ecology age (~12 world days per real day)
- Persistent `{ epoch, seed }` in `localStorage`
- Seasons as ash / heat haze / ember storms
- Settlement growth (campfire → dwellings)
- Twitch effects: celebration burst, ember shower
- Population agents when the host negotiates `population` (chatters or NPCs)

## Performance

Target 30 fps. Canvas2D, offline CSP, no network.
