// Drifting accent streaks over a soft bloom.
//
// A port of the WPF procedural wallpaper these scenes replaced, which could not be made to render
// at all once the window was parented under Progman. The look is deliberately unchanged; only the
// way it is drawn is different.
//
// Identical in all three sibling scenes. Each package carries its own copy because a scene is
// distributed as a self-contained folder, and its identity comes from index.html and scene.json
// rather than from this file.
(function () {
  'use strict';

  var SCHEMA = 1;

  // Ported constants. Motion is per second rather than per tick: the original advanced a fixed
  // distance on a 50ms dispatcher timer, which tied its speed to a timer this scene does not have.
  var STREAK_COUNT = 36;
  var STREAK_RUN = 40;           // segment length along x
  var STREAK_RISE = 8;           // segment length along y
  var STREAK_WIDTH = 2.2;
  var STREAK_ALPHA = 160 / 255;
  var DRIFT_X = 56;              // px/s, was 2.8px per 50ms tick
  var DRIFT_Y = 28;              // px/s, was 1.4px per 50ms tick

  var GLOW_RADIUS = 260;
  var GLOW_ALPHA = 90 / 255;
  var GLOW_MIN = 0.35;
  var GLOW_MAX = 0.9;
  var GLOW_RAMP = 4000;          // ms in one direction; the original auto-reversed over 4s

  var canvas = document.getElementById('scene');
  var ctx = canvas.getContext('2d');
  var sceneId = document.body.dataset.sceneId || 'unknown';
  var rgb = toRgb(document.body.dataset.accent || '#B56CFF');

  var width = 0;
  var height = 0;
  var streaks = [];
  var maxFps = 30;

  var rafHandle = 0;
  var lastFrame = 0;
  var lastBeat = 0;
  var beatFrames = 0;
  var frames = 0;
  var elapsed = 0;               // animation time in ms, drives the bloom

  function post(message) {
    if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(message);
  }

  function toRgb(hex) {
    var n = parseInt(String(hex).replace('#', ''), 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  function rgba(alpha) {
    return 'rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ',' + alpha + ')';
  }

  // Static, so it costs nothing per frame. The original tinted the outer edge with a fifth of the
  // accent and left the centre almost black.
  function paintBackdrop() {
    var edge = 'rgb(' +
      Math.round(rgb.r / 5) + ',' + Math.round(rgb.g / 6) + ',' + Math.round(rgb.b / 4) + ')';
    document.body.style.background =
      'radial-gradient(ellipse 85% 85% at 50% 35%, rgb(8,6,14) 0%, ' + edge + ' 100%)';
  }

  function resize() {
    var dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.max(1, Math.round(width * dpr));
    canvas.height = Math.max(1, Math.round(height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (!streaks.length) seed();
  }

  // Only ever seeded once. Re-seeding on resize would snap every streak to a new random position,
  // which is exactly what made the original flicker when the display changed.
  function seed() {
    streaks = [];
    for (var i = 0; i < STREAK_COUNT; i++) {
      streaks.push({
        x: Math.random() * width,
        y: Math.random() * height,
        alpha: 0.25 + Math.random() * 0.6
      });
    }
  }

  function advance(dt) {
    var dx = DRIFT_X * dt;
    var dy = DRIFT_Y * dt;
    for (var i = 0; i < streaks.length; i++) {
      var s = streaks[i];
      s.x += dx;
      s.y += dy;
      if (s.y > height + 40) {
        s.y = -40;
        s.x = Math.random() * width;
      }
      if (s.x > width + 40) s.x = -20;
    }
  }

  function draw() {
    ctx.clearRect(0, 0, width, height);

    // The original animated the bloom's opacity linearly and auto-reversed, which is a triangle
    // wave rather than a sine.
    var phase = (elapsed % (GLOW_RAMP * 2)) / GLOW_RAMP;
    var glow = GLOW_MIN + (GLOW_MAX - GLOW_MIN) * (phase <= 1 ? phase : 2 - phase);

    var cx = width / 2;
    var cy = height / 2 - 20;
    var bloom = ctx.createRadialGradient(cx, cy, 0, cx, cy, GLOW_RADIUS);
    bloom.addColorStop(0, rgba(GLOW_ALPHA));
    bloom.addColorStop(1, rgba(0));
    ctx.globalAlpha = glow;
    ctx.fillStyle = bloom;
    ctx.beginPath();
    ctx.arc(cx, cy, GLOW_RADIUS, 0, Math.PI * 2);
    ctx.fill();

    ctx.lineWidth = STREAK_WIDTH;
    ctx.strokeStyle = rgba(STREAK_ALPHA);
    for (var i = 0; i < streaks.length; i++) {
      var s = streaks[i];
      ctx.globalAlpha = s.alpha;
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(s.x + STREAK_RUN, s.y + STREAK_RISE);
      ctx.stroke();
    }

    ctx.globalAlpha = 1;
  }

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);

    // Honour the host's cap. This is mandatory, not advisory: nothing else in the stack limits a
    // wallpaper's frame rate, and requestAnimationFrame is not a frame limiter.
    var interval = 1000 / (maxFps || 30);
    if (lastFrame && now - lastFrame < interval - 0.5) return;

    // Clamped so a long pause or a stalled compositor cannot teleport every streak at once.
    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.25) : 0;
    lastFrame = now;
    elapsed += dt * 1000;

    advance(dt);
    draw();
    frames++;
    beatFrames++;

    // From inside the render loop, never a timer. A heartbeat on setInterval would keep arriving
    // from a scene that had stopped drawing, which is the failure the host watchdog exists to
    // catch, and the host suspends scenes that keep beating after life.pause.
    if (!lastBeat) {
      lastBeat = now;
    } else if (now - lastBeat >= 1000) {
      post({
        v: SCHEMA,
        type: 'heartbeat',
        fps: Math.round(beatFrames * 10000 / (now - lastBeat)) / 10,
        frames: frames
      });
      lastBeat = now;
      beatFrames = 0;
    }
  }

  function start() {
    if (rafHandle) return;
    lastFrame = 0;          // so the first frame after a resume has no accumulated delta
    lastBeat = 0;
    beatFrames = 0;
    rafHandle = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { return; }
    }
    if (!msg || typeof msg.type !== 'string') return;

    switch (msg.type) {
      case 'life.init':
        if (msg.performance && msg.performance.maxFps) maxFps = msg.performance.maxFps;
        resize();
        break;
      case 'life.pause':
        // Required, not advisory. The host leaves the surface up so this frame stays on screen.
        stop();
        break;
      case 'life.resume':
        start();
        break;
      case 'life.resize':
        // Deliberately does not start the loop: a resolution change must never wake a scene that
        // a fullscreen game paused.
        resize();
        break;
      case 'life.destroy':
        stop();
        break;
      case 'rt.performance':
        if (msg.maxFps) maxFps = msg.maxFps;
        break;
      default:
        // Unknown types are ignored on purpose: it is what lets the host add signals without a
        // coordinated release of every existing scene. This scene negotiates none.
        break;
    }
  }

  window.addEventListener('resize', resize);
  window.addEventListener('error', function (e) {
    post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) { onMessage(e.data); });
  }

  paintBackdrop();
  resize();
  post({ v: SCHEMA, type: 'ready', sceneId: sceneId, renderer: 'canvas2d' });
  start();
})();
