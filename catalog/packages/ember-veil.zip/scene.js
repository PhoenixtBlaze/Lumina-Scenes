// Ember Veil - living hearth valley under a veil of embers, for Lumina.
//
// Canvas2D Drift-class sibling of Wave Drift: dual clocks, cursor/audio, seasons as ash and
// heat, settlement growth, Twitch effects, and optional population agents from the host.
(function () {
  'use strict';

  var SCHEMA = 1;
  var canvas = document.getElementById('scene');
  var ctx = canvas.getContext('2d', { alpha: false });
  var sceneId = document.body.dataset.sceneId || 'ember-veil';
  var SPAN = 1920;
  var EPOCH = Date.UTC(2026, 0, 1);

  var width = 0, height = 0, dpr = 1;
  var maxFps = 30;
  var rafHandle = 0, lastFrame = 0, lastBeat = 0;
  var beatFrames = 0, frames = 0, stamps = [];
  var originX = 0, originY = 0, pxPerCss = 1;

  var CURSOR_ATTRACT = 'attract', CURSOR_REPEL = 'repel', CURSOR_OFF = 'off';
  var cursorMotion = CURSOR_ATTRACT;
  var audioReactive = true;
  var dayNightCycle = true;
  var fixedSky = 'night';
  var attractMix = 1, repelMix = 0, modeSettled = false;

  var cursor = { x: 0.5, y: 0.5 };
  var cursorTarget = { x: 0.5, y: 0.5 };
  var presence = 0, presenceTarget = 0;
  var energy = 0, energyTarget = 0;
  var level = 0, levelTarget = 0;
  var bass = 0, bassTarget = 0;
  var pulse = 0;

  var DAY_MS = 86400000;
  var WORLD_KEY = 'lumina.world.ember-veil';
  var WORLD_SYNC_MS = 2000;
  var worldEpoch = 0;
  var worldSeed = 0xE1BE4;
  var worldDays = 0;
  var lastWorldSync = 0;
  var epochDayOffset = 0;
  var SPEEDS = { live: 1, hour: 24, minute: 1440, fast: 8640, warp: 43200 };
  var evolutionRate = 1;
  var LIFE_PER_REAL_DAY = 12;

  var sunAlt = -1, nightness = 1, dayFrac = 0, worldGrowth = 0;
  var ashFall = 0, heatHaze = 0, emberStorm = 0;

  var embers = [];
  var ash = [];
  var dwellings = [];
  var fxBurst = 0;
  var fxShower = 0;

  // Population agents (host evt.population). Drawn on the near shore when negotiated.
  var popAgents = [];
  var agentSheet = null;
  var agentReady = false;
  var AGENT_COLS = 8;
  var AGENT_ROWS = 10;
  var AGENT_FRAMES = {
    walk: { start: 0, count: 8, loop: true },
    sitting: { start: 64, count: 8, loop: true },
    sleeping: { start: 72, count: 8, loop: true },
    building: { start: 48, count: 8, loop: true },
    attack: { start: 8, count: 8, loop: false }
  };

  function post(message) {
    if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(message);
  }

  function lerp(a, b, t) { return a + (b - a) * t; }
  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
  function mod(v, n) { return ((v % n) + n) % n; }
  function smoothstep(v) { v = clamp01(v); return v * v * (3 - 2 * v); }
  function approach(current, target, rate, dt) {
    return current + (target - current) * (1 - Math.exp(-rate * dt));
  }
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function rgba(r, g, b, a) {
    return 'rgba(' + Math.round(r) + ',' + Math.round(g) + ',' + Math.round(b) + ',' + a + ')';
  }

  function ecologyRate() {
    return evolutionRate > 1 ? evolutionRate : LIFE_PER_REAL_DAY;
  }

  function readWorld() {
    try {
      var raw = window.localStorage.getItem(WORLD_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed.epoch !== 'number' || !isFinite(parsed.epoch)) return null;
      return { epoch: parsed.epoch, seed: (parsed.seed >>> 0) || 0xE1BE4 };
    } catch (e) { return null; }
  }

  function writeWorld() {
    try {
      window.localStorage.setItem(WORLD_KEY, JSON.stringify({ epoch: worldEpoch, seed: worldSeed }));
    } catch (e) { /* private mode */ }
  }

  function anchorDay() {
    var d = new Date(worldEpoch);
    epochDayOffset = ((d.getHours() * 60 + d.getMinutes()) * 60 + d.getSeconds()) * 1000;
  }

  function loadWorld() {
    var stored = readWorld();
    if (stored) {
      worldEpoch = stored.epoch;
      worldSeed = stored.seed;
      anchorDay();
      return;
    }
    worldEpoch = Math.floor(Date.now() / 60000) * 60000;
    worldSeed = (Math.imul(worldEpoch >>> 9, 0x9E3779B1) ^ 0xE1BE4) >>> 0;
    writeWorld();
    anchorDay();
  }

  function syncWorld(wall) {
    if (wall - lastWorldSync < WORLD_SYNC_MS) return;
    lastWorldSync = wall;
    var stored = readWorld();
    if (stored && (stored.epoch !== worldEpoch || stored.seed !== worldSeed)) {
      worldEpoch = stored.epoch;
      worldSeed = stored.seed;
      anchorDay();
      seedLife();
    }
  }

  function ageInDays(wall) {
    return Math.max(0, (wall - worldEpoch) * ecologyRate() / DAY_MS);
  }

  function dayFraction(wall) {
    if (!dayNightCycle) return fixedSky === 'day' ? 0.5 : 0;
    return mod((epochDayOffset + (wall - worldEpoch) * evolutionRate) / DAY_MS, 1);
  }

  function sunHeight(frac) {
    return Math.sin((frac - 0.25) * Math.PI * 2);
  }

  function seasonAt(days) {
    var phase = mod(days / 365 + 0.15, 1);
    // Ember theme: dry heat, ash season, calm, and stormy ember nights.
    var dry = Math.exp(-Math.pow((phase - 0.25) / 0.18, 2));
    var ash = Math.exp(-Math.pow((phase - 0.55) / 0.16, 2));
    var calm = Math.exp(-Math.pow((phase - 0.85) / 0.2, 2));
    var stormy = Math.exp(-Math.pow((phase - 0.05) / 0.14, 2));
    var sum = dry + ash + calm + stormy + 1e-6;
    return { dry: dry / sum, ash: ash / sum, calm: calm / sum, stormy: stormy / sum, phase: phase };
  }

  function growth(days) {
    return smoothstep(days / 40);
  }

  function seedLife() {
    var r = rng(worldSeed ^ 0x51A77);
    dwellings = [];
    var count = 1 + Math.floor(r() * 5);
    for (var i = 0; i < count; i++) {
      dwellings.push({
        x: 0.12 + r() * 0.76,
        born: 2 + r() * 55,
        kind: r() < 0.35 ? 'fire' : (r() < 0.55 ? 'tent' : 'house'),
        w: 0.02 + r() * 0.03,
        h: 0.03 + r() * 0.05
      });
    }

    embers = [];
    for (var e = 0; e < 90; e++) {
      embers.push({
        x: r(),
        y: r(),
        z: 0.3 + r() * 0.7,
        s: 0.6 + r() * 1.8,
        ph: r() * Math.PI * 2
      });
    }
    ash = [];
    for (var a = 0; a < 70; a++) {
      ash.push({
        x: r(),
        y: r(),
        v: 0.015 + r() * 0.04,
        w: 0.2 + r() * 0.8
      });
    }
  }

  function loadAgentSheet() {
    var img = new Image();
    img.onload = function () {
      agentSheet = img;
      agentReady = true;
    };
    img.onerror = function () { agentReady = false; };
    img.src = 'assets/agents/agent.png';
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.max(1, Math.round(width * dpr));
    canvas.height = Math.max(1, Math.round(height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function placeOnDesktop(display) {
    if (!display) return;
    if (typeof display.originX === 'number') originX = display.originX;
    if (typeof display.originY === 'number') originY = display.originY;
    if (typeof display.pxPerCss === 'number') pxPerCss = display.pxPerCss;
  }

  function drawSky(p) {
    var g = ctx.createLinearGradient(0, 0, 0, height);
    var top = [
      lerp(28, 8, nightness),
      lerp(18, 4, nightness),
      lerp(22, 10, nightness)
    ];
    var mid = [
      lerp(180, 40, nightness) + heatHaze * 20,
      lerp(90, 18, nightness),
      lerp(70, 22, nightness)
    ];
    var bot = [
      lerp(70, 18, nightness),
      lerp(28, 8, nightness),
      lerp(24, 10, nightness)
    ];
    g.addColorStop(0, rgba(top[0], top[1], top[2], 1));
    g.addColorStop(0.45, rgba(mid[0], mid[1], mid[2], 1));
    g.addColorStop(1, rgba(bot[0], bot[1], bot[2], 1));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, width, height);

    // Soft sun / moon disk
    var cx = width * (0.2 + dayFrac * 0.6);
    var cy = height * (0.55 - sunAlt * 0.35);
    var glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, height * 0.35);
    if (nightness < 0.85) {
      glow.addColorStop(0, rgba(255, 200, 120, 0.55 * (1 - nightness)));
      glow.addColorStop(1, rgba(255, 120, 60, 0));
    } else {
      glow.addColorStop(0, rgba(255, 220, 180, 0.18));
      glow.addColorStop(1, rgba(255, 160, 80, 0));
    }
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, width, height);
  }

  function drawRange(t) {
    var horizon = height * 0.58;
    ctx.beginPath();
    ctx.moveTo(0, height);
    ctx.lineTo(0, horizon + 20);
    for (var i = 0; i <= 24; i++) {
      var u = i / 24;
      var x = u * width;
      var n = Math.sin((u * 6 + worldSeed * 0.001) * Math.PI) * 0.5
            + Math.sin((u * 13 + t * 0.00005) * Math.PI) * 0.2;
      var y = horizon - (0.08 + 0.14 * worldGrowth) * height * (0.55 + n);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(width, height);
    ctx.closePath();
    var rock = ctx.createLinearGradient(0, horizon - height * 0.25, 0, height);
    rock.addColorStop(0, rgba(62, 28, 26, 1));
    rock.addColorStop(0.5, rgba(36, 16, 14, 1));
    rock.addColorStop(1, rgba(18, 8, 8, 1));
    ctx.fillStyle = rock;
    ctx.fill();

    // Near shore bank
    var shore = height * 0.78;
    ctx.beginPath();
    ctx.moveTo(0, height);
    for (var s = 0; s <= 20; s++) {
      var su = s / 20;
      var sx = su * width;
      var sy = shore + Math.sin(su * 9 + worldSeed) * 10 + Math.sin(su * 21) * 4;
      if (s === 0) ctx.lineTo(0, sy);
      else ctx.lineTo(sx, sy);
    }
    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fillStyle = rgba(48 + heatHaze * 20, 22, 18, 1);
    ctx.fill();
  }

  function drawSettlement() {
    var shore = height * 0.78;
    for (var i = 0; i < dwellings.length; i++) {
      var d = dwellings[i];
      if (worldDays < d.born) continue;
      var grow = clamp01((worldDays - d.born) / 3);
      grow = grow * grow * (3 - 2 * grow);
      var x = d.x * width;
      var w = d.w * width * grow;
      var h = d.h * height * grow;
      var y = shore - h * 0.15;
      if (d.kind === 'fire') {
        var flick = 0.7 + 0.3 * Math.sin(Date.now() * 0.01 + i);
        ctx.fillStyle = rgba(255, 140, 60, 0.55 * flick);
        ctx.beginPath();
        ctx.arc(x, y - 4, w * 0.55, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = rgba(255, 220, 140, 0.8 * flick);
        ctx.beginPath();
        ctx.arc(x, y - 6, w * 0.25, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = rgba(40, 22, 18, 0.95);
        ctx.fillRect(x - w * 0.5, y - h, w, h);
        ctx.fillStyle = rgba(90, 36, 28, 0.95);
        ctx.beginPath();
        ctx.moveTo(x - w * 0.6, y - h);
        ctx.lineTo(x, y - h - h * 0.45);
        ctx.lineTo(x + w * 0.6, y - h);
        ctx.closePath();
        ctx.fill();
        if (nightness > 0.4 && d.kind === 'house') {
          ctx.fillStyle = rgba(255, 180, 90, 0.55 + 0.2 * Math.sin(Date.now() * 0.004 + i));
          ctx.fillRect(x - w * 0.15, y - h * 0.55, w * 0.22, h * 0.22);
        }
      }
    }
  }

  function cursorPush(nx, ny) {
    if (presence < 0.01) return { x: 0, y: 0 };
    var dx = nx - cursor.x;
    var dy = ny - cursor.y;
    var dist = Math.sqrt(dx * dx + dy * dy) + 1e-4;
    var fall = Math.exp(-dist * dist * 14) * presence * (0.4 + energy);
    var sign = attractMix - repelMix;
    return { x: dx / dist * fall * sign * 0.04, y: dy / dist * fall * sign * 0.03 };
  }

  function drawEmbers(t) {
    var boost = 1 + level * 1.4 + emberStorm * 1.2 + fxShower * 2;
    for (var i = 0; i < embers.length; i++) {
      var e = embers[i];
      var drift = t * 0.00004 * (0.4 + e.z);
      var nx = mod(e.x + drift * 0.7 + Math.sin(t * 0.001 + e.ph) * 0.01, 1);
      var ny = mod(e.y - drift * e.s * 0.35, 1);
      var push = cursorPush(nx, ny);
      nx = mod(nx + push.x, 1);
      ny = clamp01(ny + push.y);
      var x = nx * width;
      var y = ny * height * 0.85;
      var a = (0.25 + 0.55 * e.z) * (0.45 + 0.55 * nightness) * boost;
      a = Math.min(1, a);
      var r = (1.2 + e.s * 2.2) * (0.8 + bass * 0.6);
      ctx.fillStyle = rgba(255, 120 + e.z * 80, 60, a);
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawAsh(t) {
    if (ashFall < 0.05 && fxShower < 0.05) return;
    var amount = Math.max(ashFall, fxShower * 0.8);
    ctx.fillStyle = rgba(200, 180, 160, 0.35 * amount);
    for (var i = 0; i < ash.length; i++) {
      var p = ash[i];
      var y = mod(p.y + t * 0.0001 * p.v * (1 + amount), 1);
      var x = mod(p.x + Math.sin(t * 0.0003 + i) * 0.002 * p.w, 1);
      ctx.fillRect(x * width, y * height, 1.5 * p.w, 1.5 * p.w);
    }
  }

  function drawHaze() {
    if (heatHaze < 0.05) return;
    var g = ctx.createLinearGradient(0, height * 0.5, 0, height);
    g.addColorStop(0, rgba(255, 100, 40, 0));
    g.addColorStop(1, rgba(255, 90, 40, 0.12 * heatHaze));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, width, height);
  }

  function drawFx() {
    if (fxBurst > 0.01) {
      var g = ctx.createRadialGradient(width * 0.5, height * 0.7, 0, width * 0.5, height * 0.7, height * 0.5);
      g.addColorStop(0, rgba(255, 200, 120, 0.35 * fxBurst));
      g.addColorStop(1, rgba(255, 80, 40, 0));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, width, height);
    }
  }

  function animFrame(name, tSec) {
    var spec = AGENT_FRAMES[name] || AGENT_FRAMES.sitting;
    var idx = spec.loop
      ? spec.start + (Math.floor(tSec * 8) % spec.count)
      : spec.start + Math.min(spec.count - 1, Math.floor(tSec * 10) % spec.count);
    return idx;
  }

  function drawAgents(tSec) {
    if (!agentReady || !popAgents.length) return;
    var fw = agentSheet.width / AGENT_COLS;
    var fh = agentSheet.height / AGENT_ROWS;
    var shore = height * 0.78;
    var drawH = Math.max(28, height * 0.08);
    var drawW = drawH * (fw / fh);
    for (var i = 0; i < popAgents.length; i++) {
      var a = popAgents[i];
      var x = (typeof a.xNorm === 'number' ? a.xNorm : (0.08 + (i % 12) * 0.07)) * width;
      var y = shore - 4;
      var frame = animFrame(a.animation || 'sitting', tSec + i);
      var col = frame % AGENT_COLS;
      var row = Math.floor(frame / AGENT_COLS);
      ctx.save();
      if (a.facing === 'left') {
        ctx.translate(x, y);
        ctx.scale(-1, 1);
        ctx.drawImage(agentSheet, col * fw, row * fh, fw, fh, -drawW * 0.5, -drawH, drawW, drawH);
      } else {
        ctx.drawImage(agentSheet, col * fw, row * fh, fw, fh, x - drawW * 0.5, y - drawH, drawW, drawH);
      }
      ctx.restore();
      if (a.username) {
        ctx.font = '600 11px Segoe UI, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = rgba(255, 230, 210, 0.85);
        ctx.fillText(String(a.username).slice(0, 16), x, y - drawH - 4);
      }
    }
  }

  function draw(t, dt) {
    presence = approach(presence, presenceTarget, 4.5, dt);
    cursor.x = approach(cursor.x, cursorTarget.x, 7, dt);
    cursor.y = approach(cursor.y, cursorTarget.y, 7, dt);
    energyTarget = approach(energyTarget, 0, 2.2, dt);
    energy = approach(energy, energyTarget, 5, dt);
    level = approach(level, audioReactive ? levelTarget : 0, 7, dt);
    bass = approach(bass, audioReactive ? bassTarget : 0, 9, dt);
    pulse = audioReactive ? pulse * Math.exp(-3.4 * dt) : 0;
    fxBurst = approach(fxBurst, 0, 1.2, dt);
    fxShower = approach(fxShower, 0, 0.7, dt);

    var wantA = cursorMotion === CURSOR_ATTRACT ? 1 : 0;
    var wantR = cursorMotion === CURSOR_REPEL ? 1 : 0;
    attractMix = approach(attractMix, wantA, 3.5, dt);
    repelMix = approach(repelMix, wantR, 3.5, dt);

    var wall = t + EPOCH;
    syncWorld(wall);
    worldDays = ageInDays(wall);
    worldGrowth = growth(worldDays);
    dayFrac = dayFraction(wall);
    sunAlt = sunHeight(dayFrac);
    nightness = 1 - smoothstep((sunAlt + 0.14) / 0.30);

    var season = seasonAt(worldDays);
    ashFall = season.ash * 0.85 + season.stormy * 0.35;
    heatHaze = season.dry * 0.9 + level * 0.25;
    emberStorm = season.stormy * (0.5 + 0.5 * nightness) + pulse * 0.4;

    drawSky();
    drawRange(t);
    drawSettlement();
    drawEmbers(t);
    drawAsh(t);
    drawAgents(t / 1000);
    drawHaze();
    drawFx();
  }

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);
    var interval = 1000 / (maxFps || 30);
    if (lastFrame && now - lastFrame < interval - 0.5) return;
    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.25) : 0;
    lastFrame = now;
    draw(Date.now() - EPOCH, dt);
    frames++;
    beatFrames++;
    stamps.push(now);
    if (!lastBeat) lastBeat = now;
    else if (now - lastBeat >= 1000) {
      post({
        v: SCHEMA,
        type: 'heartbeat',
        fps: Math.round(beatFrames * 10000 / (now - lastBeat)) / 10,
        fpsFloor: worstFps(),
        frames: frames
      });
      lastBeat = now;
      beatFrames = 0;
      stamps = stamps.length ? [stamps[stamps.length - 1]] : [];
    }
  }

  function worstFps() {
    if (stamps.length < 3) return 0;
    var worst = 0;
    for (var i = 1; i < stamps.length; i++) {
      var gap = stamps[i] - stamps[i - 1];
      if (gap > worst) worst = gap;
    }
    return worst > 0 ? Math.round(10000 / worst) / 10 : 0;
  }

  function start() {
    if (rafHandle) return;
    lastFrame = 0;
    lastBeat = 0;
    beatFrames = 0;
    stamps.length = 0;
    rafHandle = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  function applyOptions(options) {
    if (!options) return;
    if (options.cursorMotion === CURSOR_ATTRACT ||
        options.cursorMotion === CURSOR_REPEL ||
        options.cursorMotion === CURSOR_OFF) {
      cursorMotion = options.cursorMotion;
    }
    if (typeof options.audioReactive === 'string')
      audioReactive = options.audioReactive === 'true';
    if (typeof options.dayNightCycle === 'string')
      dayNightCycle = options.dayNightCycle === 'true';
    if (options.fixedSky === 'day' || options.fixedSky === 'night')
      fixedSky = options.fixedSky;
    if (typeof options.evolutionSpeed === 'string' &&
        Object.prototype.hasOwnProperty.call(SPEEDS, options.evolutionSpeed)) {
      evolutionRate = SPEEDS[options.evolutionSpeed];
    }
  }

  function settleMode() {
    if (modeSettled) return;
    modeSettled = true;
    attractMix = cursorMotion === CURSOR_ATTRACT ? 1 : 0;
    repelMix = cursorMotion === CURSOR_REPEL ? 1 : 0;
  }

  function applyCursor(c) {
    if (c.onDisplay === false) {
      presenceTarget = 0;
      return;
    }
    presenceTarget = 1;
    if (typeof c.x === 'number') cursorTarget.x = c.x;
    if (typeof c.y === 'number') cursorTarget.y = c.y;
    var vx = typeof c.vx === 'number' ? c.vx : 0;
    var vy = typeof c.vy === 'number' ? c.vy : 0;
    energyTarget = Math.max(energyTarget, Math.min(1, Math.sqrt(vx * vx + vy * vy) / 0.04));
  }

  function applyAudio(a) {
    if (!a || !a.active) {
      levelTarget = 0;
      bassTarget = 0;
      return;
    }
    var loud = typeof a.level === 'number' ? a.level : 0;
    levelTarget = Math.min(1, Math.sqrt(Math.max(0, loud)) * 1.8);
    var bands = a.bands;
    var b = 0;
    if (bands && bands.length) {
      for (var i = 0; i < Math.min(4, bands.length); i++) b += bands[i];
      b /= Math.min(4, bands.length);
    }
    var prev = bassTarget;
    bassTarget = Math.min(1, Math.sqrt(Math.max(0, b)) * 1.6);
    var jump = bassTarget - prev;
    if (jump > 0.06) pulse = Math.min(1, pulse + jump * 2.6);
  }

  function applyTwitch(msg) {
    var effect = msg.effect && msg.effect.id;
    if (!effect || effect === 'none') return;
    if (effect === 'celebration') {
      fxBurst = 1;
      return;
    }
    if (effect === 'meteorShower') {
      var intensity = (msg.effect.params && msg.effect.params.intensity) || 'med';
      fxShower = intensity === 'high' ? 1 : (intensity === 'low' ? 0.45 : 0.75);
      fxBurst = Math.max(fxBurst, 0.4);
    }
  }

  function applyPopulation(msg) {
    if (msg.snapshot && Array.isArray(msg.snapshot.players)) {
      popAgents = msg.snapshot.players.map(function (p, i) {
        return {
          id: p.id,
          username: p.username || '',
          animation: p.animation || 'sitting',
          facing: p.facing || 'right',
          xNorm: typeof p.xNorm === 'number' ? p.xNorm : (typeof p.slotIndex === 'number' ? (0.08 + p.slotIndex * 0.07) : (0.1 + i * 0.07)),
          kind: p.kind || 'npc'
        };
      });
      return;
    }
    if (Array.isArray(msg.players)) {
      applyPopulation({ snapshot: { players: msg.players } });
    }
  }

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { return; }
    }
    if (!msg || typeof msg.type !== 'string') return;
    switch (msg.type) {
      case 'life.init':
        if (msg.performance && msg.performance.maxFps) maxFps = msg.performance.maxFps;
        applyOptions(msg.options);
        settleMode();
        resize();
        placeOnDesktop(msg.display);
        break;
      case 'life.pause': stop(); break;
      case 'life.resume': start(); break;
      case 'life.resize':
        resize();
        placeOnDesktop(msg.display);
        break;
      case 'life.destroy': stop(); break;
      case 'env.tick':
        if (msg.cursor) applyCursor(msg.cursor);
        if (msg.audio) applyAudio(msg.audio);
        break;
      case 'rt.options': applyOptions(msg.options); break;
      case 'rt.performance':
        if (msg.maxFps) maxFps = msg.maxFps;
        break;
      case 'evt.twitch': applyTwitch(msg); break;
      case 'evt.population': applyPopulation(msg); break;
      default: break;
    }
  }

  window.addEventListener('resize', resize);
  window.addEventListener('error', function (e) {
    post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) { onMessage(e.data); });
  }

  resize();
  loadWorld();
  seedLife();
  loadAgentSheet();
  post({ v: SCHEMA, type: 'ready', sceneId: sceneId, renderer: 'canvas2d' });
  start();
})();
