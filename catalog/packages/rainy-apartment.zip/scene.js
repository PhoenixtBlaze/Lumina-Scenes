// Rainy Apartment - Lumina's flagship scene.
//
// A window seat above a neon city in the rain. Everything is procedural: there are no textures to
// ship, no network to reach, and nothing that has to be recomputed when the display changes size.
//
// It is also Lumina's integration test wearing a nicer coat. One scene exercises WebGL2 under
// WorkerW, the frame cap, pause and resume, resize, multi-display, and every ambient signal the
// host serves, so a regression in any of those shows up as something visibly wrong here rather
// than as a number in a log.
//
// Signals are all optional by contract. Every one of them has a defined look when it never
// arrives: no cursor means no parallax, no sun means an evening grade, no audio means no
// equalizer, and no climate means the wet overcast evening the scene is named after. The scene
// must never depend on a signal it merely asked for.
(function () {
  'use strict';

  var SCHEMA = 1;
  var BAND_COUNT = 16;

  var canvas = document.getElementById('scene');
  var clockEl = document.getElementById('clock');
  var metaEl = document.getElementById('meta');
  var sceneId = document.body.dataset.sceneId || 'rainy-apartment';

  var gl = canvas.getContext('webgl2', {
    alpha: false,
    antialias: false,
    depth: false,
    powerPreference: 'high-performance',
    preserveDrawingBuffer: false
  });

  function post(message) {
    if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(message);
  }

  function fail(message) {
    post({ v: SCHEMA, type: 'error', message: String(message), fatal: true });
  }

  if (!gl) { fail('WebGL2 unavailable'); return; }

  // ------------------------------------------------------------------ shaders

  var VERT = `#version 300 es
in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`;

  // One fullscreen pass. The layering that would normally be separate draw calls is done in the
  // shader instead, because every layer reads the same procedural city and a multi-pass version
  // would either re-evaluate it or cost framebuffers this scene does not otherwise need.
  var FRAG = `#version 300 es
precision highp float;

out vec4 frag;

uniform vec2  uRes;
uniform float uTime;        // seconds
uniform vec2  uCursor;      // 0..1 across this display, eased host-side and here
uniform float uNight;       // 1 at night, 0 in full day
uniform float uWarm;        // seasonal tint, 0 cold to 1 warm
uniform float uAudio;       // 0..1 overall loudness, already silence-gated
uniform float uBands[${BAND_COUNT}];

// The climate signal, eased host-side. All modelled, never observed, which is why nothing here
// is ever labelled as a measurement on screen.
uniform float uCloud;       // 0 clear to 1 overcast
uniform float uRain;        // 0..1 liquid falling now
uniform float uSnow;        // 0..1 frozen falling now
uniform float uWet;         // 0..1 how wet the glass is, lags uRain on the way down
uniform float uWind;        // 0..1, slants and speeds the fall
uniform float uHaze;        // 0..1 fog depth over the city
uniform float uThunder;     // 0..1 probability weight, not a trigger

// Where the window is, in screen fractions measured from the bottom-left. The glass, the frame,
// the drops, the condensation and the reflections all have to agree on these, so they are named
// once; nudging one of them inline and missing another is how this composition falls apart.
const float SILL_TOP   = 0.135;
const float REVEAL_X   = 0.045;
const float REVEAL_TOP = 0.028;
const float MULLION_X  = 0.455;
const float TRANSOM_Y  = 0.735;

// ---------------------------------------------------------------- utilities

float hash(vec2 p) {
    p = fract(p * vec2(443.897, 441.423));
    p += dot(p, p + 19.19);
    return fract(p.x * p.y);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

// Signed distance to a box, used for signage. Cheaper than four smoothsteps and it gives the
// outside distance for free, which is what the glow halo is driven from.
float boxDistance(vec2 p, vec2 halfSize) {
    vec2 d = abs(p) - halfSize;
    return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}

// Four fixed hues rather than a hue sweep. A sweep spends most of its range on the muddy colours
// between neon tubes, which is exactly what makes procedural cities look procedural.
vec3 neonPalette(float t) {
    vec3 cyan    = vec3(0.10, 0.86, 1.00);
    vec3 magenta = vec3(1.00, 0.16, 0.58);
    vec3 violet  = vec3(0.56, 0.34, 1.00);
    vec3 sodium  = vec3(1.00, 0.68, 0.22);
    if (t < 0.34) return mix(cyan, magenta, t / 0.34);
    if (t < 0.67) return mix(magenta, violet, (t - 0.34) / 0.33);
    return mix(violet, sodium, (t - 0.67) / 0.33);
}

// ---------------------------------------------------------------- the city
//
// Blocks of buildings in depth-sorted bands. Distance is sold by lifting the base, shrinking the
// heights and mixing the whole band toward the fog colour, which costs three numbers instead of
// the perspective projection this does not otherwise need.
//
// Returns premultiplied-ish colour plus coverage, so the caller composites rather than guessing
// from brightness whether a pixel is sky or an unlit facade.

vec4 cityBand(vec2 uv, float seed, float depth, vec3 fogCol) {
    float w  = mix(0.082, 0.030, depth);
    float ci = floor(uv.x / w) + seed;
    float fx = fract(uv.x / w);

    float base = mix(-0.08, 0.34, depth);

    // A low-frequency envelope across x, so the band has a downtown cluster and quieter edges.
    // Per-column randomness alone gives an even field of towers, which reads as a texture rather
    // than as a skyline no matter how varied the individual heights are.
    // Sampled from the column index rather than uv.x, or the envelope would slope the roofline
    // of each individual building instead of varying between them.
    float district = 0.50 + 0.85 * noise(vec2((ci - seed) * w * 1.15 + seed * 0.7, seed));
    float mass = base + mix(0.18, 0.56, hash(vec2(ci, seed))) * district * (1.0 - depth * 0.5);

    // A narrower core rising out of the main mass. Two stacked rectangles per column is the
    // cheapest thing that breaks up the comb of equal boxes a single height always produces.
    float coreWidth = mix(0.26, 0.64, hash(vec2(ci, seed + 4.0)));
    float coreShift = (hash(vec2(ci, seed + 8.0)) - 0.5) * (1.0 - coreWidth);
    float inCore    = step(abs(fx - 0.5 - coreShift), coreWidth * 0.5);
    float roof      = mass + inCore * mix(0.0, 0.20, hash(vec2(ci, seed + 12.0))) * (1.0 - depth * 0.6);

    vec2 local = vec2(fx * w, uv.y);

    // Aircraft warning light, above the roofline, so it has to be folded into coverage rather
    // than into the facade colour.
    float beacon = smoothstep(0.0075, 0.0025, length(local - vec2(w * (0.5 + coreShift), roof + 0.007)))
                 * step(0.62, fract(uTime * 0.42 + hash(vec2(ci, 5.5))))
                 * (1.0 - depth * 0.7);

    float px = fwidth(uv.y) * 1.1;
    float cover = 1.0 - smoothstep(-px, px, uv.y - roof);
    float total = max(cover, beacon);
    if (total < 0.003) return vec4(0.0);

    // Facade, darkest at street level where nothing lights it.
    vec3 col = mix(vec3(0.007, 0.010, 0.020), fogCol, depth * 0.92);
    col *= mix(0.45, 1.0, smoothstep(base, roof, uv.y));

    // Lit windows. The row grid is offset per column so neighbouring towers do not share floors
    // and read as one building.
    vec2 cellSize = vec2(w * 0.24, 0.020 * (1.0 - depth * 0.45));
    vec2 grid = vec2(uv.x, uv.y + hash(vec2(ci, 1.7)) * 0.014) / cellSize;
    vec2 cell = floor(grid);
    vec2 inCell = fract(grid);

    float pane = step(0.20, inCell.x) * step(inCell.x, 0.80) *
                 step(0.24, inCell.y) * step(inCell.y, 0.76);
    // A slow per-cell blink, not a per-frame one: a window that changes every frame is static.
    float blink = step(0.992, hash(cell + floor(uTime * 0.10) * 3.1));
    float on = step(0.58, hash(cell + seed * 7.3)) * (1.0 - blink) * pane;

    vec3 interior = mix(vec3(1.00, 0.74, 0.42), vec3(0.82, 0.90, 1.00), step(0.82, hash(cell + 2.0)));
    vec3 winCol = mix(interior, neonPalette(hash(cell + 5.0)), step(0.93, hash(cell + 5.0)));
    col += winCol * on * mix(0.05, 1.0, uNight) * mix(0.35, 1.0, hash(cell + 9.0)) * (1.0 - depth * 0.55);

    // Signage, near bands only: at distance a sign is a single pixel and just reads as noise.
    float signSeed = hash(vec2(ci, seed + 21.0));
    if (depth < 0.55 && signSeed > 0.68) {
        vec3 tube = neonPalette(hash(vec2(ci, seed + 27.0)));
        vec2 halfSize = hash(vec2(ci, seed + 29.0)) > 0.5
                      ? vec2(w * 0.085, 0.055)     // blade sign down the corner
                      : vec2(w * 0.30, 0.012);     // billboard across the facade
        vec2 at = vec2(mix(halfSize.x + 0.003, w - halfSize.x - 0.003, hash(vec2(ci, seed + 31.0))),
                       mix(base + 0.12, roof - halfSize.y - 0.012, hash(vec2(ci, seed + 33.0))));

        float d = boxDistance(local - at, halfSize);
        float face = 1.0 - smoothstep(0.0, 0.003, d);
        float halo = exp(-max(d, 0.0) * 40.0);

        // Mains hum plus the occasional dead second. Steady signage reads as a lit quad; the
        // flicker is most of what makes it read as a tube.
        float flicker = (0.86 + 0.14 * sin(uTime * (7.0 + signSeed * 11.0) + ci))
                      * step(0.05, hash(vec2(ci, floor(uTime * 3.0))));

        col += tube * (face * 2.1 + halo * 0.65) * flicker * mix(0.20, 1.0, uNight) * (1.0 - depth * 0.85);
    }

    // Daylight washes a warning light out almost completely; left at full strength it becomes the
    // brightest thing in an overcast frame.
    col += vec3(1.0, 0.11, 0.08) * beacon * mix(0.30, 1.8, uNight);
    return vec4(col, total);
}

// Sky, cloud, skyline and haze. Sampled through a distorted uv so the drops on the glass refract
// all of it rather than just the buildings.
vec3 world(vec2 uv, vec2 parallax, vec3 neon) {
    // Two skies, crossfaded by cloud cover. Overcast is the flat grey this scene was built
    // around; clear is genuinely blue by day and nearly black at night. Interpolating between
    // them rather than tinting one is what lets a break in the weather feel like a different day
    // instead of the same day with the contrast turned up.
    vec3 clearLow     = mix(vec3(0.62, 0.73, 0.90), vec3(0.020, 0.028, 0.072), uNight);
    vec3 clearHigh    = mix(vec3(0.26, 0.47, 0.82), vec3(0.004, 0.007, 0.026), uNight);
    vec3 overcastLow  = mix(vec3(0.40, 0.42, 0.47), vec3(0.055, 0.050, 0.098), uNight);
    vec3 overcastHigh = mix(vec3(0.18, 0.21, 0.28), vec3(0.010, 0.013, 0.034), uNight);

    vec3 skyLow  = mix(clearLow, overcastLow, uCloud);
    vec3 skyHigh = mix(clearHigh, overcastHigh, uCloud);
    vec3 col = mix(skyLow, skyHigh, clamp((uv.y - 0.15) * 1.15, 0.0, 1.0));

    // Stars, and only on a clear night. They are the payoff for the weather breaking: the scene
    // has one view, so the sky is the only place a change of conditions can really show.
    float starVis = uNight * (1.0 - smoothstep(0.10, 0.45, uCloud)) * smoothstep(0.30, 0.55, uv.y);
    if (starVis > 0.002) {
        vec2 grid = uv * vec2(260.0, 150.0);
        vec2 cell = floor(grid);
        float pick = hash(cell);

        // Sparse, and placed inside the cell rather than at its corner, so the field does not
        // read as a lattice.
        if (pick > 0.982) {
            vec2 at = vec2(hash(cell + 3.0), hash(cell + 7.0));
            float d = length(fract(grid) - at);
            float twinkle = 0.55 + 0.45 * sin(uTime * (1.1 + pick * 5.0) + pick * 60.0);
            float mag = 0.35 + 0.65 * hash(cell + 11.0);
            col += vec3(0.86, 0.90, 1.0) * smoothstep(0.09, 0.0, d) * twinkle * mag * starVis * 0.8;
        }
    }

    float cloud = noise(vec2(uv.x * 2.1 + uTime * 0.004, uv.y * 3.2)) * 0.62
                + noise(vec2(uv.x * 4.9 - uTime * 0.007, uv.y * 6.8)) * 0.38;
    // Clear air still has some texture in it, but nothing like a rain cloud's.
    cloud *= 0.18 + 0.82 * uCloud;
    col = mix(col, col * vec3(1.12, 1.06, 1.14), cloud * 0.35);

    // Light pollution: the city throws its own colour back onto the cloud base, which is the one
    // thing that makes a night sky look like a city rather than a gradient. It needs a cloud base
    // to bounce off, so it goes with the overcast.
    col += neon * 0.26 * uNight * cloud * pow(1.0 - clamp(uv.y, 0.0, 1.0), 2.2);

    vec3 fogCol = mix(vec3(0.34, 0.37, 0.44), vec3(0.055, 0.065, 0.135), uNight);

    // Far to near, so the near band composites over the ones behind it.
    for (int i = 2; i >= 0; i--) {
        float depth = float(i) * 0.5;
        float shift = (1.0 - depth) * 0.055;
        vec2 p = vec2(uv.x + parallax.x * shift + float(i) * 0.41,
                      uv.y + parallax.y * shift * 0.35 - depth * 0.015);
        vec4 band = cityBand(p, float(i) * 17.0 + 3.0, depth, fogCol);
        col = mix(col, band.rgb, band.a);
    }

    // Ground fog, which swallows the city from the bottom up. Composited after the bands rather
    // than inside them because fog is between the viewer and all three, not a property of any one.
    if (uHaze > 0.002) {
        float lift = noise(vec2(uv.x * 3.0 + uTime * 0.012, uTime * 0.02)) * 0.06;
        float depth = 1.0 - smoothstep(SILL_TOP, SILL_TOP + 0.26 + 0.30 * uHaze + lift, uv.y);
        col = mix(col, fogCol * (1.0 + 0.40 * uNight), depth * uHaze * 0.88);
    }

    // The street is below the sill and never visible, so the canyon is implied entirely by the
    // glow it throws up between the towers.
    col += neon * 0.16 * uNight * exp(-max(uv.y - SILL_TOP, 0.0) * 9.0);
    return col;
}

// Snow. Not rain with different constants: it drifts sideways, tumbles, and has no streak at all,
// and treating it as slow rain is the tell that gives away a scene that only really does rain.
float snowFall(vec2 uv, float aspect, float scale, float speed, float drift) {
    vec2 p = vec2(uv.x * aspect, uv.y) * scale;
    p.y -= uTime * speed;
    // Each column sways on its own phase, so flakes wander instead of falling in ranks.
    p.x += sin(uTime * 0.5 * drift + p.y * 0.6) * drift;

    vec2 cell = floor(p);
    vec2 f = fract(p);

    float present = step(0.90, hash(cell));
    vec2 at = vec2(hash(cell + 1.0), hash(cell + 2.0));
    float size = 0.06 + 0.10 * hash(cell + 4.0);

    return present * smoothstep(size, 0.0, length(f - at));
}

// ---------------------------------------------------------------- weather
//
// Rain is sheets, not particles. A particle system for this many drops costs a buffer upload
// every frame; a sheared, repeating hash costs nothing and reads the same at wallpaper distance.

float rainSheet(vec2 uv, float scale, float speed, float slant, float thickness) {
    vec2 p = uv * vec2(scale, scale * 0.42);
    p.x += p.y * slant;
    p.y -= uTime * speed;

    vec2 cell = floor(p);
    vec2 f = fract(p);

    float present = step(0.86, hash(cell));
    float streak = smoothstep(thickness, 0.0, abs(f.x - hash(cell + 1.0)));
    float len = 0.32 + 0.48 * hash(cell + 2.0);
    float fade = smoothstep(0.0, 0.10, f.y) * smoothstep(len, len * 0.35, f.y);
    return present * streak * fade;
}

// Beads clinging to the glass. The refraction is the point: a drop that only adds a highlight
// looks like dirt on the screen, and this scene sits behind everything the user is reading.
vec2 dropletOffset(vec2 uv, float aspect, out float lens, out float rim) {
    lens = 0.0;
    rim = 0.0;

    vec2 scale = vec2(15.0 * aspect / 1.78, 10.0);
    vec2 p = uv * scale;
    vec2 cell = floor(p);
    vec2 f = fract(p) - 0.5;

    if (hash(cell) < 0.72) return vec2(0.0);

    // Cubed so most beads are small and the large ones are rare. A flat distribution gives every
    // drop roughly the same size, which is what makes procedural rain look like soap bubbles.
    float size = hash(cell + 7.0);
    float radius = 0.05 + size * size * size * 0.22;

    // Each bead is placed so it fits entirely inside its own cell. Letting one drift across the
    // boundary clips it against the neighbouring sample, which is what turns drops into crescent
    // pairs that read as smudges rather than water.
    float room = (0.5 - radius - 0.02) * 2.0;
    vec2 centre = vec2(hash(cell + 3.0) - 0.5, hash(cell + 11.0) - 0.5) * room;

    vec2 d = (f - centre) * vec2(1.0, 1.08);
    float dist = length(d) / radius;          // 0 at the centre, 1 at the rim
    if (dist > 1.0) return vec2(0.0);

    float body = smoothstep(1.0, 0.86, dist);
    // Water is brightest at the rim, where it bends the most light toward the eye.
    rim = smoothstep(0.55, 0.98, dist) * body;
    // Specular from the room behind the viewer, so it is always on the same side of every bead.
    lens = smoothstep(0.55, 0.0, length(d / radius - vec2(-0.30, 0.32))) * body;

    // A bead is a converging lens, so it shows the scene inverted and magnified rather than
    // merely nudged. Displacing outward instead is what makes procedural drops look like bubbles.
    return -(f - centre) / scale * 1.7 * body;
}

// The handful of beads that actually run. Parameterized per column rather than per cell so a drop
// can travel the whole pane without ever crossing a sampling boundary.
vec2 runnerOffset(vec2 uv, out float glint) {
    glint = 0.0;

    const float COLUMNS = 13.0;
    float c = floor(uv.x * COLUMNS);
    float fx = (fract(uv.x * COLUMNS) - 0.5) / COLUMNS;   // back to screen units

    float r = hash(vec2(c, 91.0));
    if (r < 0.62) return vec2(0.0);

    float y = 1.0 - fract(uTime * (0.045 + r * 0.075) + hash(vec2(c, 17.0)));
    float width = (0.006 + hash(vec2(c, 29.0)) * 0.006);

    float head = smoothstep(1.0, 0.35, length(vec2(fx, (uv.y - y) * 0.62) / width));
    // The trail is only above the head, and only for as long as it takes to drain.
    float trail = smoothstep(width * 0.5, 0.0, abs(fx))
                * smoothstep(0.0, 0.015, uv.y - y)
                * smoothstep(0.20, 0.0, uv.y - y);

    glint = head + trail * 0.30;
    return vec2(sign(fx) * -1.0, 0.0) * (head * 0.009 + trail * 0.002);
}

void main() {
    vec2 uv = gl_FragCoord.xy / uRes;
    float aspect = uRes.x / max(uRes.y, 1.0);

    // Parallax is a head-shift, not a camera move. A wallpaper that swings with the pointer is a
    // novelty that becomes irritating inside a day.
    vec2 parallax = (uCursor - 0.5) * vec2(1.0, 0.55);

    vec3 neon = mix(vec3(0.24, 0.62, 1.00), vec3(1.00, 0.42, 0.48), uWarm);

    // Everything weather-related is clipped to the pane: rain on the frame would give away that
    // the frame is painted on rather than in front.
    float glass = smoothstep(REVEAL_X - 0.002, REVEAL_X + 0.002, uv.x)
                * smoothstep(REVEAL_X - 0.002, REVEAL_X + 0.002, 1.0 - uv.x)
                * smoothstep(SILL_TOP - 0.002, SILL_TOP + 0.002, uv.y)
                * smoothstep(REVEAL_TOP - 0.002, REVEAL_TOP + 0.002, 1.0 - uv.y);

    // The beads scale with how wet the glass is, not with how hard it is raining, so they linger
    // after a shower and the pane dries out slowly instead of snapping clean.
    float lens = 0.0, rim = 0.0, glint = 0.0;
    vec2 bend = vec2(0.0);
    if (uWet > 0.004) {
        bend = (dropletOffset(uv, aspect, lens, rim) + runnerOffset(uv, glint)) * glass * uWet;
        lens *= uWet;
        rim *= uWet;
        glint *= uWet;
    }

    vec3 col = world(uv + bend, parallax, neon);

    col += lens * glass * (0.22 + 0.34 * uNight) * mix(vec3(1.0), neon, 0.45);
    col += rim * glass * (0.14 + 0.26 * uNight) * mix(vec3(0.85, 0.92, 1.0), neon, 0.35);
    col += glint * glass * (0.10 + 0.20 * uNight) * mix(vec3(0.80, 0.88, 1.0), neon, 0.40);

    // Mist too fine to refract. Brightness only, and it fills the gaps between the beads so the
    // glass reads as wet all over rather than as a few objects floating on a clean pane.
    float mist = step(0.993, hash(floor(uv * vec2(420.0 * aspect / 1.78, 420.0))));
    col += mist * glass * (0.03 + 0.07 * uNight) * vec3(0.85, 0.90, 1.0) * uWet;

    // Three sheets at different scales and speeds, all sharing one gust so the wind is coherent.
    // Wind sets both the slant and how much the gust breathes; in still air the fall is nearly
    // vertical, which is the difference between drizzle and a squall.
    if (uRain > 0.004) {
        float gust = (0.06 + 0.62 * uWind) * (1.0 + 0.35 * sin(uTime * 0.09));
        float speed = 1.0 + 0.55 * uWind;
        float rain = rainSheet(uv, 34.0, 2.9 * speed, gust, 0.055) * 0.24
                   + rainSheet(uv, 19.0, 1.9 * speed, gust * 1.2, 0.075) * 0.17
                   + rainSheet(uv, 11.0, 1.25 * speed, gust * 1.5, 0.100) * 0.11;
        col += rain * uRain * glass * mix(vec3(0.50, 0.56, 0.68), neon, 0.45) * (0.55 + 0.65 * uNight);
    }

    // Snow drifts far more than it falls, so the wind moves it sideways rather than speeding it up.
    if (uSnow > 0.004) {
        float drift = 0.25 + 1.5 * uWind;
        float flakes = snowFall(uv, aspect, 26.0, 0.55, drift) * 0.55
                     + snowFall(uv, aspect, 15.0, 0.34, drift * 1.4) * 0.40
                     + snowFall(uv, aspect,  9.0, 0.20, drift * 1.9) * 0.30;
        col += flakes * uSnow * glass * mix(vec3(0.82, 0.86, 0.95), neon, 0.18)
             * (0.70 + 0.50 * uNight);
    }

    // Lightning. Hashed per half-second cell rather than driven by a sine, because anything
    // periodic reads as a strobe; uThunder is a probability weight, so most cells are dark.
    if (uThunder > 0.004) {
        float cell = floor(uTime * 2.0);
        float strike = step(1.0 - uThunder * 0.05, hash(vec2(cell, 31.0)));
        float phase = fract(uTime * 2.0);
        // Two-stroke decay: the leader, then the brighter return a moment later.
        float flash = exp(-phase * 9.0) + 0.6 * exp(-abs(phase - 0.18) * 26.0);
        col += vec3(0.70, 0.78, 1.0) * strike * flash * 0.30 * (0.35 + 0.65 * uNight);
    }

    // Condensation gathers where the glass meets the frame, because that is where it is coldest.
    float toEdge = min(min(uv.x - REVEAL_X, 1.0 - REVEAL_X - uv.x), uv.y - SILL_TOP);
    float fog = noise(uv * vec2(7.0 * aspect / 1.78, 7.0) + vec2(0.0, uTime * 0.008));
    col += vec3(0.035, 0.040, 0.055) * fog * glass * (1.0 - smoothstep(0.0, 0.08, toEdge))
         * (0.35 + 0.65 * uWet);

    // ------------------------------------------------------------ reflections
    //
    // The room reflected in the pane. It does not move with parallax, which is the cue that tells
    // the eye it is on this side of the window.
    col += vec3(1.0, 0.56, 0.22)
         * exp(-length((uv - vec2(0.82, 0.30)) * vec2(1.5, 2.4)) * 3.2)
         * 0.11 * glass * mix(0.4, 1.0, uNight);

    // Audio goes here rather than on top of the city: a reflection is the only place a visualizer
    // could plausibly live in a room, and it keeps it from competing with the skyline.
    if (uAudio > 0.001) {
        float slot = uv.x * float(${BAND_COUNT});
        int index = int(clamp(floor(slot), 0.0, float(${BAND_COUNT} - 1)));
        float top = SILL_TOP + uBands[index] * 0.17 * uAudio;

        float gap = smoothstep(0.06, 0.18, min(fract(slot), 1.0 - fract(slot)));
        float fill = smoothstep(top, top - 0.006, uv.y) * step(SILL_TOP, uv.y);
        // Brightest at the sill and fading upward, the way a reflection in glass actually falls off.
        float falloff = 1.0 - clamp((uv.y - SILL_TOP) / max(top - SILL_TOP, 0.001), 0.0, 1.0);
        col += neon * gap * fill * falloff * 0.42 * glass;
    }

    // ------------------------------------------------------------ the room
    //
    // The frame is what makes this an apartment rather than a flythrough, and it is drawn in
    // screen space so it stays put while the city parallaxes behind it.
    float mullion = (1.0 - smoothstep(0.008, 0.011, abs(uv.x - MULLION_X))) * step(SILL_TOP, uv.y);
    float transom = 1.0 - smoothstep(0.006, 0.009, abs(uv.y - TRANSOM_Y));
    float frame = clamp((1.0 - glass) + mullion + transom, 0.0, 1.0);

    col = mix(col, vec3(0.013, 0.014, 0.022), frame);

    // A catch-light along the inner edges: painted wood next to a bright pane is never pure black,
    // and without this the frame looks like a hole cut in the image.
    float innerEdge = (1.0 - smoothstep(0.0, 0.006, abs(uv.x - MULLION_X) - 0.008))
                    + (1.0 - smoothstep(0.0, 0.005, abs(uv.y - TRANSOM_Y) - 0.006))
                    + (1.0 - smoothstep(0.0, 0.005, abs(uv.y - SILL_TOP) - 0.001));
    col += mix(vec3(0.35, 0.42, 0.55), neon, 0.4) * clamp(innerEdge, 0.0, 1.0) * frame * 0.10;

    // Sill and the room below it, lit only by a lamp behind and to the right of the viewer.
    float room = 1.0 - smoothstep(SILL_TOP - 0.001, SILL_TOP + 0.001, uv.y);
    col += vec3(1.0, 0.58, 0.24)
         * exp(-length((uv - vec2(0.88, 0.0)) * vec2(0.85, 2.1)) * 2.4)
         * room * 0.30 * mix(0.45, 1.0, uNight);
    // The sill edge catches the window light square-on, and it is the brightest thing indoors.
    col += mix(vec3(0.5, 0.58, 0.72), neon, 0.35)
         * exp(-abs(uv.y - SILL_TOP + 0.0035) * 420.0) * 0.16;

    // ------------------------------------------------------------ grade
    //
    // Cool shadows against warm highlights. Without the split, procedural neon tonemaps into a
    // single flat hue and the whole thing reads as a gradient demo.
    float luma = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(col * vec3(0.84, 0.91, 1.14), col * vec3(1.06, 0.98, 0.93), smoothstep(0.06, 0.50, luma));

    col *= 1.0 - 0.50 * pow(length((uv - 0.5) * vec2(1.05, 1.0)), 2.4);
    col = col / (col + 0.72);
    col = pow(col, vec3(0.88));

    // Dither. Large smooth gradients band visibly at 8 bits, and a wallpaper is stared at for
    // hours on a dim desktop, which is exactly when banding is most obvious.
    col += (hash(gl_FragCoord.xy + uTime) - 0.5) / 255.0;

    frag = vec4(col, 1.0);
}`;

  // ------------------------------------------------------------------- setup

  function compile(type, source) {
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      throw new Error(gl.getShaderInfoLog(shader) || 'shader compile failed');
    }
    return shader;
  }

  var program;
  try {
    program = gl.createProgram();
    gl.attachShader(program, compile(gl.VERTEX_SHADER, VERT));
    gl.attachShader(program, compile(gl.FRAGMENT_SHADER, FRAG));
    gl.bindAttribLocation(program, 0, 'aPos');
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      throw new Error(gl.getProgramInfoLog(program) || 'program link failed');
    }
  } catch (e) {
    fail(e.message);
    return;
  }

  gl.useProgram(program);

  var quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

  var u = {
    res: gl.getUniformLocation(program, 'uRes'),
    time: gl.getUniformLocation(program, 'uTime'),
    cursor: gl.getUniformLocation(program, 'uCursor'),
    night: gl.getUniformLocation(program, 'uNight'),
    warm: gl.getUniformLocation(program, 'uWarm'),
    audio: gl.getUniformLocation(program, 'uAudio'),
    bands: gl.getUniformLocation(program, 'uBands'),
    cloud: gl.getUniformLocation(program, 'uCloud'),
    rain: gl.getUniformLocation(program, 'uRain'),
    snow: gl.getUniformLocation(program, 'uSnow'),
    wet: gl.getUniformLocation(program, 'uWet'),
    wind: gl.getUniformLocation(program, 'uWind'),
    haze: gl.getUniformLocation(program, 'uHaze'),
    thunder: gl.getUniformLocation(program, 'uThunder')
  };

  // ------------------------------------------------------------------- state

  var negotiated = {};
  var maxFps = 30;

  // The two halves of the label under the clock. Kept apart because season and climate arrive on
  // different messages and either can be absent for the whole session.
  var seasonWord = '';
  var climateWord = '';

  var width = 0;
  var height = 0;

  // Targets are what the host last said; the rendered values chase them. Signals arrive in steps
  // - the cursor at 30Hz, the sun every few minutes - and stepping a visual straight to a new
  // value makes a wallpaper twitch, which is the one thing it must never do.
  var cursor = { x: 0.5, y: 0.5 };
  var cursorTarget = { x: 0.5, y: 0.5 };
  var night = 0.85;              // evening until the sun says otherwise
  var nightTarget = 0.85;
  var warm = 0.5;
  var warmTarget = 0.5;
  var audio = 0;
  var audioTarget = 0;
  var bands = new Float32Array(BAND_COUNT);
  var bandTargets = new Float32Array(BAND_COUNT);

  // Weather. The defaults are the scene's own identity - a wet, overcast evening - because
  // climate is declined outright when the host has no location, and a scene called Rainy
  // Apartment opening on a clear blue sky because nobody knows where the user is would be worse
  // than one that simply never changes.
  var cloud = 0.92, cloudTarget = 0.92;
  var rain = 0.55, rainTarget = 0.55;
  var snow = 0, snowTarget = 0;
  var wet = 0.70, wetTarget = 0.70;
  var wind = 0.30, windTarget = 0.30;
  var haze = 0.05, hazeTarget = 0.05;
  var thunder = 0, thunderTarget = 0;

  var rafHandle = 0;
  var lastFrame = 0;
  var lastBeat = 0;
  var stamps = [];               // rendered-frame times since the last heartbeat
  var beatFrames = 0;
  var frames = 0;
  var elapsed = 0;               // seconds of animation time, paused with the scene

  function resize() {
    var dpr = window.devicePixelRatio || 1;
    width = Math.max(1, Math.round(window.innerWidth * dpr));
    height = Math.max(1, Math.round(window.innerHeight * dpr));
    canvas.width = width;
    canvas.height = height;
    gl.viewport(0, 0, width, height);
  }

  function approach(current, target, rate, dt) {
    // Frame-rate independent easing. A plain lerp per frame would ease at a different speed at
    // 30fps than at 60, and the host changes the cap at runtime.
    return current + (target - current) * (1.0 - Math.exp(-rate * dt));
  }

  function render(dt) {
    cursor.x = approach(cursor.x, cursorTarget.x, 6.0, dt);
    cursor.y = approach(cursor.y, cursorTarget.y, 6.0, dt);
    night = approach(night, nightTarget, 0.35, dt);
    warm = approach(warm, warmTarget, 0.2, dt);
    audio = approach(audio, audioTarget, 8.0, dt);

    for (var i = 0; i < BAND_COUNT; i++) {
      // Faster than the other eases: the host already applies attack and release to the bands,
      // so this only smooths the 30Hz delivery rate, not the musical envelope.
      bands[i] = approach(bands[i], bandTargets[i], 16.0, dt);
    }

    // Weather eases far slower than anything else here. The host sends a new climate state every
    // few minutes and each one is a small step, but a sky that reaches its new state in a second
    // still reads as a cut; over a minute it reads as the weather changing.
    cloud = approach(cloud, cloudTarget, 0.08, dt);
    rain = approach(rain, rainTarget, 0.10, dt);
    snow = approach(snow, snowTarget, 0.10, dt);
    wind = approach(wind, windTarget, 0.15, dt);
    haze = approach(haze, hazeTarget, 0.06, dt);
    thunder = approach(thunder, thunderTarget, 0.20, dt);

    // Asymmetric on purpose. Glass wets almost as fast as it starts raining and then dries over
    // several minutes, so the beads outlast the shower. Easing this symmetrically makes the pane
    // go clean the moment the rain stops, which is the most obviously wrong thing the scene can do.
    wetTarget = Math.max(rain, snow * 0.35);
    wet = approach(wet, wetTarget, wetTarget > wet ? 0.35 : 0.018, dt);

    gl.uniform2f(u.res, width, height);
    gl.uniform1f(u.time, elapsed);
    gl.uniform2f(u.cursor, cursor.x, cursor.y);
    gl.uniform1f(u.night, night);
    gl.uniform1f(u.warm, warm);
    gl.uniform1f(u.audio, audio);
    gl.uniform1fv(u.bands, bands);
    gl.uniform1f(u.cloud, cloud);
    gl.uniform1f(u.rain, rain);
    gl.uniform1f(u.snow, snow);
    gl.uniform1f(u.wet, wet);
    gl.uniform1f(u.wind, wind);
    gl.uniform1f(u.haze, haze);
    gl.uniform1f(u.thunder, thunder);

    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  function loop(now) {
    rafHandle = requestAnimationFrame(loop);

    // Honour the host's cap. This is mandatory, not advisory: nothing else in the stack limits a
    // wallpaper's frame rate, and requestAnimationFrame is not a frame limiter.
    var interval = 1000 / (maxFps || 30);
    if (lastFrame && now - lastFrame < interval - 0.5) return;

    // Clamped so a long stall cannot jump the rain forward by a visible amount in one frame.
    var dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.25) : 0;
    lastFrame = now;
    elapsed += dt;

    render(dt);
    frames++;
    beatFrames++;

    stamps.push(now);

    // From inside the render loop, never a timer. A heartbeat on setInterval would keep arriving
    // from a scene that had stopped drawing, which is the failure the host watchdog exists to
    // catch, and the host suspends scenes that keep beating after life.pause.
    if (!lastBeat) {
      lastBeat = now;
    } else if (now - lastBeat >= 1000) {
      post({
        v: SCHEMA,
        type: 'heartbeat',
        fps: Math.round(beatFrames * 10000 / (now - lastBeat)) / 10,
        // Required by the contract, and the host's only evidence of stutter. It compares this
        // against fps to decide whether to ask the scene to scale down, and a scene that omits it
        // is one the host cannot help.
        fpsFloor: worstFps(),
        frames: frames
      });
      lastBeat = now;
      beatFrames = 0;
      // Keep only the boundary frame, so the next floor covers the next second and nothing else.
      if (stamps.length) stamps = [stamps[stamps.length - 1]];
    }
  }

  // The slowest frame since the last heartbeat, as a rate.
  //
  // Scoped to the heartbeat interval on purpose. A longer window is the more usual way to compute
  // a 1% low, but it makes consecutive heartbeats report the same worst frame over and over, and
  // the host counts consecutive bad heartbeats to decide the scene is struggling. Over five
  // seconds a single hitch is indistinguishable from five seconds of sustained stutter. This also
  // keeps the floor over the same interval as the fps reported beside it, which is what makes the
  // ratio of the two meaningful.
  function worstFps() {
    if (stamps.length < 3) return 0;

    var worst = 0;
    for (var i = 1; i < stamps.length; i++) {
      var gap = stamps[i] - stamps[i - 1];
      if (gap > worst) worst = gap;
    }

    return worst > 0 ? Math.round(10000 / worst) / 10 : 0;
  }

  function start() {
    if (rafHandle) return;
    lastFrame = 0;          // so the first frame after a resume has no accumulated delta
    lastBeat = 0;
    beatFrames = 0;
    // The pause itself is a gap of arbitrary length between two rendered frames. Left in the
    // window it would be reported as this second's worst frame, and the host would read a resume
    // as catastrophic stutter.
    stamps.length = 0;
    rafHandle = requestAnimationFrame(loop);
  }

  function stop() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    rafHandle = 0;
  }

  // ------------------------------------------------------------------ signals

  function pad(n) { return n < 10 ? '0' + n : String(n); }

  function applyClock(clock) {
    if (typeof clock.hour !== 'number' || typeof clock.minute !== 'number') return;
    clockEl.textContent = pad(clock.hour) + ':' + pad(clock.minute);
    clockEl.style.opacity = '1';
  }

  // Elevation drives the grade continuously rather than switching on sun.phase, because a
  // wallpaper that flips its palette the instant civil twilight ends is jarring. Phase is only
  // used as the fallback shape when elevation is missing.
  function applySun(sun) {
    if (typeof sun.elevation === 'number') {
      // Fully lit above 10 degrees, fully dark below -6, which is roughly civil twilight.
      nightTarget = 1.0 - Math.min(1, Math.max(0, (sun.elevation + 6) / 16));
    } else if (typeof sun.phase === 'string') {
      nightTarget = sun.phase === 'day' ? 0.05 : sun.phase === 'civil' ? 0.55 : 0.95;
    }
  }

  function applySeason(season) {
    // Only a tint: autumn and summer push the neon warm, winter pushes it cold. The season is a
    // word by contract, so there is no latitude here to get wrong.
    var byName = { summer: 0.75, autumn: 0.85, spring: 0.40, winter: 0.10 };
    if (typeof season.season === 'string' && byName[season.season] !== undefined) {
      warmTarget = byName[season.season];
    }
    if (typeof season.season === 'string') {
      seasonWord = season.season;
      renderMeta();
    }
  }

  function clamp01(n) { return n < 0 ? 0 : n > 1 ? 1 : n; }

  function applyClimate(c) {
    if (typeof c.cloudCover === 'number') cloudTarget = clamp01(c.cloudCover);
    if (typeof c.wind === 'number') windTarget = clamp01(c.wind);
    if (typeof c.thunder === 'number') thunderTarget = clamp01(c.thunder);

    // The model's fog is the shallow kind that sits on the ground at dawn, so it drives the haze
    // in the street rather than the condensation on the pane, which is an indoor phenomenon and
    // tracks how wet the glass is instead.
    if (typeof c.fog === 'number') hazeTarget = clamp01(c.fog);

    var falling = typeof c.precipitation === 'number' ? clamp01(c.precipitation) : 0;
    // Sleet is the reason this is a split rather than a switch: it falls as both, and a scene
    // that picks one looks wrong for the whole band between rain and snow.
    var frozen = c.precipitationType === 'snow' ? 1
      : c.precipitationType === 'sleet' ? 0.5
        : 0;

    rainTarget = falling * (1 - frozen);
    snowTarget = falling * frozen;

    climateWord = conditionWord(c, falling);
    renderMeta();
  }

  // What to call the sky. Deliberately plain language and deliberately never a temperature: the
  // signal is modelled, and a number on screen would read as a measurement.
  function conditionWord(c, falling) {
    if (c.precipitationType === 'snow') return falling > 0.45 ? 'heavy snow' : 'snow';
    if (c.precipitationType === 'sleet') return 'sleet';
    if (falling > 0.45) return 'heavy rain';
    if (falling > 0.15) return 'rain';
    if (falling > 0.02) return 'drizzle';
    if (typeof c.fog === 'number' && c.fog > 0.30) return 'fog';
    if (typeof c.cloudCover === 'number' && c.cloudCover > 0.75) return 'overcast';
    if (typeof c.cloudCover === 'number' && c.cloudCover > 0.35) return 'cloudy';
    return 'clear';
  }

  function renderMeta() {
    var parts = [];
    if (seasonWord) parts.push(seasonWord);
    if (climateWord) parts.push(climateWord);
    if (!parts.length) return;

    metaEl.textContent = parts.join(' \u00b7 ');
    metaEl.style.opacity = '1';
  }

  function applyCursor(c) {
    // onDisplay false still carries the last on-display position, so the parallax eases out
    // toward centre instead of freezing wherever the pointer left.
    if (c.onDisplay === false) {
      cursorTarget.x = 0.5;
      cursorTarget.y = 0.5;
      return;
    }
    if (typeof c.x === 'number') cursorTarget.x = c.x;
    if (typeof c.y === 'number') cursorTarget.y = c.y;
  }

  function applyAudio(a) {
    // active is the host's silence gate. Honouring it is what keeps the equalizer from sitting
    // there at zero on a quiet desktop, which would be a permanent strip of furniture.
    if (!a.active) {
      audioTarget = 0;
      return;
    }
    audioTarget = 1;
    if (a.bands && a.bands.length) {
      for (var i = 0; i < BAND_COUNT; i++) {
        bandTargets[i] = i < a.bands.length ? a.bands[i] : 0;
      }
    }
  }

  function onMessage(raw) {
    var msg = raw;
    if (typeof msg === 'string') {
      try { msg = JSON.parse(msg); } catch (e) { return; }
    }
    if (!msg || typeof msg.type !== 'string') return;

    switch (msg.type) {
      case 'life.init':
        negotiated = msg.signals || {};
        if (msg.performance && msg.performance.maxFps) maxFps = msg.performance.maxFps;
        resize();
        break;
      case 'life.pause':
        // Required, not advisory. The host leaves the surface up so this frame stays on screen.
        stop();
        break;
      case 'life.resume':
        start();
        break;
      case 'life.resize':
        // Deliberately does not start the loop: a resolution change must never wake a scene that
        // a fullscreen game paused.
        resize();
        break;
      case 'life.destroy':
        stop();
        break;
      case 'env.tick':
        if (msg.cursor) applyCursor(msg.cursor);
        if (msg.audio) applyAudio(msg.audio);
        break;
      case 'env.state':
        // Every key is optional on every message, including ones that were negotiated: the host
        // sends only what changed, and a negotiated signal can still never arrive.
        if (msg.clock) applyClock(msg.clock);
        if (msg.sun) applySun(msg.sun);
        if (msg.season) applySeason(msg.season);
        if (msg.climate) applyClimate(msg.climate);
        break;
      case 'rt.performance':
        if (msg.maxFps) maxFps = msg.maxFps;
        break;
      default:
        // Unknown types are ignored on purpose: it is what lets the host add signals without a
        // coordinated release of every existing scene.
        break;
    }
  }

  window.addEventListener('resize', resize);
  window.addEventListener('error', function (e) {
    post({ v: SCHEMA, type: 'error', message: String(e.message), fatal: true });
  });
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', function (e) { onMessage(e.data); });
  }

  resize();
  post({ v: SCHEMA, type: 'ready', sceneId: sceneId, renderer: 'webgl2' });
  start();
})();
